from typing import List, Optional, Union

from fastapi import UploadFile as Up1
from starlette.datastructures import UploadFile as Up2

_VIDEO = "video"
_IMAGE = "image"


def check_type_files_in_image_or_video(
    files: Union[Up1, Up2, List[Union[Up1, Up2]]],
    is_image: bool = True,
    is_video: bool = True,
) -> bool:
    types = []

    if is_video:
        types.append(_VIDEO)

    if is_image:
        types.append(_IMAGE)

    if isinstance(files, (Up1, Up2)):
        return files.content_type.split("/")[0] in types
    if isinstance(files, list):
        return all(file.content_type.split("/")[0] in types for file in files)

    return False


def check_type_media(files: Union[Up1, Up2]) -> Optional[str]:
    types = {
        "image": "photo",
        "video": "video",
        "audio": "audio",
        "application": "document",
    }

    return types.get(files.content_type.split("/")[0], None)
