from pydantic import BaseSettings


class JWTSettings(BaseSettings):
    JWT_ACCESS_LIFETIME_DAYS: float
    JWT_REFRESH_LIFETIME_DAYS: float
    JWT_SECRET: str
    JWT_ALGORITHM: str
