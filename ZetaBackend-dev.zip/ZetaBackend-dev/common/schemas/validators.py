from common.enums.validators import ValidatorsErrorEnum


def validate_email(email: str) -> str:
    if not isinstance(email, str):
        raise TypeError(ValidatorsErrorEnum.EMAIL_MUST_BE_STR.to_str_dict_for_exception)
    if "@" not in email:
        raise ValueError(
            ValidatorsErrorEnum.EMAIL_NOT_CONTAIN_DOG.to_str_dict_for_exception
        )
    return email


def validate_phone_number(phone_number: str) -> str:
    """
    На данный момент проверяется только что все цифры
    и начало на +
    позже добавим проверку на код страны и т.д.
    """
    if not isinstance(phone_number, str):
        raise TypeError(ValidatorsErrorEnum.PHONE_MUST_BE_STR.to_str_dict_for_exception)
    phone_number = phone_number.strip()
    if not phone_number.startswith("+"):
        raise ValueError(ValidatorsErrorEnum.PHONE_START_PLUS.to_str_dict_for_exception)
    if not phone_number[1:].isdigit():
        raise ValueError(ValidatorsErrorEnum.PHONE_ONLY_DIGIT.to_str_dict_for_exception)
    return phone_number
