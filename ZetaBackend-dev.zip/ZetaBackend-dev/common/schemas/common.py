from typing import Any, Optional

from pydantic import BaseModel


class Page(BaseModel):
    limit: int
    page: int
    data: Any = None
    count: Optional[int] = None
