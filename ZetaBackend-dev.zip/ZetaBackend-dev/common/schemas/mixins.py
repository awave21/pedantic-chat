import json
from typing import Any, Dict, Iterable

from pydantic import BaseModel


class FormDataMixinSchema(BaseModel):
    @classmethod
    def __get_validators__(cls) -> Iterable[BaseModel]:
        yield cls.validate_to_json

    @classmethod
    def validate_to_json(cls, value: Any) -> BaseModel:
        if isinstance(value, str):
            return cls(**json.loads(value))
        return value
