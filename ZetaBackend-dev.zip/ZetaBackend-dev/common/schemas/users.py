from typing import Optional

from pydantic import BaseModel


class ShortPersonProfile(BaseModel):
    id: int
    nickname: str
    avatar: Optional[str]

    class Config:
        orm_mode = True
