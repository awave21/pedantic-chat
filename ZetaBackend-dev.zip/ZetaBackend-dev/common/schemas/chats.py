from typing import Optional

from pydantic import BaseModel


class ChatAvatar(BaseModel):
    id: Optional[int]
    link: str

    class Config:
        orm_mode = True


class Media(BaseModel):
    id: Optional[int]
    type: Optional[str]
    url: str

    class Config:
        orm_mode = True
