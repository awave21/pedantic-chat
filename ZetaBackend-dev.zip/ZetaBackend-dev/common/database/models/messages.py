from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from ..base import Base
from ..mixins import EqMixin
from . import SubCategory
from .many_to_many import ChatsAssociateTable, MessagesAssociateTable
from .media import ChatAvatar


class Chat(Base, EqMixin):
    __tablename__ = "chat"

    id = Column(Integer, primary_key=True)
    users = relationship("User", secondary=ChatsAssociateTable, back_populates="chats")
    is_group = Column(Boolean, default=False)
    is_public = Column(Boolean, default=False)
    name = Column(String, nullable=True)
    # avatar = Column(String, nullable=True)
    avatar_id = Column(Integer, ForeignKey(ChatAvatar.id), nullable=True)
    avatar = relationship(ChatAvatar, uselist=False)
    admin_id = Column(Integer, ForeignKey("user.id", ondelete="CASCADE"), nullable=True)
    admin = relationship("User", uselist=False)
    messages = relationship("Message", back_populates="chat")


class Message(Base, EqMixin):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    from_id = Column(Integer, ForeignKey("user.id", ondelete="CASCADE"))
    author = relationship("User", back_populates="messages")
    chat_id = Column(Integer, ForeignKey("chat.id", ondelete="CASCADE"))
    chat = relationship("Chat", back_populates="messages")
    text = Column(String(2048), nullable=True)
    state = Column(String, default="sent")  # sent - доставлено, read - прочитано
    # attachments = relationship("Attachment", back_populates="message")
    attachments = relationship(
        "Attachment", secondary=MessagesAssociateTable, back_populates="message"
    )


class Attachment(Base, EqMixin):
    __tablename__ = "attachments"

    id = Column(Integer, primary_key=True)
    # message_id = Column(Integer, ForeignKey("messages.id"))
    # message = relationship("Message", back_populates="attachments")
    message = relationship(
        "Message", secondary=MessagesAssociateTable, back_populates="attachments"
    )
    type = Column(String, default="photo")  # photo, video, audio, document
    url = Column(String, nullable=True)
