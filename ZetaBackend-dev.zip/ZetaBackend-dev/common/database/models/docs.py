from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String, Text

from ..base import Base
from ..mixins import EqMixin


class Document(Base, EqMixin):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    name = Column(String)
    name_eng = Column(String)
    text = Column(Text)
    text_eng = Column(Text)
    slug = Column(Text, nullable=True, unique=True)
    last_update = Column(DateTime(timezone=True), default=datetime.utcnow)
