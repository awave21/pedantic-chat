from datetime import datetime

from sqlalchemy import (
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Table,
    UniqueConstraint,
)

from common.database.base import Base

LikerAssociateTable = Table(
    "user_post_liker_associated",
    Base.metadata,
    Column("post_id", ForeignKey("post.id")),
    Column("user_id", ForeignKey("user.id")),
    UniqueConstraint("post_id", "user_id", name="unique_liker_for_post"),
)


FavoriteAssociateTable = Table(
    "user_post_favorite_associated",
    Base.metadata,
    Column("post_id", ForeignKey("post.id")),
    Column("user_id", ForeignKey("user.id")),
    Column("created_at", DateTime(timezone=True), default=datetime.utcnow),
    UniqueConstraint("post_id", "user_id", name="unique_favorite_posts_for_user"),
)


PostSubCategoryAssociateTable = Table(
    "post_subcategory_associated",
    Base.metadata,
    Column("post_id", ForeignKey("post.id")),
    Column("subcategory_id", ForeignKey("subcategory.id")),
    UniqueConstraint("post_id", "subcategory_id", name="unique_subcategory_for_post"),
)


UserSubCategoryAssociateTable = Table(
    "user_subcategory_associated",
    Base.metadata,
    Column("user_id", ForeignKey("user.id")),
    Column("subcategory_id", ForeignKey("subcategory.id")),
    UniqueConstraint("user_id", "subcategory_id", name="unique_subcategory_for_user"),
)


FollowersAssociateTable = Table(
    "followers_associated",
    Base.metadata,
    Column("follower_id", ForeignKey("user.id")),
    Column("following_id", ForeignKey("user.id")),
    Column("created_at", DateTime(timezone=True), default=datetime.utcnow),
    UniqueConstraint("follower_id", "following_id", name="unique_followers"),
    CheckConstraint("follower_id != following_id", name="check_follower_self"),
)


BlockedAssociateTable = Table(
    "blocked_associated",
    Base.metadata,
    Column("blocker_id", ForeignKey("user.id")),
    Column("blocking_id", ForeignKey("user.id")),
    Column("created_at", DateTime(timezone=True), default=datetime.utcnow),
    UniqueConstraint("blocker_id", "blocking_id", name="unique_blocks"),
    CheckConstraint("blocker_id != blocking_id", name="check_block_self"),
)


ChatsAssociateTable = Table(
    "chat_users_associated",
    Base.metadata,
    Column("user_id", ForeignKey("user.id", ondelete="CASCADE")),
    Column("chat_id", ForeignKey("chat.id", ondelete="CASCADE")),
    UniqueConstraint("user_id", "chat_id", name="unique_chat_members"),
)


MessagesAssociateTable = Table(
    "messages_attachments_associated",
    Base.metadata,
    Column("message_id", ForeignKey("messages.id", ondelete="CASCADE")),
    Column("attachment_id", ForeignKey("attachments.id", ondelete="CASCADE")),
    UniqueConstraint("message_id", "attachment_id", name="unique_message_attachments"),
)
