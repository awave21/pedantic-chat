from datetime import datetime

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from common.database.base import Base
from common.database.mixins import EqMixin
from common.database.models.posts import Post


class Media(Base, EqMixin):
    __tablename__ = "media"

    id = Column(Integer, primary_key=True)
    type = Column(String)
    link = Column(String)

    post_id = Column(Integer, ForeignKey("post.id"))
    post = relationship(Post, back_populates="medias")

    aspect_ratio = Column(Float)

    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)


class ChatAvatar(Base, EqMixin):
    __tablename__ = "chat_avatar"

    id = Column(Integer, primary_key=True)
    link = Column(String)

    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
