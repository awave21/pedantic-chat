from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.future import select
from sqlalchemy.orm import relationship
from sqlalchemy.sql import Select

from common.database.base import Base
from common.database.mixins import EqMixin
from common.database.models.many_to_many import (
    FavoriteAssociateTable,
    LikerAssociateTable,
    PostSubCategoryAssociateTable,
)


class Post(Base, EqMixin):
    __tablename__ = "post"

    id = Column(Integer, primary_key=True)
    description = Column(Text(1024))
    tags = Column(String(1024), nullable=True)

    is_draft = Column(Boolean, server_default="False", default=False)

    author_id = Column(Integer, ForeignKey("user.id"))
    author = relationship("User", back_populates="posts")

    media_count = Column(Integer, server_default="0")
    medias = relationship("Media", back_populates="post")

    subcategories = relationship(
        "SubCategory", secondary=PostSubCategoryAssociateTable, back_populates="posts"
    )
    favorite_for = relationship(
        "User", secondary=FavoriteAssociateTable, back_populates="favorite_posts"
    )
    likers = relationship(
        "User", secondary=LikerAssociateTable, back_populates="like_posts"
    )

    updated_at = Column(
        DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow
    )
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    reports = relationship("Report", back_populates="post")

    @staticmethod
    def get_count_liker_post_query() -> Select:
        """
        Подзапрос для количества лайков поста
        """
        return (
            select(func.count())
            .where(LikerAssociateTable.c.post_id == Post.id)
            .scalar_subquery()
        )

    def set_optional_fields_for_list_view(self, user_id: int) -> None:
        """
        Устанавливает допоплнительные поля, необходимые для отображение листинга постов
        на фронтенде
        """

        self.count_likers = len(self.likers)
        self.is_liker = user_id in [liker.id for liker in self.likers]
        self.is_favorite = user_id in [favorite.id for favorite in self.favorite_for]

    def set_optional_fields_for_favorite_list_view(self, user_id: int) -> None:
        """
        Устанавливает допоплнительные поля, необходимые для отображение листинга сохраненных постов
        на фронтенде
        """
        self.count_likers = len(self.likers)
        self.is_liker = user_id in [liker.id for liker in self.likers]
        self.is_favorite = True


class Report(Base, EqMixin):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True)

    user_id = Column(Integer, ForeignKey("user.id"))
    user = relationship("User", back_populates="reports")

    post_id = Column(Integer, ForeignKey("post.id"))
    post = relationship("Post", back_populates="reports")

    description = Column(Text(1024))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    solved = Column(Boolean, default=False)
