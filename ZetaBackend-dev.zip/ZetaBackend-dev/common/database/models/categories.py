from sqlalchemy import Boolean, Column, ForeignKey, Index, Integer, String, func
from sqlalchemy.orm import relationship

from ..base import Base
from ..mixins import EqMixin
from .many_to_many import PostSubCategoryAssociateTable, UserSubCategoryAssociateTable
from .posts import Post


class Category(Base, EqMixin):
    __tablename__ = "category"

    id = Column(Integer, primary_key=True)
    name_en = Column(
        String,
    )
    name_ru = Column(
        String,
    )
    is_archive = Column(Boolean, server_default=str(False), default=False)
    subcategories = relationship(
        "SubCategory",
        back_populates="category",
        order_by="asc(SubCategory.is_archive), asc(SubCategory.id)",
    )


class SubCategory(Base, EqMixin):
    __tablename__ = "subcategory"

    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("category.id"))
    name_en = Column(
        String,
    )
    name_ru = Column(
        String,
    )
    icon = Column(String)
    is_archive = Column(Boolean, server_default=str(False), default=False)
    category = relationship(Category, back_populates="subcategories")

    posts = relationship(
        Post, secondary=PostSubCategoryAssociateTable, back_populates="subcategories"
    )

    users = relationship(
        "User", secondary=UserSubCategoryAssociateTable, back_populates="subcategories"
    )


# В миграции для БД эти индексы вбиты руками, так как - not supported by SQLAlchemy reflection
# Index("idx_category_name_lower", func.lower(Category.name))
# Index("idx_subcategory_name_lower", func.lower(SubCategory.name))
