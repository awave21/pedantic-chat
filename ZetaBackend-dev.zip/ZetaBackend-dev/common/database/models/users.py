from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from ..base import Base
from ..mixins import EqMixin
from . import SubCategory
from .many_to_many import (
    BlockedAssociateTable,
    ChatsAssociateTable,
    FavoriteAssociateTable,
    FollowersAssociateTable,
    LikerAssociateTable,
    UserSubCategoryAssociateTable,
)
from .posts import Post, Report


class User(Base, EqMixin):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True)
    nickname = Column(String, nullable=False, index=True)
    password = Column(Text, nullable=True)

    avatar = Column(String, nullable=True)

    phone = Column(String, nullable=True)
    email = Column(String, nullable=True)

    age = Column(SmallInteger, nullable=True)
    country = Column(String, nullable=True)

    about_me = Column(String(1024), nullable=True)

    is_draft = Column(Boolean, default=True)  # является ли юзер черновым
    is_admin = Column(Boolean, default=False)
    is_blocked = Column(Boolean, default=False)

    count_posts = Column(Integer, server_default="0", default=0)
    count_followers = Column(Integer, server_default="0", default=0)
    count_followings = Column(Integer, server_default="0", default=0)

    followers = relationship(
        "User",
        secondary=FollowersAssociateTable,
        primaryjoin=(id == FollowersAssociateTable.c.follower_id),
        secondaryjoin=(id == FollowersAssociateTable.c.following_id),
    )
    followings = relationship(
        "User",
        secondary=FollowersAssociateTable,
        primaryjoin=(id == FollowersAssociateTable.c.following_id),
        secondaryjoin=(id == FollowersAssociateTable.c.follower_id),
    )
    blocked = relationship(
        "User",
        secondary=BlockedAssociateTable,
        primaryjoin=(id == BlockedAssociateTable.c.blocking_id),
        secondaryjoin=(id == BlockedAssociateTable.c.blocker_id),
    )

    posts = relationship(Post, back_populates="author")
    favorite_posts = relationship(
        Post, secondary=FavoriteAssociateTable, back_populates="favorite_for"
    )
    like_posts = relationship(
        Post, secondary=LikerAssociateTable, back_populates="likers"
    )

    subcategories = relationship(
        SubCategory, secondary=UserSubCategoryAssociateTable, back_populates="users"
    )

    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    chats = relationship("Chat", secondary=ChatsAssociateTable, back_populates="users")

    messages = relationship("Message", back_populates="author")

    reports = relationship(Report, back_populates="user")

    __table_args__ = (
        CheckConstraint("age >= 0", name="check_positive_age"),
        CheckConstraint("count_posts >= 0", name="check_positive_count_posts"),
        CheckConstraint("count_followers >= 0", name="check_positive_count_followers"),
        CheckConstraint(
            "count_followings >= 0", name="check_positive_count_followings"
        ),
    )

    @property
    def phone_int(self) -> int:
        return int(self.phone.replace("+", ""))


class VerificationCode(Base, EqMixin):
    __tablename__ = "verification_code"

    id = Column(Integer, primary_key=True)
    user = Column(
        Integer, ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True
    )
    code = Column(String, nullable=False)
    type = Column(String, nullable=False)
