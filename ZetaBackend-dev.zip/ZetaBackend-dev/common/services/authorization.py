from typing import Optional

from common.database.models import User
from common.db import get_db
from common.repositories.authorization import UserAuthorizationRepository


class AuthorizationService:
    def __init__(self, auth_user_repository: UserAuthorizationRepository):
        self.auth_user_repository = auth_user_repository

    async def get_user_by_id(self, id: int) -> Optional[User]:
        return await self.auth_user_repository.get_user_by_id(id)


authorization_service = AuthorizationService(UserAuthorizationRepository(get_db))


async def get_authorization_service() -> AuthorizationService:
    return authorization_service
