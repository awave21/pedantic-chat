from typing import Dict

from starlette.datastructures import QueryParams


def get_query_params(query_params: QueryParams) -> Dict[str, str]:
    return {key: value for key, value in query_params.multi_items()}
