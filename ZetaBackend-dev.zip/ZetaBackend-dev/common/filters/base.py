import copy
from typing import Dict, Type

from sqlalchemy.sql import Select

from common.database.base import Base
from common.filters import func as filter


class FilterBase:
    fields: Dict = {}

    def __init__(self, filters: Dict[str, str]) -> None:
        self.allowed_filter_func = self._check_allowed_filter_func(filters)

    async def exec_filter(self, select: Select, model: Type[Base]) -> Select:
        for key, value in self.allowed_filter_func.items():
            try:
                filter_func, key = await filter.query_parser(key)
                select = filter_func(select, model, key, value)
            except:
                continue

        return select

    def _check_allowed_filter_func(self, request_params: dict) -> Dict[str, str]:
        pram_func = request_params.keys()
        temp_param_func = copy.deepcopy(list(pram_func))

        for condition in temp_param_func:
            if "__" in condition:
                pram, func = condition.split("__")
                # param is not in allowed fields or doesn't allow the method
                if pram not in self.fields.keys() or func not in self.fields[pram]:
                    request_params.pop(condition)

            elif condition in self.fields.keys():
                # if func is exact query but if the func is not allowed
                if "exact" not in self.fields[condition]:
                    request_params.pop(condition)
            # func is exact query but param does not exist on allowed fields
            else:
                request_params.pop(condition)

        return request_params
