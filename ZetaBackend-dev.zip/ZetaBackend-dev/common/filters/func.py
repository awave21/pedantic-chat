from typing import Any, Dict, List, Tuple

from sqlalchemy import func as F
from sqlalchemy.sql import Select

from common.database.base import Base

GT = "gt"
GTE = "gte"
LT = "lt"
LTE = "lte"
STARTSWITH = "startswith"
ISTARTSWITH = "istartswith"
CONTAINS = "contains"
ICONTAINS = "icontains"
ICONTAINS_LIST = "icontains_list"
IN = "in"
EXCLUDE = "exclude"


_INTEGER = ["SMALLINT", "INTEGER", "BIGINT"]
_FLOAT = ["FLOAT", "NUMERIC"]
_STRING = ["VARCHAR", "CHAR", "TEXT"]
_BOOLEAN = ["BOOLEAN"]
_DATETIME = ["DATETIME"]
_DATE = ["DATE"]
_TIME = ["TIME"]


class InvalidType(Exception):
    pass


def join_models(select: Select, list_of_models: List) -> Select:
    for _model in list_of_models:
        select = select.join(_model)
    return select


def _filter_get(select: Select, model: Base, column_name: str, value: str) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column == value)
    elif column_type in _FLOAT:
        select = select.filter(model_column == float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column == bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column == int(value))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter_gte(select: Select, model: Base, column_name: str, value: str) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column >= value)
    elif column_type in _FLOAT:
        select = select.filter(model_column >= float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column >= bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column >= int(value))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter_gt(select: Select, model: Base, column_name: str, value: str) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column > value)
    elif column_type in _FLOAT:
        select = select.filter(model_column > float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column > bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column > int(value))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__lte(select: Select, model: Base, column_name: str, value: str) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column <= value)
    elif column_type in _FLOAT:
        select = select.filter(model_column <= float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column <= bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column <= int(value))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__lt(select: Select, model: Base, column_name: str, value: str) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column < value)
    elif column_type in _FLOAT:
        select = select.filter(model_column < float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column < bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column < int(value))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__startswith(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.like(f"{value}%"))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__istartswith(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.ilike(f"{value}%"))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__icontains(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.ilike(f"%{value}%"))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__contains(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.like(f"%{value}%"))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__in(
    select: Select, model: Base, column_name: str, value_list: List[str]
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.in_(value_list))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__list_in(
    select: Select, model: Base, column_name: str, value_list: List[str]
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column.op("&&")(value_list))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__list_icontains(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(F.array_to_string(model_column, ",").ilike(f"%{value}%"))
    else:
        raise InvalidType("Invalid type")

    return select


def _filter__exclude(
    select: Select, model: Base, column_name: str, value: str
) -> Select:
    model_column = getattr(model, column_name)
    column_type = str(model_column.property.columns[0].type)

    if column_type in _STRING:
        select = select.filter(model_column != value)
    elif column_type in _FLOAT:
        select = select.filter(model_column != float(value))
    elif column_type in _BOOLEAN:
        select = select.filter(model_column != bool(value))
    elif column_type in _INTEGER:
        select = select.filter(model_column != int(value))
    else:
        raise InvalidType("Invalid type")

    return select


# def _filter_array_any(select: Select, model: Base, column_name, value):
#     column_name_map = {
#         'tag_id__in': 'category_tag_ids',
#         'city_id': 'city_ids',
#         'country_id': 'country_ids'
#     }
#     if type(value) == str:
#         values = [int(_v) for _v in value.split(",")]
#     elif type(value) == int:
#         values = [value]
#     else:
#         values = value
#     column_name = column_name_map.get(column_name, column_name)
#     model_column = getattr(model, column_name)
#     _filters = []
#     for i in values:
#         _filters.append(model_column.any(i))
#     select = select.filter(or_(*_filters))
#     return select


# def _filter_date_range(
#     select: Select,
#     model: Base,
#     column_name: str,
#     start: Union[datetime.datetime, datetime.date],
#     end: Union[datetime.datetime, datetime.date]
# ) -> Select:
#     model_column = getattr(model, column_name)
#     column_type = str(model_column.property.columns[0].type)
#
#     if column_type in DATE:
#         select = select.filter(F.date(model_column).between(start, end))
#
#     select = select.filter(F.date(model_column).between(start, end))
#     return select


# TODO: func and check types for date/time types
async def query_parser(request_param_func: str, value: Any = None) -> Tuple:
    filter_function_mapping = {
        GT: _filter_gt,
        GTE: _filter_gte,
        LT: _filter__lt,
        LTE: _filter__lte,
        STARTSWITH: _filter__startswith,
        ISTARTSWITH: _filter__istartswith,
        ICONTAINS: _filter__icontains,
        CONTAINS: _filter__contains,
        IN: _filter__in,
        "&&": _filter__list_in,
        ICONTAINS_LIST: _filter__list_icontains,
        EXCLUDE: _filter__exclude,
        # "range": filter_date_range
    }
    field_func = request_param_func.split("__")

    if len(field_func) == 1:
        # if query string is like "id=1,3,4" -> treat as `in` filtering
        if isinstance(value, list) or value and len(value.split(",")) > 1:
            return _filter__in, field_func[0]
        return _filter_get, field_func[0]

    field, func = field_func
    return filter_function_mapping[func], field
