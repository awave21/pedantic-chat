from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from сonfig import app_settings

SQLALCHEMY_DATABASE_URL = (
    f"postgresql+asyncpg://{app_settings.POSTGRES_USER}:{app_settings.POSTGRES_PASSWORD}@{app_settings.DB_CONTAINER_NAME}:"
    f"{app_settings.PORT_DB}/{app_settings.POSTGRES_DB}"
)


engine = create_async_engine(
    SQLALCHEMY_DATABASE_URL,
    echo=True,
)

async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


def get_db() -> sessionmaker:
    return async_session()
