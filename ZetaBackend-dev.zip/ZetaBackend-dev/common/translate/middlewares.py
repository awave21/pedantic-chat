from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

from common.enums.languages import AccessLanguageEnum


class LanguageMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        lang = request.headers.get("Accept-Language")
        lang = self._check_language(lang)
        request.state.language = lang
        response = await call_next(request)
        response.headers["Content-Language"] = lang
        return response

    @staticmethod
    def _check_language(lang: str) -> str:
        if lang and lang.lower() == AccessLanguageEnum.RU.value:
            return AccessLanguageEnum.RU.value
        else:
            return AccessLanguageEnum.EN.value
