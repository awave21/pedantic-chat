import ast
from enum import Enum
from typing import Optional


class AccessLanguageEnum(Enum):
    EN = "en"
    RU = "ru"


class AbstractLangEnum(Enum):
    def __init__(self, en: str, ru: str) -> None:
        self.en = en
        self.ru = ru

    def translate(self, lang: str) -> str:
        return (
            self.ru if lang and lang.lower() == AccessLanguageEnum.RU.value else self.en
        )

    @property
    def to_str_dict_for_exception(self) -> str:
        dictionary = {
            "en": self.en,
            "ru": self.ru,
        }
        return f"loc{str(dictionary)}"


class ParseLangException(Exception):
    pass


def translate_from_str_exception(string: str, lang: Optional[str] = None) -> str:
    if string.startswith("loc{"):
        dictionary = ast.literal_eval(string[3:])
        return (
            dictionary[AccessLanguageEnum.RU.value]
            if lang == AccessLanguageEnum.RU.value
            else dictionary[AccessLanguageEnum.EN.value]
        )

    raise ParseLangException()
