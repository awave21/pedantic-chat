from common.enums.languages import AbstractLangEnum


class ValidatorsErrorEnum(AbstractLangEnum):
    EMAIL_MUST_BE_STR = "Email must be str", "Почта должна быть строкой"
    EMAIL_NOT_CONTAIN_DOG = (
        "Invalid email: it should contain '@'",
        "Почта должна содержать @",
    )

    PHONE_MUST_BE_STR = "Phone must be str", "Телефон должен быть строкой"
    PHONE_START_PLUS = (
        "Invalid phone number: it should starts from '+'",
        "Неправильный телефон: должен начинаться с +",
    )
    PHONE_ONLY_DIGIT = (
        "Invalid phone number: it should be only digits after plus",
        "Неправильный телефон: должен содержать после + только цифры",
    )

    PHONE_AND_EMAIL_EMPTY = (
        "Phone and email shouldn't be empty",
        "Поля телефона и почты пустые",
    )
    PHONE_AND_EMAIL_AND_NICKNAME_EMPTY = (
        "Phone, email and nickname shouldn't be empty",
        "Поля телефона, почты и никнейма пустые",
    )

    PASSWORDS_EMPTY = "Passwords shouldn't be empty", "Пароли не продоставлены"
    PASSWORDS_NO_EQUAL = "Passwords should be equals", "Пароли не равны"
    PASSWORD_SMALL_LEN = (
        "Passwords should contain minimum 8 symbols",
        "Пароль должен содержать минимум 8 символов",
    )
    PASSWORD_NOT_CONTAIN_DIGIT = (
        "Passwords should contain minimum 1 digit",
        "Пароль должен содержать минимум одну цифру",
    )
    PASSWORD_NOT_CONTAIN_UPPER = (
        "Passwords should contain minimum 1 uppercase symbol",
        "Пароль должен содержать минимум одну заглавную букву",
    )

    FORM_EMPTY = "Form shouldn't be empty", "Форма не может быть пустой"

    NAMES_EMPTY = (
        "All names shouldn't be empty",
        "Поля с именами не должны быть пустыми",
    )
