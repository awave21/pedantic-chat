from common.enums.languages import AbstractLangEnum


class UploaderResponseEnum(AbstractLangEnum):
    NO_IMAGE = "File must be image", "Файл должен быть изображением"
    NO_VIDEO = "File must be video", "Файл должен быть в видео формате"
    NO_IMAGE_OR_VIDEO = (
        "File must be image or video",
        "Файл должен быть изображением или в видео формате",
    )
    UNSUPPORTED_MEDIA_FILE = (
        "Unsuppoted media type",
        "Файл данного формата не поддерживается",
    )
