from typing import Callable, List, Optional

from response_tuples import ResponseCategoryTuple
from sqlalchemy import and_, asc
from sqlalchemy.future import select
from sqlalchemy.orm import aliased, selectinload, sessionmaker

from common.database.models import Category, SubCategory


class CategoriesRepository:
    base_model = Category
    subcategory_model = SubCategory

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_unarchive_subcategories_by_ids(
        self, category_ids: List[int]
    ) -> List[SubCategory]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.subcategory_model).where(
                    and_(
                        self.subcategory_model.id.in_(category_ids),
                        self.subcategory_model.is_archive.is_(False),
                    )
                )
            )
            subcategories = result.scalars().all()
            return subcategories

    async def list_categories(
        self, add_archieved: bool = False
    ) -> ResponseCategoryTuple:
        async with self.get_db() as session:
            if add_archieved:
                result = await session.execute(
                    select(self.base_model)
                    .options(selectinload(self.base_model.subcategories))
                    .order_by(asc(self.base_model.is_archive), asc(self.base_model.id))
                )
            else:
                subcategories = (
                    select(self.subcategory_model)
                    .where(self.subcategory_model.is_archive.is_(False))
                    .subquery()
                )
                sub_alias = aliased(self.subcategory_model, subcategories)
                result = await session.execute(
                    select(self.base_model)
                    .where(self.base_model.is_archive.is_(False))
                    .options(
                        selectinload(self.base_model.subcategories.of_type(sub_alias))
                    )
                    .order_by(asc(self.base_model.is_archive), asc(self.base_model.id))
                )

            categories = result.scalars().all()
            return ResponseCategoryTuple(data=categories)

    async def get_subcategory_by_id(self, subcategory_id: int) -> Optional[SubCategory]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.subcategory_model).where(
                    self.subcategory_model.id == subcategory_id
                )
            )

            subcategory = result.scalars().first()

            return subcategory
