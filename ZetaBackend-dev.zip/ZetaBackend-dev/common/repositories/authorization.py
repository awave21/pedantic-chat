from typing import Callable, Optional

from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import User


class UserAuthorizationRepository:
    base_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_user_by_id(self, id: int) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.id == id)
            )
            user = result.scalars().first()
            return user
