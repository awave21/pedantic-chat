from typing import Any

import jwt
from fastapi import HTTPException, Request, WebSocket, WebSocketException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from common.auth.jwt_handler import AuthHandler, InvalidTypeTokenException, TokenType
from common.db import get_db
from common.repositories.authorization import UserAuthorizationRepository
from common.services.authorization import AuthorizationService


class JWTBearer(HTTPBearer):
    def __init__(
        self,
        auth_handler: AuthHandler,
        token_type: TokenType = TokenType.ACCESS,
        auto_error: bool = True,
        is_admin: bool = False,
    ) -> None:
        super(JWTBearer, self).__init__(auto_error=auto_error)
        self.token_type = token_type
        self.auth_handler = auth_handler
        self.is_admin = is_admin

        self.authorization_service = AuthorizationService(
            UserAuthorizationRepository(get_db)
        )

    async def __call__(
        self, request: Request = None, websocket: WebSocket = None
    ) -> Any:
        """
        Проверяет токен и возвращает в ручку инстанс пользователя
        """
        request = request or websocket
        exception_class = WebSocketException if websocket else HTTPException
        credentials: HTTPAuthorizationCredentials = await super(
            JWTBearer, self
        ).__call__(request)
        if credentials:
            if not credentials.scheme == "Bearer":
                raise exception_class(403, "Invalid authentication scheme.")
            try:
                id = (
                    self.auth_handler.decode_access_token(credentials.credentials)
                    if self.token_type == TokenType.ACCESS
                    else self.auth_handler.decode_refresh_token(credentials.credentials)
                )
            except jwt.ExpiredSignatureError:
                raise exception_class(403, "Signature has expired")
            except (jwt.InvalidTokenError, InvalidTypeTokenException):
                raise exception_class(403, "Invalid token")

            user = await self.authorization_service.get_user_by_id(id)

            if user:
                if self.is_admin and not user.is_admin:
                    raise exception_class(403, "Forbidden")
                if user.is_blocked:
                    raise exception_class(403, "User is blocked")
                return user

            raise exception_class(401, "Forbidden")
        else:
            raise exception_class(403, "Invalid authorization code.")


def get_jwt_bearer(
    auth_handler: AuthHandler,
    token_type: TokenType = TokenType.ACCESS,
    is_admin: bool = False,
) -> JWTBearer:
    return JWTBearer(auth_handler, token_type, is_admin=is_admin)
