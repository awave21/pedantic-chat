from datetime import datetime, timedelta
from enum import Enum
from typing import Dict

import jwt

from common.configs import JWTSettings


class TokenType(Enum):
    ACCESS = "access_token"
    REFRESH = "refresh_token"


class InvalidTypeTokenException(Exception):
    pass


class AuthHandler:
    def __init__(self, settings: JWTSettings) -> None:
        self._access_lifetime_days = settings.JWT_ACCESS_LIFETIME_DAYS
        self._refresh_lifetime_days = settings.JWT_REFRESH_LIFETIME_DAYS
        self._jwt_secret = settings.JWT_SECRET
        self._jwt_algorithm = settings.JWT_ALGORITHM

    def encode_token(self, id: int, type: TokenType) -> str:
        payload = dict(
            id=id,
            type=type.value,
        )

        if type == TokenType.ACCESS:
            payload.update({"exp": datetime.utcnow() + timedelta(days=self._access_lifetime_days)})  # type: ignore
        else:
            payload.update({"exp": datetime.utcnow() + timedelta(days=self._refresh_lifetime_days)})  # type: ignore

        return jwt.encode(payload, self._jwt_secret, algorithm=self._jwt_algorithm)

    def encode_login_token(self, id: int) -> Dict[str, str]:
        access_token = self.encode_token(id, TokenType.ACCESS)
        refresh_token = self.encode_token(id, TokenType.REFRESH)

        return {"access_token": access_token, "refresh_token": refresh_token}

    def encode_update_token(self, id: int) -> Dict[str, str]:
        access_token = self.encode_token(id, TokenType.REFRESH)

        return {"access_token": access_token}

    def decode_access_token(self, token: str) -> int:
        payload = jwt.decode(token, self._jwt_secret, algorithms=[self._jwt_algorithm])
        if payload["type"] != TokenType.ACCESS.value:
            raise InvalidTypeTokenException
        return payload["id"]

    def decode_refresh_token(self, token: str) -> int:
        payload = jwt.decode(token, self._jwt_secret, algorithms=[self._jwt_algorithm])
        if payload["type"] != TokenType.REFRESH.value:
            raise InvalidTypeTokenException
        return payload["id"]
