from typing import Callable, List, Optional

from enums.messages import ChatResponseEnum, MessagesResponseEnum
from response_tuples import ResponseChatTuple, ResponseMessageTuple
from schemas.messages import ChatCreateSchema, ChatEditSchema, MessageCreateSchema
from sqlalchemy import and_, asc, delete, desc, func, insert, or_, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload, sessionmaker
from sqlalchemy.sql.expression import exists

from common.database.models import (
    Attachment,
    Chat,
    ChatsAssociateTable,
    FollowersAssociateTable,
    Message,
    MessagesAssociateTable,
    User,
)


class MessagesRepository:
    base_model = Message
    chat_model = Chat
    chat_user_model = ChatsAssociateTable
    messages_attachment_model = MessagesAssociateTable
    attachment_model = Attachment
    user_model = User
    associated_model = FollowersAssociateTable

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_user_chats(
        self, user_id: int, is_group: bool, page: int, limit: int
    ) -> ResponseChatTuple:
        async with self.get_db() as session:
            where = and_(
                self.chat_user_model.c.user_id.in_((user_id,)),
                self.chat_model.is_group == is_group,
            )
            result = await session.execute(
                select(self.chat_model)
                .join(self.chat_user_model)
                .where(where)
                .limit(limit)
                .offset(page * limit)
                .options(
                    selectinload(self.chat_model.users),
                    selectinload(self.chat_model.avatar),
                )
            )

            result_count = await session.execute(
                select(func.count())
                .select_from(self.chat_model)
                .join(self.chat_user_model)
                .where(where)
            )

            chats = result.scalars().all()
            count = result_count.scalar()

            # TODO: выглядит как bad-practice, но пока лучше ничего не придумал (лучше только сырым запросом сложным)
            for chat in chats:
                chat.last_message = await self._get_chat_last_message(chat.id)
                chat.unread_count = await self._get_unread_count(chat.id, user_id)
                if not chat.is_group:
                    chat.name = (
                        chat.users[1].nickname
                        if chat.users[0].id == user_id
                        else chat.users[0].nickname
                    )
                    chat.avatar_link = (
                        chat.users[1].avatar
                        if chat.users[0].id == user_id
                        else chat.users[0].avatar
                    )

            return ResponseChatTuple(data=(chats, count))

    async def get_chat_messages(
        self, chat_id: int, user_id: int, page: int, limit: int
    ) -> ResponseMessageTuple:
        async with self.get_db() as session:
            where = self.base_model.chat_id == chat_id
            result = await session.execute(
                select(self.base_model)
                .where(where)
                .order_by(self.base_model.created_at.desc())
                .limit(limit)
                .offset(page * limit)
                .options(
                    selectinload(self.base_model.author),
                    selectinload(self.base_model.attachments),
                )
            )
            result_count = await session.execute(
                select(func.count()).select_from(self.base_model).where(where)
            )

            messages = result.scalars().all()
            count = result_count.scalar()
            return ResponseMessageTuple(data=(messages, count))

    async def get_chat(self, chat_id: int, user_id: int) -> ResponseChatTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.chat_model)
                .join(self.chat_user_model)
                .where(self.chat_model.id == chat_id)
                .options(
                    selectinload(self.chat_model.users),
                    selectinload(self.chat_model.avatar),
                    selectinload(self.chat_model.admin),
                )
            )

            chat = result.scalars().first()
            chat.last_message = await self._get_chat_last_message(chat.id)
            chat.unread_count = await self._get_unread_count(chat.id, user_id)
            if not chat.is_group:
                chat.name = (
                    chat.users[1].nickname
                    if chat.users[0].id == user_id
                    else chat.users[0].nickname
                )
                chat.avatar_link = (
                    chat.users[1].avatar
                    if chat.users[0].id == user_id
                    else chat.users[0].avatar
                )
            return ResponseChatTuple(data=chat)

    async def create_chat(
        self, chat_data: ChatCreateSchema, admin_id: int = None
    ) -> ResponseChatTuple:
        async with self.get_db() as session:
            chat = self.chat_model(
                **chat_data.dict(exclude={"users"}), admin_id=admin_id
            )
            try:
                session.add(chat)
                await session.flush()
                await session.execute(
                    insert(self.chat_user_model),
                    [{"user_id": user, "chat_id": chat.id} for user in chat_data.users],
                )
                await session.commit()
            except IntegrityError:
                return ResponseChatTuple(
                    error_code=500, description=ChatResponseEnum.CHAT_NOT_CREATED
                )
            chat.last_message = await self._get_chat_last_message(chat.id)
            return ResponseChatTuple(data=chat)

    async def edit_chat(
        self, chat_id: int, chat_data: ChatEditSchema
    ) -> ResponseChatTuple:
        async with self.get_db() as session:
            try:
                result = await session.execute(
                    update(self.chat_model)
                    .where(self.chat_model.id == chat_id)
                    .values(
                        **chat_data.dict(
                            exclude_unset=True, exclude={"add_users", "remove_users"}
                        )
                    )
                )

                if not result.rowcount:
                    return ResponseChatTuple(
                        error_code=404,
                        description=ChatResponseEnum.CHAT_NOT_FOUND,
                    )

                await session.commit()
            except IntegrityError:
                return ResponseChatTuple(
                    error_code=500, description=ChatResponseEnum.CHAT_NOT_EDITED
                )
            return ResponseChatTuple(data=chat_id)

    async def add_users(self, chat_id: int, users: List[int]) -> int:
        async with self.get_db() as session:
            try:
                result = await session.execute(
                    insert(self.chat_user_model),
                    [{"user_id": user, "chat_id": chat_id} for user in users],
                )
                row_count = result.rowcount
                if not row_count:
                    return ResponseChatTuple(
                        error_code=404,
                        description=ChatResponseEnum.CHAT_NOT_FOUND,
                    )

                await session.commit()
            except IntegrityError:
                return ResponseChatTuple(
                    error_code=500, description=ChatResponseEnum.CHAT_NOT_EDITED
                )
            return row_count

    async def remove_users(self, chat_id: int, users: List[int]):
        async with self.get_db() as session:
            try:
                await session.execute(
                    delete(self.chat_user_model).where(
                        and_(
                            self.chat_user_model.c.user_id.in_(users),
                            self.chat_user_model.c.chat_id == chat_id,
                        )
                    )
                )
                await session.commit()
            except IntegrityError:
                return ResponseChatTuple(
                    error_code=500, description=ChatResponseEnum.CHAT_NOT_EDITED
                )

    async def create_message(
        self, from_id: int, message_data: MessageCreateSchema
    ) -> ResponseMessageTuple:
        async with self.get_db() as session:
            message = self.base_model(
                **message_data.dict(exclude={"user_id", "media"}), from_id=from_id
            )
            try:
                session.add(message)
                await session.flush()
                if message_data.media:
                    await session.execute(
                        insert(self.messages_attachment_model),
                        [
                            {"attachment_id": attachment, "message_id": message.id}
                            for attachment in message_data.media
                        ],
                    )
                await session.commit()
            except IntegrityError:
                return ResponseMessageTuple(
                    error_code=500, description=MessagesResponseEnum.MESSAGE_NOT_CREATED
                )
            return ResponseMessageTuple(data=message)

    async def get_message(self, message_id: int) -> ResponseMessageTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .where(self.base_model.id == message_id)
                .options(
                    selectinload(self.base_model.attachments),
                )
            )

            message = result.scalars().first()

            return ResponseMessageTuple(data=message)

    async def get_private_chat_by_users(self, users: List[int]):
        """user[0] - создающий users[1] - добавляемый"""
        async with self.get_db() as session:
            result = await session.execute(
                select(self.chat_model.id)
                .join(self.chat_user_model)
                .filter(self.chat_user_model.c.user_id == users[0])
            )
            user_chats = result.scalars().all()
            result = await session.execute(
                select(self.chat_model)
                .join(self.chat_user_model)
                .filter(
                    and_(
                        self.chat_model.id.in_(user_chats),
                        self.chat_user_model.c.user_id == users[1],
                        self.chat_model.is_group.is_(False),
                    )
                )
                .options(selectinload(self.chat_model.users))
            )
            chat = result.scalars().first()
            if chat:
                chat.last_message = await self._get_chat_last_message(chat.id)
                chat.unread_count = await self._get_unread_count(chat.id, users[0])
                if not chat.is_group:
                    chat.name = (
                        chat.users[1].nickname
                        if chat.users[0].id == users[0]
                        else chat.users[0].nickname
                    )
            return ResponseChatTuple(data=chat)

    async def _get_chat_last_message(self, chat_id: int) -> Message:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .where(self.base_model.chat_id == chat_id)
                .order_by(self.base_model.created_at.desc())
                .options(
                    selectinload(self.base_model.author),
                    selectinload(self.base_model.attachments),
                )
            )

            message = result.scalars().first()

            return message

    async def _get_unread_count(self, chat_id: int, user_id: int) -> int:
        async with self.get_db() as session:
            result = await session.execute(
                select(func.count())
                .select_from(self.base_model)
                .where(
                    and_(
                        self.base_model.chat_id == chat_id,
                        self.base_model.state == "sent",
                        self.base_model.from_id != user_id,
                    )
                )
            )

            return result.scalar()

    async def _check_attachments(self, media_list: Optional[List[int]]) -> bool:
        if not media_list:
            return True

        if len(media_list) > 10:
            return False

        async with self.get_db() as session:
            result = await session.execute(
                select(self.attachment_model).where(
                    self.attachment_model.id.in_(media_list)
                )
            )

            attachments = result.scalars().all()

        types = set()
        for attachment in attachments:
            types.add(attachment.type)
        if len(types) > 2:
            return False
        if len(types) == 2:
            if "photo" in types and "video" in types:
                return True
            else:
                return False

        return True

    async def _check_allowed_chat(
        self, chat_id: int, user_id: int, admin: bool = False
    ) -> int:
        async with self.get_db() as session:
            if admin:
                result = await session.execute(
                    select(
                        exists(
                            select(self.chat_model).filter(
                                and_(
                                    self.chat_model.id == chat_id,
                                    self.chat_model.admin_id == user_id,
                                )
                            )
                        )
                    )
                )
            else:
                result = await session.execute(
                    select(
                        exists(
                            select(self.chat_user_model).filter(
                                and_(
                                    self.chat_user_model.c.chat_id == chat_id,
                                    self.chat_user_model.c.user_id == user_id,
                                )
                            )
                        )
                    )
                )

            return result.scalar()

    async def _check_public_chat(self, chat_id: int) -> int:
        async with self.get_db() as session:
            result = await session.execute(
                select(
                    exists(
                        select(self.chat_model).filter(
                            and_(
                                self.chat_model.id == chat_id,
                                self.chat_model.is_public.is_(True),
                            )
                        )
                    )
                )
            )

            return result.scalar()

    async def search_chats_by_name(
        self, search_string: str, user_id: int, page: int, limit: int
    ) -> ResponseChatTuple:
        async with self.get_db() as session:
            where_expr = and_(
                or_(
                    self.chat_model.is_public.is_(True),
                    self.chat_user_model.c.user_id.in_((user_id,)),
                ),
                self.chat_model.is_group.is_(True),
                func.lower(self.chat_model.name).startswith(search_string.lower()),
            )
            result = await session.execute(
                select(self.chat_model)
                .distinct(self.chat_model.id)
                .join(self.chat_user_model)
                .where(where_expr)
                .order_by(asc(self.chat_model.id), asc(self.chat_model.name))
                .limit(limit)
                .offset(page * limit)
                .options(
                    selectinload(self.chat_model.users),
                    selectinload(self.chat_model.avatar),
                )
            )
            chats = result.scalars().all()
            for chat in chats:
                chat.last_message = await self._get_chat_last_message(chat.id)
                chat.is_member = await self._check_allowed_chat(chat.id, user_id)
            count = len(chats)
            return ResponseChatTuple(data=(chats, count))

    async def search_private_chats_by_name(
        self, search_string: str, user_id: int, page: int, limit: int
    ) -> ResponseChatTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.user_model)
                .join(
                    self.associated_model,
                    or_(
                        self.associated_model.c.follower_id == self.user_model.id,
                        self.associated_model.c.following_id == self.user_model.id,
                    ),
                )
                .where(
                    and_(
                        or_(
                            self.associated_model.c.following_id == user_id,
                            self.associated_model.c.follower_id == user_id,
                        ),
                        func.lower(self.user_model.nickname).startswith(
                            search_string.lower()
                        ),
                    )
                )
            )

            followers = result.scalars().all()
            followers_list = [follower.id for follower in followers]

            where = and_(
                self.chat_user_model.c.user_id.in_((user_id,)),
                self.chat_model.is_group.is_(False),
            )
            result = await session.execute(
                select(self.chat_model.id).join(self.chat_user_model).where(where)
            )
            chats = result.scalars().all()

            where_expr = and_(
                self.chat_model.id.in_(chats),
                self.chat_user_model.c.user_id.in_(followers_list),
            )
            result = await session.execute(
                select(self.chat_model)
                .join(self.chat_user_model)
                .distinct(self.chat_model.id)
                .where(where_expr)
                .order_by(asc(self.chat_model.id), asc(self.chat_model.name))
                .limit(limit)
                .offset(page * limit)
                .options(
                    selectinload(self.chat_model.users),
                    selectinload(self.chat_model.avatar),
                )
            )
            chats = result.scalars().all()
            for chat in chats:
                chat.last_message = await self._get_chat_last_message(chat.id)
                chat.is_member = await self._check_allowed_chat(chat.id, user_id)
                chat.name = (
                    chat.users[1].nickname
                    if chat.users[0].id == user_id
                    else chat.users[0].nickname
                )
                chat.avatar_link = (
                    chat.users[1].avatar
                    if chat.users[0].id == user_id
                    else chat.users[0].avatar
                )
            count = len(chats)
            return ResponseChatTuple(data=[(chats, followers), count])

    async def read_messages(self, chat_id: int, user_id: int) -> ResponseChatTuple:
        async with self.get_db() as session:
            try:
                result = await session.execute(
                    update(self.base_model)
                    .where(
                        and_(
                            self.base_model.chat_id == chat_id,
                            self.base_model.from_id != user_id,
                        )
                    )
                    .values(state="read")
                )
                count = result.rowcount
                await session.commit()
            except IntegrityError:
                return ResponseChatTuple(
                    error_code=500, description=MessagesResponseEnum.MESSAGES_NOT_READ
                )
            return ResponseChatTuple(data=count)
