from repositories.messages import MessagesRepository
from services.messages import MessagesService
from services.ws import WebsocketService

from common.db import get_db

messages_repository = MessagesRepository(get_db)
ws_service = WebsocketService()
messages_service = MessagesService(messages_repository, ws_service)


async def get_messages_service() -> MessagesService:
    return messages_service


async def get_ws_service() -> WebsocketService:
    return ws_service
