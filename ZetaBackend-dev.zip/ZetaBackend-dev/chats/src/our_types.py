from dataclasses import dataclass
from typing import List

from common.database.models import User


@dataclass
class FollowersWithCount:
    count: int
    followers: List[User]
