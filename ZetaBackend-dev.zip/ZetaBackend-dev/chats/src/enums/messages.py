from enum import Enum

from common.enums.languages import AbstractLangEnum


class ChatResponseEnum(AbstractLangEnum):
    INVALID_USERS = (
        "You must add at least one user",
        "Вы должны добавить как минимум одного пользователя",
    )
    INVALID_USERS_PRIVATE = (
        "You can only add one user to a private chat",
        "Вы можете добавить только одного пользователя в личную переписку",
    )
    INVALID_CHAT_NAME = (
        "Invalid chat name",
        "Неверное имя чата",
    )
    CHAT_NOT_CREATED = ("Failed to create chat", "Не удалось создать чат")
    CHAT_NOT_EDITED = ("Failed to edit chat", "Не удалось обновить чат")
    CHAT_NOT_FOUND = ("Chat not found", "Чат не найден")
    FORBIDDEN = (
        "You have no access to edit this chat",
        "У вас нет доступа для изменения данного чата",
    )
    FORBIDDEN_JOIN = (
        "You have no access to join this chat",
        "У вас нет доступа для вступления в данный чат",
    )
    ILLEGAL_SELF_REMOVE = (
        "You can't leave from chat if you are admin",
        "Вы не можете выйти из чата будучи администатором",
    )


class MessagesResponseEnum(AbstractLangEnum):
    FORBIDDEN = (
        "You have no access to this chat",
        "У вас нет доступа к данной переписке",
    )
    CHAT_NOT_FOUND = ("Chat not found", "Переписка не найдена")
    MESSAGE_NOT_CREATED = ("Failed to create message", "Не удалось создать сообщение")
    CHAT_ID_EXPECTED = ("chat_id or user_id expected", "Ожидается chat_id или user_id")
    INVALID_MEDIA_LIST = ("Invalid media list", "Недопустимый список медиафайлов")
    INVALID_MEDIA_LIST_LENGTH = (
        "Invalid media list length (>10)",
        "Невозможно прикрепить более 10 медиафайлов",
    )
    MESSAGES_NOT_READ = (
        "Failed to update messages state",
        "Ошибка при обновлении состояния прочитанности сообщений",
    )


class SearchChatEnum(Enum):
    ANY = "any"
    GROUP = "group"
    PRIVATE = "private"
