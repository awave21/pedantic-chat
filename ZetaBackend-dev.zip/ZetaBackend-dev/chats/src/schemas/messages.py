from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, root_validator

from common.database.models import Chat, Message, User
from common.enums.validators import ValidatorsErrorEnum
from common.schemas.chats import ChatAvatar
from common.schemas.common import Page
from common.schemas.users import ShortPersonProfile


class AttachmentSchema(BaseModel):
    id: int
    type: Optional[str]
    url: Optional[str]

    class Config:
        orm_mode = True


class MessageSchema(BaseModel):
    id: int
    created_at: datetime
    from_id: int
    chat_id: int
    text: Optional[str]
    state: str
    attachments: Optional[List["AttachmentSchema"]]
    type: Optional[str]

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Message) -> BaseModel:
        MessageSchema.update_forward_refs()
        schema: BaseModel = super().from_orm(obj)
        if obj.attachments:
            types_dict = {
                "photo": "media",
                "video": "media",
                "audio": "audio",
                "document": "document",
            }
            schema.type = types_dict[obj.attachments[0].type]
        else:
            schema.type = "text"
        return schema


class LastMessageSchema(BaseModel):
    id: int
    created_at: datetime
    author: "ShortPersonProfile"
    text: Optional[str]
    state: str
    attachments: Optional[List["AttachmentSchema"]]
    type: Optional[str]

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Message) -> BaseModel:
        LastMessageSchema.update_forward_refs()
        schema: BaseModel = super().from_orm(obj)
        if obj.attachments:
            types_dict = {
                "photo": "media",
                "video": "media",
                "audio": "audio",
                "document": "document",
            }
            schema.type = types_dict[obj.attachments[0].type]
        else:
            schema.type = "text"
        return schema


class ChatSchema(BaseModel):
    id: Optional[int]
    user_id: Optional[int]
    is_group: bool
    name: Optional[str]
    avatar: Optional[ChatAvatar]
    unread_count: Optional[int]
    last_message: Optional["LastMessageSchema"]
    is_member: bool = True

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Chat) -> BaseModel:
        ChatSchema.update_forward_refs()
        schema: BaseModel = super().from_orm(obj)
        if hasattr(obj, "avatar_link"):
            if obj.avatar_link:
                schema.avatar = ChatAvatar(link=obj.avatar_link)
            else:
                schema.avatar = None
        if hasattr(obj, "last_message"):
            if obj.last_message:
                schema.last_message = LastMessageSchema.from_orm(obj.last_message)
        if len(obj.users) == 1:
            schema.user_id = obj.users[0].id
        return schema


class ChatDetailSchema(BaseModel):
    id: int
    is_group: bool
    name: Optional[str]
    avatar: Optional[ChatAvatar]
    users: List["ShortPersonProfile"]
    admin: Optional["ShortPersonProfile"]
    unread_count: Optional[int]
    last_message: Optional["LastMessageSchema"]
    is_public: bool

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Chat) -> BaseModel:
        ChatSchema.update_forward_refs()
        schema: BaseModel = super().from_orm(obj)
        schema.users = [ShortPersonProfile.from_orm(i) for i in obj.users]
        if hasattr(obj, "avatar_link"):
            if obj.avatar_link:
                schema.avatar = ChatAvatar(link=obj.avatar_link)
            else:
                schema.avatar = None
        if obj.last_message:
            schema.last_message = LastMessageSchema.from_orm(obj.last_message)
        return schema


class ChatsPage(Page):
    data: List[ChatSchema] = []


class ChatsSearchPage(BaseModel):
    group: ChatsPage = None
    private: ChatsPage = None


class MessagesPage(Page):
    data: List[MessageSchema] = []


class ChatCreateSchema(BaseModel):
    is_group: bool = True
    is_public: bool = False
    users: List[int]
    name: Optional[str]
    avatar_id: Optional[int]


class ChatEditSchema(BaseModel):
    name: Optional[str]
    avatar_id: Optional[int]
    is_public: Optional[bool]
    add_users: Optional[List[int]]
    remove_users: Optional[List[int]]


class ChatJoinSchema(BaseModel):
    chat_id: int


class MessageCreateSchema(BaseModel):
    chat_id: Optional[int]
    user_id: Optional[int]
    text: Optional[str]
    media: Optional[List[int]]
