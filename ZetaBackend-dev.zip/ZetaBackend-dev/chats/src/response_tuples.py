from typing import List, NamedTuple, Optional, Tuple, Union

from enums.messages import ChatResponseEnum, MessagesResponseEnum

from common.database.models import Chat, Message


class ResponseChatTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[ChatResponseEnum] = None
    data: Tuple[List[Chat], int] = [], 0


class ResponseMessageTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[MessagesResponseEnum] = None
    data: Tuple[List[Message], int] = [], 0
