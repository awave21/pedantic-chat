from typing import Dict

from depends import get_messages_service
from enums.messages import SearchChatEnum
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from fastapi.encoders import jsonable_encoder
from schemas.messages import (
    ChatCreateSchema,
    ChatDetailSchema,
    ChatEditSchema,
    ChatJoinSchema,
    ChatSchema,
    ChatsPage,
    ChatsSearchPage,
    MessageCreateSchema,
    MessageSchema,
    MessagesPage,
)
from services.messages import MessagesService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User

router = APIRouter(tags=["messages"])


@router.get(
    "",
    response_model=ChatsPage,
    status_code=200,
    description="""Список чатов""",
)
async def get_user_chats(
    request: Request,
    is_group: bool = Query(True),
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.get_user_chats(user.id, is_group, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    chats = [ChatSchema.from_orm(chat) for chat in result.data[0]]

    return JSONResponse(
        jsonable_encoder(
            ChatsPage(page=page, limit=limit, data=chats, count=result.data[1])
        ),
        status_code=200,
    )


@router.get(
    "/search",
    response_model=ChatsSearchPage,
    status_code=200,
    description="""Поиск публичных чатов по названию""",
)
async def search_chats_by_name(
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
    fetch: SearchChatEnum = Query(default=SearchChatEnum.ANY, alias="type"),
    name: str = Query(...),
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=2),
) -> JSONResponse:
    if fetch == SearchChatEnum.ANY:
        limit = 3
        group_result = await messages_service.search_chats_by_name(
            name, user.id, page, limit
        )
        group_chats = [ChatSchema.from_orm(chat) for chat in group_result.data[0]]
        group_chats_page = ChatsPage(
            page=page, limit=limit, data=group_chats, count=group_result.data[1]
        )

        private_result = await messages_service.search_private_chats_by_name(
            name, user.id, page, limit
        )
        private_chats = [
            ChatSchema.from_orm(chat) for chat in private_result.data[0][0]
        ]
        private_chats_page = ChatsPage(
            page=page, limit=limit, data=private_chats, count=private_result.data[1]
        )

        return ChatsSearchPage(group=group_chats_page, private=private_chats_page)

    elif fetch == SearchChatEnum.GROUP:
        group_result = await messages_service.search_chats_by_name(
            name, user.id, page, limit
        )
        group_chats = [ChatSchema.from_orm(chat) for chat in group_result.data[0]]
        group_chats_page = ChatsPage(
            page=page, limit=limit, data=group_chats, count=group_result.data[1]
        )

        return ChatsSearchPage(group=group_chats_page)

    elif fetch == SearchChatEnum.PRIVATE:
        private_result = await messages_service.search_private_chats_by_name(
            name, user.id, page, limit
        )
        private_chats = [
            ChatSchema.from_orm(chat) for chat in private_result.data[0][0]
        ]
        private_chats_page = ChatsPage(
            page=page, limit=limit, data=private_chats, count=private_result.data[1]
        )

        return ChatsSearchPage(private=private_chats_page)

    return ChatsSearchPage()


@router.post(
    "/join",
    response_model=ChatDetailSchema,
    status_code=200,
    description="""Вступление в публичный чат""",
)
async def join_chat(
    request: Request,
    chat_data: ChatJoinSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.join_chat(user.id, chat_data.chat_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    chat = ChatDetailSchema.from_orm(result.data)
    return JSONResponse(
        jsonable_encoder(chat),
        status_code=200,
    )


@router.post(
    "/leave",
    response_model=Dict,
    status_code=200,
    description="""Выход из чата""",
)
async def leave_chat(
    request: Request,
    chat_data: ChatJoinSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.leave_chat(user.id, chat_data.chat_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(
        result.data,
        status_code=200,
    )


@router.get(
    "/{chat_id}",
    response_model=ChatDetailSchema,
    status_code=200,
    description="""Деталка чата (информация о чате, участниках)""",
)
async def get_chat(
    request: Request,
    chat_id: int,
    is_user: bool = Query(False),
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    if not is_user:
        result = await messages_service.get_chat(chat_id, user.id)
    else:
        result = await messages_service.get_chat_by_user_id(chat_id, user.id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    chat = ChatDetailSchema.from_orm(result.data)

    return chat


@router.get(
    "/messages/{chat_id}",
    response_model=MessagesPage,
    status_code=200,
    description="""Список сообщений чата""",
)
async def get_chat_messages(
    request: Request,
    chat_id: int,
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.get_chat_messages(chat_id, user.id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    messages = [MessageSchema.from_orm(message) for message in result.data[0]]

    return JSONResponse(
        jsonable_encoder(
            MessagesPage(page=page, limit=limit, data=messages, count=result.data[1])
        ),
        status_code=200,
    )


@router.post(
    "",
    response_model=ChatDetailSchema,
    status_code=201,
    description="""Создание чата""",
)
async def create_chat(
    request: Request,
    chat_data: ChatCreateSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.create_chat(user.id, chat_data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    chat = ChatDetailSchema.from_orm(result.data)
    return JSONResponse(
        jsonable_encoder(chat),
        status_code=201,
    )


@router.patch(
    "/{chat_id}",
    response_model=ChatDetailSchema,
    status_code=200,
    description="""Изменение чата""",
)
async def edit_chat(
    request: Request,
    chat_id: int,
    chat_data: ChatEditSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.edit_chat(user.id, chat_id, chat_data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    chat = ChatDetailSchema.from_orm(result.data)
    return JSONResponse(
        jsonable_encoder(chat),
        status_code=200,
    )


@router.post(
    "/messages",
    response_model=Dict,
    status_code=201,
    description="""Отправка сообщения""",
)
async def send_message(
    request: Request,
    message_data: MessageCreateSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.create_message(user.id, message_data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return MessageSchema.from_orm(result.data).dict()


@router.get(
    "/{chat_id}/read",
    response_model=Dict,
    status_code=200,
    description="""Деталка чата (информация о чате, участниках)""",
)
async def read_messages(
    request: Request,
    chat_id: int,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    messages_service: MessagesService = Depends(get_messages_service),
) -> JSONResponse:

    result = await messages_service.read_messages(chat_id, user.id)

    return JSONResponse(
        result.data,
        status_code=200,
    )
