import json
from functools import partial
from typing import Dict, List

import aiohttp
import requests
from сonfig import app_settings


class WebsocketService:
    def __init__(self):
        pass

    async def push_message(self, event: str, users: List[int], data: Dict):
        event_data = {"event": event, "user_ids": users, "data": data}
        async with aiohttp.ClientSession(
            json_serialize=partial(json.dumps, default=str)
        ) as session:
            url = f"http://{app_settings.WS_CONTAINER_NAME}:{app_settings.PORT_WS}/ws/event"
            async with session.post(url, json=event_data) as resp:
                await resp.json()
