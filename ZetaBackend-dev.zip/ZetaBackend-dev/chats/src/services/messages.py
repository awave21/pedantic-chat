import asyncio
from typing import Dict, List, Optional

from fastapi import BackgroundTasks
from repositories.messages import MessagesRepository
from response_tuples import (
    ChatResponseEnum,
    MessagesResponseEnum,
    ResponseChatTuple,
    ResponseMessageTuple,
)
from schemas.messages import (
    ChatCreateSchema,
    ChatDetailSchema,
    ChatEditSchema,
    MessageCreateSchema,
)
from services.ws import WebsocketService

from common.database.models import Chat


class MessagesService:
    def __init__(
        self, messages_repository: MessagesRepository, ws_service: WebsocketService
    ):
        self.messages_repository = messages_repository
        self.ws_service = ws_service

    async def get_user_chats(
        self, user_id: int, is_group: bool, page: int, limit: int
    ) -> ResponseChatTuple:
        return await self.messages_repository.get_user_chats(
            user_id, is_group, page, limit
        )

    async def get_chat(self, chat_id: int, user_id: int) -> ResponseChatTuple:
        if not await self.messages_repository._check_public_chat(chat_id):
            if not await self.messages_repository._check_allowed_chat(chat_id, user_id):
                return ResponseMessageTuple(
                    error_code=403, description=MessagesResponseEnum.FORBIDDEN
                )
        return await self.messages_repository.get_chat(chat_id, user_id)

    async def get_chat_by_user_id(
        self, user_id: int, sender_id: int
    ) -> ResponseChatTuple:
        chat = await self.messages_repository.get_private_chat_by_users(
            [sender_id, user_id]
        )
        if not chat.data:
            chat = await self.messages_repository.create_chat(
                ChatCreateSchema(is_group=False, users=[sender_id, user_id])
            )
        return chat

    async def get_chat_messages(
        self, chat_id: int, user_id: int, page: int, limit: int
    ) -> ResponseMessageTuple:
        if not await self.messages_repository._check_public_chat(chat_id):
            if not await self.messages_repository._check_allowed_chat(chat_id, user_id):
                return ResponseMessageTuple(
                    error_code=403, description=MessagesResponseEnum.FORBIDDEN
                )
        return await self.messages_repository.get_chat_messages(
            chat_id, user_id, page, limit
        )

    async def create_chat(
        self, user_id: int, chat_data: ChatCreateSchema
    ) -> ResponseChatTuple:
        if user_id not in chat_data.users:
            chat_data.users.append(user_id)

        if len(chat_data.users) < 2:
            return ResponseChatTuple(
                error_code=400, description=ChatResponseEnum.INVALID_USERS
            )
        if not chat_data.is_group:
            if len(chat_data.users) != 2:
                return ResponseChatTuple(
                    error_code=400, description=ChatResponseEnum.INVALID_USERS_PRIVATE
                )
            chat_data.name = None
            chat_data.avatar = None
            admin = None
        else:
            if not chat_data.name:
                return ResponseChatTuple(
                    error_code=400, description=ChatResponseEnum.INVALID_CHAT_NAME
                )
            admin = user_id
        result = await self.messages_repository.create_chat(chat_data, admin_id=admin)
        return await self.messages_repository.get_chat(result.data.id, user_id)

    async def edit_chat(
        self, user_id: int, chat_id: int, chat_data: ChatEditSchema
    ) -> ResponseChatTuple:
        if not await self.messages_repository._check_allowed_chat(
            chat_id, user_id, admin=True
        ):
            return ResponseChatTuple(
                error_code=403, description=ChatResponseEnum.FORBIDDEN
            )
        result = await self.messages_repository.edit_chat(chat_id, chat_data)
        if result.error_code:
            return result
        if chat_data.add_users:
            await self.messages_repository.add_users(chat_id, chat_data.add_users)
        if chat_data.remove_users:
            if user_id in chat_data.remove_users:
                return ResponseChatTuple(
                    error_code=400, description=ChatResponseEnum.ILLEGAL_SELF_REMOVE
                )
            await self.messages_repository.remove_users(chat_id, chat_data.remove_users)
        return await self.messages_repository.get_chat(result.data, user_id)

    async def create_message(
        self, user_id: int, message_data: MessageCreateSchema
    ) -> ResponseMessageTuple:
        if message_data.user_id:
            chat = (
                await self.messages_repository.get_private_chat_by_users(
                    [user_id, message_data.user_id]
                )
            ).data
            if not chat:
                chat = (
                    await self.messages_repository.create_chat(
                        ChatCreateSchema(
                            is_group=False, users=[user_id, message_data.user_id]
                        )
                    )
                ).data
            message_data.chat_id = chat.id
        if not message_data.chat_id:
            return ResponseMessageTuple(
                error_code=400, description=MessagesResponseEnum.CHAT_ID_EXPECTED
            )
        if not await self.messages_repository._check_allowed_chat(
            message_data.chat_id, user_id
        ):
            return ResponseMessageTuple(
                error_code=403, description=MessagesResponseEnum.FORBIDDEN
            )
        if not await self.messages_repository._check_attachments(message_data.media):
            return ResponseMessageTuple(
                error_code=400, description=MessagesResponseEnum.INVALID_MEDIA_LIST
            )
        result = await self.messages_repository.create_message(user_id, message_data)
        result = await self.messages_repository.get_message(result.data.id)

        # Отправка в сокет
        loop = asyncio.get_event_loop()
        chat = (
            await self.messages_repository.get_chat(result.data.chat_id, user_id)
        ).data

        loop.create_task(
            self.send_to_ws(
                [user_id], "new_message", ChatDetailSchema.from_orm(chat).dict()
            )
        )

        users_receive = [user.id for user in chat.users]
        users_receive.pop(users_receive.index(user_id))
        chat = (
            await self.messages_repository.get_chat(
                result.data.chat_id, users_receive[0]
            )
        ).data

        loop.create_task(
            self.send_to_ws(
                users_receive, "new_message", ChatDetailSchema.from_orm(chat).dict()
            )
        )

        return result

    async def search_chats_by_name(
        self, name: str, user_id: int, page: int, limit: int
    ) -> ResponseChatTuple:
        result = await self.messages_repository.search_chats_by_name(
            name, user_id, page, limit
        )
        return result

    async def search_private_chats_by_name(
        self, name: str, user_id: int, page: int, limit: int
    ) -> ResponseChatTuple:
        result = await self.messages_repository.search_private_chats_by_name(
            name, user_id, page, limit
        )
        for user in result.data[0][1]:
            need_append = True
            for chat in result.data[0][0]:
                for chat_user in chat.users:
                    if user.id == chat_user.id:
                        need_append = False
                        break
                if not need_append:
                    break
            if need_append:
                not_created_chat = Chat(
                    is_group=False,
                    name=user.nickname,
                    users=[user],
                )
                not_created_chat.avatar_link = user.avatar
                result.data[0][0].append(not_created_chat)
        result.data[1] = len(result.data[0][0])
        return result

    async def join_chat(self, user_id: int, chat_id: int) -> ResponseChatTuple:
        if not await self.messages_repository._check_public_chat(chat_id):
            return ResponseChatTuple(
                error_code=403, description=ChatResponseEnum.FORBIDDEN_JOIN
            )
        await self.messages_repository.add_users(chat_id=chat_id, users=[user_id])
        return await self.messages_repository.get_chat(chat_id, user_id)

    async def leave_chat(self, user_id: int, chat_id: int) -> ResponseChatTuple:
        if await self.messages_repository._check_allowed_chat(
            chat_id, user_id, admin=True
        ):
            return ResponseChatTuple(
                error_code=403, description=ChatResponseEnum.ILLEGAL_SELF_REMOVE
            )
        await self.messages_repository.remove_users(chat_id=chat_id, users=[user_id])
        return ResponseChatTuple(data={"result": "ok"})

    async def read_messages(self, chat_id: int, user_id: int) -> ResponseChatTuple:
        if not await self.messages_repository._check_allowed_chat(chat_id, user_id):
            return ResponseMessageTuple(
                error_code=403, description=MessagesResponseEnum.FORBIDDEN
            )
        count = await self.messages_repository.read_messages(
            chat_id=chat_id, user_id=user_id
        )

        chat = (await self.messages_repository.get_chat(chat_id, user_id)).data
        users_receive = [user.id for user in chat.users]
        loop = asyncio.get_event_loop()
        loop.create_task(
            self.send_to_ws(users_receive, "read_messages", {"chat_id": chat_id})
        )
        # await self.ws_service.push_message(
        #     event="read_messages", users=users_receive, data={"chat_id": chat_id}
        # )

        return ResponseChatTuple(data={"result": count.data})

    async def send_to_ws(self, users_receive: List[int], event: str, data: dict):
        await self.ws_service.push_message(
            event=event,
            users=users_receive,
            data=data,
        )
