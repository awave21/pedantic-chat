from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from routing import messages
from сonfig import app_settings

from common.translate.handlers import validation_exception_translate_handler
from common.translate.middlewares import LanguageMiddleware

app = FastAPI(
    debug=app_settings.DEBUG, openapi_url="/chats/openapi.json", docs_url="/chats/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LanguageMiddleware)

app.add_exception_handler(
    RequestValidationError, validation_exception_translate_handler
)

app.include_router(messages.router, prefix="/chats")
