from dataclasses import dataclass

from fastapi import UploadFile


@dataclass
class NetworkUploadFile:
    file: UploadFile
    auth_header: str
