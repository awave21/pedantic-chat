from typing import List

from repositories.docs import DocsRepository
from response_tuples import ResponseDocTuple
from schemas.docs import DocScheme

from common.db import get_db


class DocsService:
    def __init__(self, docs_repository: DocsRepository):
        self.docs_repository = docs_repository

    async def get_all_docs(self) -> ResponseDocTuple:
        return await self.docs_repository.get_all_docs()

    async def get_doc(self, doc_id: int) -> ResponseDocTuple:
        return await self.docs_repository.get_doc(doc_id=doc_id)

    async def create_doc(self, data: DocScheme) -> ResponseDocTuple:
        return await self.docs_repository.create_doc(data=data)

    async def update_doc(self, doc_id: int, data: DocScheme) -> ResponseDocTuple:
        return await self.docs_repository.update_doc(doc_id=doc_id, data=data)

    async def delete_doc(self, doc_id: int) -> ResponseDocTuple:
        return await self.docs_repository.delete_doc(doc_id=doc_id)


docs_service = DocsService(DocsRepository(get_db))


async def get_docs_service() -> DocsService:
    return docs_service
