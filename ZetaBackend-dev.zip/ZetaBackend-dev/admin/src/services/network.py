import io
from typing import Optional

import aiohttp
from aiohttp import FormData
from our_types import NetworkUploadFile
from response_tuples import ResponseNetworkUploadTuple
from сonfig import NetworkSettings


class NetworkService:
    def __init__(self, network_service: NetworkSettings) -> None:
        self._uploader_url = f"http://{network_service.UPLOADER_CONTAINER_NAME}:{network_service.PORT_UPLOADER}"
        self._upload_subcategory_icon_link = (
            "/uploader/categories/upload-subcategory-icon"
        )

    async def upload_subcategory_icon(
        self,
        upload_data: NetworkUploadFile,
        old_icon_link: Optional[str] = None,
    ) -> ResponseNetworkUploadTuple:
        """
        Обновляет картинку подкатегории, обращаясь по htpp с сервисы аплоадера.
        old_icon_link - ссылка на старую картинку подкатегории для её удаления с хранилки
        """

        # Формируем url, from-data, headers
        url = f"{self._uploader_url}{self._upload_subcategory_icon_link}"
        headers = {
            "authorization": upload_data.auth_header,
        }
        data = FormData()
        data.add_field(
            "file",
            io.BytesIO(await upload_data.file.read()),
            filename=upload_data.file.filename,
            content_type=upload_data.file.content_type,
        )
        if old_icon_link:
            data.add_field("old_icon_link", old_icon_link)

        # Обращаемся к аплоадеру
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, data=data) as response:
                result = await response.json()
                if response.ok:
                    return ResponseNetworkUploadTuple(link=result.get("link"))
                else:
                    return ResponseNetworkUploadTuple(
                        error_code=response.status, description=result.get("detail")
                    )
