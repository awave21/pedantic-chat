from typing import Optional

from our_types import NetworkUploadFile
from repositories.categories import CategoriesAdminRepository
from response_tuples import ResponseCategoryTuple, ResponseSubCategoryTuple
from schemas.categories import (
    CategoryCreateSchema,
    CategoryUpdateSchema,
    SubCategoryCreateSchema,
    SubCategoryUpdateSchema,
)
from services.network import NetworkService


class CategoriesService:
    def __init__(
        self,
        categories_repository: CategoriesAdminRepository,
        network_service: NetworkService,
    ):
        self.categories_repository = categories_repository
        self.network_service = network_service

    async def list_categories(self) -> ResponseCategoryTuple:
        return await self.categories_repository.list_categories(add_archieved=True)

    async def create_category(
        self, data: CategoryCreateSchema
    ) -> ResponseCategoryTuple:
        return await self.categories_repository.create_category(data=data)

    async def update_category(
        self, category_id: int, data: CategoryUpdateSchema
    ) -> ResponseCategoryTuple:
        return await self.categories_repository.update_category(
            category_id=category_id, data=data
        )

    async def archive_category(self, category_id: int) -> ResponseCategoryTuple:
        return await self.categories_repository.archive_category(
            category_id=category_id
        )

    async def unarchive_category(self, category_id: int) -> ResponseCategoryTuple:
        return await self.categories_repository.unarchive_category(
            category_id=category_id
        )

    async def create_subcategory(
        self, data: SubCategoryCreateSchema, upload_data: NetworkUploadFile
    ) -> ResponseSubCategoryTuple:
        result = await self.network_service.upload_subcategory_icon(
            upload_data=upload_data
        )

        if result.error_code:
            return ResponseSubCategoryTuple(
                error_code=result.error_code, description=result.description
            )

        data.icon = result.link
        return await self.categories_repository.create_subcategory(data=data)

    async def update_subcategory(
        self,
        subcategory_id: int,
        data: SubCategoryUpdateSchema,
        upload_data: Optional[NetworkUploadFile] = None,
    ) -> ResponseSubCategoryTuple:
        subcategory = await self.categories_repository.get_subcategory_by_id(
            subcategory_id
        )

        if not subcategory:
            return ResponseSubCategoryTuple(
                error_code=404, description="Subcategory not found"
            )

        # Если есть картинка в запросе, отправляем её аплоадеру
        if upload_data:
            result = await self.network_service.upload_subcategory_icon(
                upload_data=upload_data, old_icon_link=subcategory.icon
            )

            if result.error_code:
                return ResponseSubCategoryTuple(
                    error_code=result.error_code, description=result.description
                )

            data.icon = result.link

        return await self.categories_repository.update_subcategory(
            subcategory_id=subcategory_id, data=data
        )

    async def archive_subcategory(
        self, subcategory_id: int
    ) -> ResponseSubCategoryTuple:
        return await self.categories_repository.archive_subcategory(
            subcategory_id=subcategory_id
        )

    async def unarchive_subcategory(
        self, subcategory_id: int
    ) -> ResponseSubCategoryTuple:
        return await self.categories_repository.unarchive_subcategory(
            subcategory_id=subcategory_id
        )
