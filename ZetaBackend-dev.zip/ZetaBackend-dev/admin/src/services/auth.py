from typing import Union

import bcrypt
from repositories.users import UserRepository
from response_tuples import ResponseJWTTuple, ResponseUserTuple
from сonfig import auth_handler


class AuthService:
    def __init__(
        self,
        user_repository: UserRepository,
    ):
        self.user_repository = user_repository

    async def login_user(
        self, user_login: str, password: str
    ) -> Union[ResponseUserTuple, ResponseJWTTuple]:
        user = await self.user_repository.get_user_by_nickname(user_login)
        if not user:
            return ResponseUserTuple(error_code=400, description="Bad credentials")

        if user.is_blocked:
            return ResponseUserTuple(error_code=403, description="User is blocked")

        if not user.is_admin:
            return ResponseUserTuple(error_code=403, description="Forbidden")

        if not bcrypt.checkpw(bytes(password, "utf-8"), bytes(user.password, "utf-8")):
            return ResponseUserTuple(error_code=400, description="Bad credentials")

        payload = auth_handler.encode_login_token(id=user.id)
        return ResponseJWTTuple(data=payload)

    @staticmethod
    async def refresh_token(user_id: int) -> ResponseJWTTuple:
        payload = auth_handler.encode_login_token(id=user_id)
        return ResponseJWTTuple(data=payload)
