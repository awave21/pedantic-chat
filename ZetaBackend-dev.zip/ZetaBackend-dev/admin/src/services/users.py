from typing import Optional

from filters import UserListFilter
from repositories.users import UserRepository
from response_tuples import ResponseUserTuple

from common.database.models import User


class UserService:
    def __init__(self, user_repository: UserRepository) -> None:
        self.user_repository = user_repository

    async def get_all_users(
        self, filters: UserListFilter, page: Optional[int], limit: Optional[int]
    ) -> ResponseUserTuple:
        return await self.user_repository.get_all_users(filters, page, limit)

    async def block_user(self, user_id: int) -> Optional[User]:
        return await self.user_repository.block_user(user_id)

    async def unblock_user(self, user_id: int) -> Optional[User]:
        return await self.user_repository.unblock_user(user_id)
