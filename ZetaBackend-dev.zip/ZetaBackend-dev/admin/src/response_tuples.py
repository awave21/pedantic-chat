from typing import Dict, List, NamedTuple, Optional, Union

from common.database.models import (
    Category,
    Document,
    SubCategory,
    User,
    VerificationCode,
)


class ResponseUserTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[List[User], User, None] = None
    count: Optional[int] = None  # type: ignore


class ResponseCodeTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Optional[VerificationCode] = None


class ResponseJWTTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Optional[Dict] = None


class ResponseDocTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[Document, List[Document], None] = None


class ResponseNetworkUploadTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    link: Optional[str] = None


class ResponseCategoryTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[Category, List[Category], Dict, List[Dict], None] = None


class ResponseSubCategoryTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[Category, List[SubCategory], Dict, None] = None
