from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routing import auth, categories, docs, subcategories, users
from сonfig import app_settings

app = FastAPI(
    debug=app_settings.DEBUG, openapi_url="/admin/openapi.json", docs_url="/admin/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(docs.router, prefix="/admin")
app.include_router(auth.router, prefix="/admin")
app.include_router(categories.router, prefix="/admin")
app.include_router(subcategories.router, prefix="/admin")
app.include_router(users.router, prefix="/admin")
