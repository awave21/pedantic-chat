from typing import Callable, Optional

from filters import UserListFilter
from response_tuples import ResponseUserTuple
from sqlalchemy import func, update
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import User


class UserRepository:
    base_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_user_by_nickname(self, nickname: str) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.nickname == nickname)
            )
            user = result.scalars().first()
            return user

    async def get_all_users(
        self, filters: UserListFilter, page: Optional[int], limit: Optional[int]
    ) -> ResponseUserTuple:
        async with self.get_db() as session:
            query = await filters.exec_filter(select(self.base_model), self.base_model)

            if page is not None and limit is not None:
                users = await session.execute(
                    query.order_by(
                        self.base_model.count_followers.desc(), self.base_model.id.asc()
                    )
                    .limit(limit)
                    .offset(page * limit)
                )
                users = users.scalars().all()
                count = await session.execute(
                    select(func.count()).select_from(query.subquery())
                )
                count = count.scalar_one()
                result = ResponseUserTuple(data=users, count=count)
            else:
                users = await session.execute(
                    query.order_by(
                        self.base_model.count_followers.desc(), self.base_model.id.asc()
                    )
                )
                users = users.scalars().all()
                result = ResponseUserTuple(data=users)
            return result

    async def block_user(self, user_id: int) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                update(self.base_model)
                .where(self.base_model.id == user_id)
                .values(is_blocked=True)
                .returning(*self.base_model.__table__.c)
            )
            user = result.first()
            await session.commit()
            return user

    async def unblock_user(self, user_id: int) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                update(self.base_model)
                .where(self.base_model.id == user_id)
                .values(is_blocked=False)
                .returning(*self.base_model.__table__.c)
            )
            user = result.first()
            await session.commit()
            return user
