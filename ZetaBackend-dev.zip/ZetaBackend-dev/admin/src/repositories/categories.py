from typing import Type, Union

from response_tuples import ResponseCategoryTuple, ResponseSubCategoryTuple
from schemas.categories import (
    CategoryCreateSchema,
    CategoryUpdateSchema,
    SubCategoryCreateSchema,
    SubCategoryUpdateSchema,
)
from sqlalchemy import insert, update
from sqlalchemy.future import select
from sqlalchemy.orm import Session

from common.database.models import Category, SubCategory
from common.repositories.categories import CategoriesRepository


class CategoriesAdminRepository(CategoriesRepository):
    async def create_category(
        self, data: CategoryCreateSchema
    ) -> ResponseCategoryTuple:
        async with self.get_db() as session:
            result = await session.execute(
                insert(self.base_model)
                .values(**data.dict())
                .returning(*self.base_model.__table__.c)
            )
            category = result.first()
            await session.commit()
            return ResponseCategoryTuple(data=category)

    async def update_category(
        self, category_id: int, data: CategoryUpdateSchema
    ) -> ResponseCategoryTuple:
        async with self.get_db() as session:
            result = await session.execute(
                update(self.base_model)
                .where(self.base_model.id == category_id)
                .values(**data.dict(exclude_unset=True))
                .returning(*self.base_model.__table__.c)
            )
            category = result.first()
            await session.commit()
            if not category:
                return ResponseCategoryTuple(
                    error_code=404, description="Category not found"
                )
            return ResponseCategoryTuple(data=category)

    async def archive_category(self, category_id: int) -> ResponseCategoryTuple:
        async with self.get_db() as session:
            result = await self._archive_instance(
                instance_id=category_id,
                is_archive=True,
                model=self.base_model,
                session=session,
            )

            if not result:
                return ResponseCategoryTuple(
                    error_code=404, description=f"Category {category_id} not found"
                )

            await session.execute(
                update(self.subcategory_model)
                .where(self.subcategory_model.category_id == category_id)
                .values({"is_archive": True})
            )

            await session.commit()
            return ResponseCategoryTuple()

    async def unarchive_category(self, category_id: int) -> ResponseCategoryTuple:
        async with self.get_db() as session:
            result = await self._archive_instance(
                instance_id=category_id,
                is_archive=False,
                model=self.base_model,
                session=session,
            )

            if not result:
                return ResponseCategoryTuple(
                    error_code=404, description=f"Category {category_id} not found"
                )

            await session.commit()
            return ResponseCategoryTuple()

    async def create_subcategory(
        self, data: SubCategoryCreateSchema
    ) -> ResponseSubCategoryTuple:
        async with self.get_db() as session:
            data = data.dict(exclude_unset=True)
            category = (
                await session.execute(
                    select(self.base_model).where(
                        self.base_model.id == data["category_id"]
                    )
                )
            ).first()
            if category is None:
                return ResponseSubCategoryTuple(
                    error_code=400,
                    description=f"Category {data['category_id']} not found",
                )
            result = await session.execute(
                insert(self.subcategory_model)
                .values(**data)
                .returning(*self.subcategory_model.__table__.c)
            )
            subcategory = result.first()
            await session.commit()
            return ResponseSubCategoryTuple(data=subcategory)

    async def update_subcategory(
        self, subcategory_id: int, data: SubCategoryUpdateSchema
    ) -> ResponseSubCategoryTuple:
        async with self.get_db() as session:
            data = data.dict(exclude_unset=True)
            if data.get("category_id"):
                category = (
                    await session.execute(
                        select(self.base_model).where(
                            self.base_model.id == data["category_id"]
                        )
                    )
                ).first()
                if category is None:
                    return ResponseSubCategoryTuple(
                        error_code=400,
                        description=f"Category {data['category_id']} not found",
                    )

            result = await session.execute(
                update(self.subcategory_model)
                .where(self.subcategory_model.id == subcategory_id)
                .values(**data)
                .returning(*self.subcategory_model.__table__.c)
            )
            subcategory = result.first()

            if not subcategory:
                return ResponseSubCategoryTuple(
                    error_code=404, description="Subcategory not found"
                )

            await session.commit()
            return ResponseSubCategoryTuple(data=subcategory)

    async def archive_subcategory(
        self, subcategory_id: int
    ) -> ResponseSubCategoryTuple:
        async with self.get_db() as session:
            result = await self._archive_instance(
                instance_id=subcategory_id,
                is_archive=True,
                model=self.subcategory_model,
                session=session,
            )

            if not result:
                return ResponseSubCategoryTuple(
                    error_code=404,
                    description=f"Subcategory {subcategory_id} not found",
                )

            await session.commit()
            return ResponseSubCategoryTuple()

    async def unarchive_subcategory(
        self, subcategory_id: int
    ) -> ResponseSubCategoryTuple:
        async with self.get_db() as session:
            result = await self._archive_instance(
                instance_id=subcategory_id,
                is_archive=False,
                model=self.subcategory_model,
                session=session,
            )

            if not result:
                return ResponseSubCategoryTuple(
                    error_code=404,
                    description=f"Subcategory {subcategory_id} not found",
                )

            await session.commit()
            return ResponseSubCategoryTuple()

    @staticmethod
    async def _archive_instance(
        instance_id: int,
        is_archive: bool,
        model: Union[Type[Category], Type[SubCategory]],
        session: Session,
    ) -> bool:

        result = await session.execute(
            update(model)
            .where(model.id == instance_id)
            .values({"is_archive": is_archive})
        )

        return bool(result.rowcount)
