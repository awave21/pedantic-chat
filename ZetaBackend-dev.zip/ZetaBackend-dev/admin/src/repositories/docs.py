from datetime import datetime
from typing import Callable, Dict, List, NamedTuple, Optional, Union

from schemas.docs import DocScheme
from sqlalchemy import delete, insert, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import Document


class ResponseDocTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Optional[Union[Document, List[Document]]] = None


class DocsRepository:
    base_model = Document

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_all_docs(self) -> ResponseDocTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).order_by(self.base_model.id.asc())
            )
            docs = result.scalars().all()
            return ResponseDocTuple(data=docs)

    async def get_doc(self, doc_id: int) -> ResponseDocTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.id == doc_id)
            )
            doc = result.scalars().first()
            if not doc:
                return ResponseDocTuple(
                    error_code=404, description="Document not found"
                )
            return ResponseDocTuple(data=doc)

    async def create_doc(self, data: DocScheme) -> ResponseDocTuple:
        async with self.get_db() as session:
            data = data.dict(exclude_unset=True, exclude={"id", "last_update"})
            data["last_update"] = datetime.utcnow()
            result = await session.execute(
                insert(self.base_model)
                .values(**data)
                .returning(*self.base_model.__table__.c)
            )
            doc = result.first()
            await session.commit()
            return ResponseDocTuple(data=doc)

    async def update_doc(self, doc_id: int, data: DocScheme) -> ResponseDocTuple:
        async with self.get_db() as session:
            data = data.dict(exclude_unset=True, exclude={"id", "last_update"})
            data["last_update"] = datetime.utcnow()
            result = await session.execute(
                update(self.base_model)
                .where(self.base_model.id == doc_id)
                .values(**data)
                .returning(*self.base_model.__table__.c)
            )
            doc = result.first()
            await session.commit()
            if not doc:
                return ResponseDocTuple(
                    error_code=404, description="Document not found"
                )
            return ResponseDocTuple(data=doc)

    async def delete_doc(self, doc_id: int) -> ResponseDocTuple:
        async with self.get_db() as session:
            await session.execute(
                delete(self.base_model).where(self.base_model.id == doc_id)
            )
            await session.commit()
            return ResponseDocTuple()
