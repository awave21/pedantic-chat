from typing import Dict, List, Optional

from pydantic import BaseModel, root_validator, validator

from common.enums.validators import ValidatorsErrorEnum
from common.schemas.mixins import FormDataMixinSchema


class SubCategoryCreateSchema(BaseModel):
    category_id: int
    name_en: str
    name_ru: str
    icon: Optional[str]

    @root_validator(pre=True)
    def check_icon_value(cls, values: Dict) -> Dict:
        assert "icon" not in values.keys(), "Icon must be unused"
        return values


class SubCategoryUpdateSchema(BaseModel):
    category_id: Optional[int]
    name_en: Optional[str]
    name_ru: Optional[str]
    icon: Optional[str]

    @root_validator(pre=True)
    def check_icon_value(cls, values: Dict) -> Dict:
        assert "icon" not in values.keys(), "Icon must be unused"
        return values

    @validator("category_id")
    def validate_category_id(cls, value: Optional[int]) -> int:
        assert value is not None, "Category id must not be None"
        return value

    @validator("name_ru")
    def validate_name_ru(cls, value: Optional[str]) -> str:
        assert value is not None, "Name must not be None"
        return value

    @validator("name_en")
    def validate_name_en(cls, value: Optional[str]) -> str:
        assert value is not None, "Name must not be None"
        return value


class SubCategoryFormDataCreateSchema(SubCategoryCreateSchema, FormDataMixinSchema):
    pass


class SubCategoryFormDataUpdateSchema(SubCategoryUpdateSchema, FormDataMixinSchema):
    pass


class SubCategorySchema(BaseModel):
    id: int
    category_id: int
    name_en: str
    name_ru: str
    icon: Optional[str]
    is_archive: Optional[bool]

    class Config:
        orm_mode = True


class CategoryCreateSchema(BaseModel):
    name_en: str
    name_ru: str


class CategoryUpdateSchema(BaseModel):
    name_en: Optional[str]
    name_ru: Optional[str]

    @root_validator(pre=True)
    def check_not_empty_names(cls, values: Dict) -> Dict:
        name_en, name_ru = values.get("name_en"), values.get("name_ru")
        if (not name_en) and (not name_ru):
            raise ValueError(ValidatorsErrorEnum.NAMES_EMPTY.to_str_dict_for_exception)
        return values


class CategoryScheme(CategoryCreateSchema):
    id: Optional[int]
    is_archive: Optional[bool]
    subcategories: List[SubCategorySchema] = []

    class Config:
        orm_mode = True
