import datetime
from typing import Optional

from pydantic import BaseModel


class DocScheme(BaseModel):
    id: Optional[int]
    name: Optional[str] = "Документ №1"
    name_eng: Optional[str] = "Document №1"
    text: Optional[str] = "<p>Тело <strong>документа</strong></p>"
    text_eng: Optional[str] = "<p>Document <strong>body</strong></p>"
    last_update: Optional[datetime.datetime]
    slug: Optional[str]

    class Config:
        orm_mode = True


class DocListingModel(BaseModel):
    id: Optional[int]
    name: Optional[str] = "Документ №1"
    name_eng: Optional[str] = "Document №1"

    class Config:
        orm_mode = True
