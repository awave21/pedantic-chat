from typing import Optional

from pydantic import BaseModel


class UserListSchema(BaseModel):
    id: int
    age: Optional[int]
    nickname: str
    avatar: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    country: Optional[str] = None
    count_posts: int = 0
    count_followers: int = 0
    is_blocked: bool

    class Config:
        orm_mode = True
