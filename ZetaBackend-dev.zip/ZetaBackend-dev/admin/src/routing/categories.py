from typing import List

from depends import get_categories_service
from fastapi import APIRouter, Depends, HTTPException
from schemas.categories import (
    CategoryCreateSchema,
    CategoryScheme,
    CategoryUpdateSchema,
)
from services.categories import CategoriesService
from starlette.responses import Response
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get(
    "/",
    responses={400: {"description": "Bad request"}},
    response_model=List[CategoryScheme],
    description="Получение листинга всех категорий с подкатегориями",
)
async def list_categories(
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> List[CategoryScheme]:
    categories = await categories_service.list_categories()
    result = [CategoryScheme.from_orm(category) for category in categories.data]
    return result


@router.post(
    "/",
    responses={201: {"description": "Created"}, 403: {"description": "Forbidden"}},
    status_code=201,
    response_model=CategoryScheme,
    description="Создание новой категории",
)
async def create_category(
    category: CategoryCreateSchema,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> CategoryScheme:
    category = await categories_service.create_category(data=category)
    result = CategoryScheme.from_orm(category.data)
    return result


@router.patch(
    "/{id}",
    responses={
        404: {"description": "Category not found"},
        403: {"description": "Forbidden"},
    },
    response_model=CategoryScheme,
    description="Обновление категории по id",
)
async def update_category(
    id: int,
    category: CategoryUpdateSchema,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> CategoryScheme:
    category = await categories_service.update_category(category_id=id, data=category)
    if category.error_code:
        raise HTTPException(category.error_code, detail=category.description)
    result = CategoryScheme.from_orm(category.data)
    return result


@router.patch(
    "/{id}/archive",
    responses={400: {"description": "Bad request"}},
    description="Добавляет категорию в архив со всеми подкатегориями по id",
)
async def archive_category(
    id: int,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Response:
    await categories_service.archive_category(category_id=id)
    return Response(status_code=200)


@router.patch(
    "/{id}/unarchive",
    responses={400: {"description": "Bad request"}},
    description="Удаляет категорию из архива по id",
)
async def unarchive_category(
    id: int,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Response:
    await categories_service.unarchive_category(category_id=id)
    return Response(status_code=200)
