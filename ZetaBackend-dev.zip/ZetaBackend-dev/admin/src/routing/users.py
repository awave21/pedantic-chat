from typing import List, Optional, Union

from depends import get_user_service
from fastapi import APIRouter, Depends, Query, Request
from filters import UserListFilter
from schemas.users import UserListSchema
from services.users import UserService
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User
from common.filters.utils import get_query_params
from common.schemas.common import Page

router = APIRouter(prefix="/user", tags=["user"])


@router.get(
    "/",
    response_model=Union[List[UserListSchema], Page],
    description="Листинг пользователей",
)
async def list_user(
    request: Request,
    page: Optional[int] = Query(None, ge=0),
    limit: Optional[int] = Query(None, ge=0),
    user_service: UserService = Depends(get_user_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Union[List[UserListSchema], Page]:
    filters = UserListFilter(get_query_params(request.query_params))
    result = await user_service.get_all_users(filters, page, limit)

    users = [UserListSchema.from_orm(user) for user in result.data]

    if page is not None and limit is not None and result.count is not None:
        return Page(page=page, limit=limit, count=result.count, data=users)

    return users


@router.patch(
    "/{id}/blocked",
    response_model=Optional[UserListSchema],
    description="Блокировка пользователя",
)
async def block_user(
    id: int,
    user_service: UserService = Depends(get_user_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Optional[UserListSchema]:
    user = await user_service.block_user(id)
    return user


@router.patch(
    "/{id}/unblocked",
    response_model=Optional[UserListSchema],
    description="Разблокировка пользователя",
)
async def unblock_user(
    id: int,
    user_service: UserService = Depends(get_user_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Optional[UserListSchema]:
    user = await user_service.unblock_user(id)
    return user
