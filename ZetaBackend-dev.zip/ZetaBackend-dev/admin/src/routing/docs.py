from typing import List

from depends import get_docs_service
from fastapi import APIRouter, Depends, HTTPException
from schemas.docs import DocListingModel, DocScheme
from services.docs import DocsService
from starlette.responses import Response
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/documents", tags=["documents"])


@router.get(
    "/",
    responses={400: {"description": "Bad request"}},
    response_model=List[DocListingModel],
    description="Получение листинга всех документов",
)
async def get_all_docs(
    docs_service: DocsService = Depends(get_docs_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> List[DocListingModel]:
    docs = await docs_service.get_all_docs()
    result = [DocListingModel.from_orm(doc) for doc in docs.data]
    return result


@router.get(
    "/{id}",
    responses={404: {"description": "Document not found"}},
    response_model=DocScheme,
    description="Получение детального документа по id",
)
async def get_doc(
    id: int,
    docs_service: DocsService = Depends(get_docs_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> DocScheme:
    doc = await docs_service.get_doc(doc_id=id)
    if doc.error_code:
        raise HTTPException(doc.error_code, detail=doc.description)
    result = DocScheme.from_orm(doc.data)
    return result


@router.post(
    "/",
    responses={201: {"description": "Created"}, 403: {"description": "Forbidden"}},
    status_code=201,
    response_model=DocScheme,
    description="Создание нового документа",
)
async def create_doc(
    doc: DocScheme,
    docs_service: DocsService = Depends(get_docs_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> DocScheme:
    if not doc.name:
        raise HTTPException(400, detail="name required")
    if not doc.name_eng:
        raise HTTPException(400, detail="name_eng required")
    doc = await docs_service.create_doc(data=doc)
    result = DocScheme.from_orm(doc.data)
    return result


@router.patch(
    "/{id}",
    responses={
        404: {"description": "Document not found"},
        403: {"description": "Forbidden"},
    },
    response_model=DocScheme,
    description="Обновление документа по id",
)
async def update_doc(
    id: int,
    doc: DocScheme,
    docs_service: DocsService = Depends(get_docs_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> DocScheme:
    doc = await docs_service.update_doc(doc_id=id, data=doc)
    if doc.error_code:
        raise HTTPException(doc.error_code, detail=doc.description)
    result = DocScheme.from_orm(doc.data)
    return result


@router.delete(
    "/{id}",
    status_code=204,
    responses={400: {"description": "Bad request"}},
    description="Удаление документа по id",
)
async def delete_doc(
    id: int,
    docs_service: DocsService = Depends(get_docs_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Response:
    await docs_service.delete_doc(doc_id=id)
    return Response(status_code=204)
