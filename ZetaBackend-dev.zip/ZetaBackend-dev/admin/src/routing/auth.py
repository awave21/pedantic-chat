from depends import get_auth_service
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from schemas.common import JWTResponse
from services.auth import AuthService
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/auth")
security = HTTPBasic()


@router.get(
    "/login",
    response_model=JWTResponse,
    description="Ручка для получения access token по логину+паролю, "
    "которые отправляются сюда по Basic Auth",
    tags=["auth"],
)
async def login(
    credentials: HTTPBasicCredentials = Depends(security),
    auth_service: AuthService = Depends(get_auth_service),
) -> JSONResponse:
    result = await auth_service.login_user(credentials.username, credentials.password)
    if result.error_code:
        raise HTTPException(status_code=result.error_code, detail=result.description)
    return JSONResponse(result.data, status_code=200)


@router.get(
    "/refresh_token",
    response_model=JWTResponse,
    description="Ручка для получения новой пары токенов по refresh token",
    tags=["auth"],
)
async def refresh_token(
    user: User = Depends(
        get_jwt_bearer(auth_handler, TokenType.REFRESH, is_admin=True)
    ),
    auth_service: AuthService = Depends(get_auth_service),
) -> JSONResponse:
    result = await auth_service.refresh_token(user.id)

    return JSONResponse(result.data, status_code=200)
