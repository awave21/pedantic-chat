from typing import Optional

from depends import get_categories_service
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from our_types import NetworkUploadFile
from schemas.categories import (
    SubCategoryFormDataCreateSchema,
    SubCategoryFormDataUpdateSchema,
    SubCategorySchema,
)
from services.categories import CategoriesService
from starlette.requests import Request
from starlette.responses import Response
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User
from common.utils.checks import check_type_files_in_image_or_video

router = APIRouter(prefix="/subcategories", tags=["subcategories"])


@router.post(
    "/",
    responses={
        201: {"description": "Created"},
        403: {"description": "Forbidden"},
        400: {"description": "Validation error"},
    },
    status_code=201,
    response_model=SubCategorySchema,
    description="Создание новой подкатегории",
)
async def create_subcategory(
    request: Request,
    subcategory: SubCategoryFormDataCreateSchema = Form(...),
    icon_file: UploadFile = File(...),
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> SubCategorySchema:
    if not check_type_files_in_image_or_video(icon_file, is_video=False):
        raise HTTPException(status_code=400, detail="File is not image")

    result = await categories_service.create_subcategory(
        data=subcategory,
        upload_data=NetworkUploadFile(icon_file, request.headers.get("authorization")),
    )
    if result.error_code:
        raise HTTPException(result.error_code, detail=result.description)

    result = SubCategorySchema.from_orm(result.data)
    return result


@router.patch(
    "/{id}",
    responses={
        404: {"description": "Subcategory not found"},
        403: {"description": "Forbidden"},
        400: {"description": "Validation error"},
    },
    response_model=SubCategorySchema,
    description="Обновление подкатегории по id",
)
async def update_subcategory(
    request: Request,
    id: int,
    subcategory: SubCategoryFormDataUpdateSchema = Form(...),
    icon_file: Optional[UploadFile] = File(None),
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> SubCategorySchema:
    if not icon_file and not any(
        val is not None for val in subcategory.dict().values()
    ):
        raise HTTPException(status_code=400, detail="No data for update")

    if icon_file and not check_type_files_in_image_or_video(icon_file, is_video=False):
        raise HTTPException(status_code=400, detail="File is not image")

    upload_data = (
        NetworkUploadFile(icon_file, request.headers.get("authorization"))
        if icon_file
        else None
    )

    subcategory = await categories_service.update_subcategory(
        subcategory_id=id, data=subcategory, upload_data=upload_data
    )
    if subcategory.error_code:
        raise HTTPException(subcategory.error_code, detail=subcategory.description)

    result = SubCategorySchema.from_orm(subcategory.data)
    return result


@router.patch(
    "/{id}/archive",
    status_code=202,
    responses={400: {"description": "Bad request"}},
    description="Добавляет подкатегория по id в архив",
)
async def archive_subcategory(
    id: int,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Response:
    result = await categories_service.archive_subcategory(subcategory_id=id)

    if result.error_code:
        raise HTTPException(result.error_code, detail=result.description)

    return Response(status_code=202)


@router.patch(
    "/{id}/unarchive",
    status_code=202,
    responses={400: {"description": "Bad request"}},
    description="Удаляет подкатегория по id из архива",
)
async def unarchive_subcategory(
    id: int,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS, is_admin=True)),
) -> Response:
    result = await categories_service.unarchive_subcategory(subcategory_id=id)

    if result.error_code:
        raise HTTPException(result.error_code, detail=result.description)

    return Response(status_code=202)
