from repositories.categories import CategoriesAdminRepository
from repositories.docs import DocsRepository
from repositories.users import UserRepository
from services.auth import AuthService
from services.categories import CategoriesService
from services.docs import DocsService
from services.network import NetworkService
from services.users import UserService
from сonfig import network_settings

from common.db import get_db

user_repository = UserRepository(get_db)
docs_repository = DocsRepository(get_db)
categories_repository = CategoriesAdminRepository(get_db)

network_service = NetworkService(network_settings)

auth_service = AuthService(user_repository)
docs_service = DocsService(docs_repository)
categories_service = CategoriesService(categories_repository, network_service)
user_service = UserService(user_repository)


async def get_auth_service() -> AuthService:
    return auth_service


async def get_docs_service() -> DocsService:
    return docs_service


async def get_categories_service() -> CategoriesService:
    return categories_service


async def get_user_service() -> UserService:
    return user_service
