from common.filters import func
from common.filters.base import FilterBase


class UserListFilter(FilterBase):
    fields = {
        "id": [func.GTE, func.GT, func.LTE, func.LT],
        "age": [func.GTE, func.GT, func.LTE, func.LT],
        "count_followers": [func.GTE, func.GT, func.LTE, func.LT],
        "count_posts": [func.GTE, func.GT, func.LTE, func.LT],
        "country": [
            func.STARTSWITH,
            func.ISTARTSWITH,
            func.CONTAINS,
            func.ICONTAINS,
            func.ICONTAINS_LIST,
        ],
        "email": [
            func.STARTSWITH,
            func.ISTARTSWITH,
            func.CONTAINS,
            func.ICONTAINS,
            func.ICONTAINS_LIST,
        ],
        "nickname": [
            func.STARTSWITH,
            func.ISTARTSWITH,
            func.CONTAINS,
            func.ICONTAINS,
            func.ICONTAINS_LIST,
        ],
        "phone": [
            func.STARTSWITH,
            func.ISTARTSWITH,
            func.CONTAINS,
            func.ICONTAINS,
            func.ICONTAINS_LIST,
        ],
    }
