from repositories.search import SearchUserRepository
from response_tuples import ResponseSearchTuple


class SearchUserService:
    def __init__(self, search_repository: SearchUserRepository):
        self.search_repository = search_repository

    async def search_users_by_nickname(
        self, nickname: str, page: int, limit: int
    ) -> ResponseSearchTuple:
        result = await self.search_repository.search_users_by_nickname(
            nickname, page, limit
        )
        return result
