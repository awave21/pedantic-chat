from enums.follow import FollowResponseEnum
from our_types import FollowersWithCount
from repositories.follow import FollowRepository
from response_tuples import ResponseFollowTuple, ResponseFollowWithCountTuple

from common.database.models import User


class FollowService:
    def __init__(self, follow_repositories: FollowRepository):
        self.follow_repositories = follow_repositories

    async def list_my_followers(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowTuple:
        return await self.follow_repositories.list_followers(user_id, page, limit)

    async def list_my_followings(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowTuple:
        return await self.follow_repositories.list_followings(user_id, page, limit)

    async def list_followers_by_id(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowWithCountTuple:
        user = await self.follow_repositories.get_profile_by_id(user_id)

        if not user:
            return ResponseFollowWithCountTuple(
                error_code=400, description=FollowResponseEnum.USER_NOT_FOUND
            )

        followers = await self.follow_repositories.list_followers(user_id, page, limit)

        return ResponseFollowWithCountTuple(
            data=FollowersWithCount(
                count=user.count_followers, followers=followers.data
            )
        )

    async def list_followings_by_id(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowWithCountTuple:
        user = await self.follow_repositories.get_profile_by_id(user_id)

        if not user:
            return ResponseFollowWithCountTuple(
                error_code=400, description=FollowResponseEnum.USER_NOT_FOUND
            )

        followings = await self.follow_repositories.list_followings(
            user_id, page, limit
        )

        return ResponseFollowWithCountTuple(
            data=FollowersWithCount(
                count=user.count_followings, followers=followings.data
            )
        )

    async def follow(self, follower_id: int, following: User) -> ResponseFollowTuple:
        if await self.follow_repositories._check_blocked(follower_id, following):
            return ResponseFollowTuple(
                error_code=403, description=FollowResponseEnum.USER_BLOCKED
            )
        return await self.follow_repositories.follow(follower_id, following)

    async def unfollow(self, follower_id: int, following: User) -> ResponseFollowTuple:
        if await self.follow_repositories._check_blocked(follower_id, following):
            return ResponseFollowTuple(
                error_code=403, description=FollowResponseEnum.USER_BLOCKED
            )
        return await self.follow_repositories.unfollow(follower_id, following)
