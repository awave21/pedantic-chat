from repositories.document import DocumentRepository
from response_tuples import ResponseDocumentTuple


class DocumentService:
    def __init__(self, document_repository: DocumentRepository):
        self.document_repository = document_repository

    async def get_document(self, slug: str) -> ResponseDocumentTuple:
        return await self.document_repository.get_document(slug)
