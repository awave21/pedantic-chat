from typing import Any, Dict

from enums.person_profile import PersonProfileResponseEnum
from repositories.users import UserRepository
from response_tuples import ResponseUserTuple
from schemas.person_profile import UpdateProfileSchema

from common.database.models import User


class PersonProfileService:
    def __init__(self, user_repository: UserRepository):
        self.user_repository = user_repository

    async def update_person_profile(
        self, user: User, data: UpdateProfileSchema
    ) -> ResponseUserTuple:
        # if not await self._check_allowed_update_profile(
        #     user, data.dict(exclude_unset=True)
        # ):
        #     return ResponseUserTuple(
        #         error_code=400, description=PersonProfileResponseEnum.NO_LOGIN_FIELD
        #     )

        return await self.user_repository.update_user(user.id, data)

    async def get_person_profile_by_id(self, user_id: int) -> ResponseUserTuple:
        return await self.user_repository.get_person_profile_by_id(user_id)

    async def get_public_profile_by_id(
        self, user_id: int, public_user_id: int
    ) -> ResponseUserTuple:
        return await self.user_repository.get_public_profile_by_id(
            user_id, public_user_id
        )

    async def delete_person_profile(self, user: User) -> None:
        await self.user_repository.delete_user(user.id)

    async def block_user(self, blocking_id: int, blocker: User) -> Any:
        return await self.user_repository.block_user(blocking_id, blocker)

    async def unblock_user(self, blocking_id: int, blocker: User) -> Any:
        return await self.user_repository.unblock_user(blocking_id, blocker)

    @staticmethod
    async def _check_allowed_update_profile(user: User, data: Dict) -> bool:
        return not (
            (data.get("phone", 1) is None and data.get("email", 1) is None)
            or (data.get("phone", 1) is None and user.email is None)
            or (data.get("email", 1) is None and user.phone is None)
        )
