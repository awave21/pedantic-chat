from depends import get_document_service
from fastapi import APIRouter, Depends, HTTPException
from schemas.document import DocumentScheme
from services.document import DocumentService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User

router = APIRouter(prefix="/document", tags=["documents"])


@router.get(
    "/{slug}",
    response_model=DocumentScheme,
    status_code=200,
    description="""Ручка для получения правового документа по слагу, для политики конфиденциальности слаг - policy""",
)
async def get_document(
    request: Request,
    slug: str,
    document_service: DocumentService = Depends(get_document_service),
) -> JSONResponse:

    result = await document_service.get_document(slug)
    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )
    document = DocumentScheme.from_orm(result.data, request.state.language)
    return JSONResponse(document.dict())
