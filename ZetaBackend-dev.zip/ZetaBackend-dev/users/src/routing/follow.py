from depends import get_follow_service
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.encoders import jsonable_encoder
from schemas.follow import FollowPage
from services.follow import FollowService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.schemas.users import ShortPersonProfile

router = APIRouter(tags=["follow"])


@router.get(
    "/my_followers",
    status_code=200,
    response_model=FollowPage,
    description="""
    Отдаёт список подписчиков пользователя.
    Работает только с пагинацией
    """,
)
async def list_followers(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.list_my_followers(user.id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    followers = [ShortPersonProfile.from_orm(follower) for follower in result.data]

    return JSONResponse(
        jsonable_encoder(
            FollowPage(
                page=page, limit=limit, data=followers, count=user.count_followers
            )
        ),
        status_code=200,
    )


@router.get(
    "/my_followings",
    status_code=200,
    response_model=FollowPage,
    description="""
    Отдаёт список подписок пользователя.
    Работает только с пагинацией
    """,
)
async def list_followings(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.list_my_followings(user.id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    followings = [ShortPersonProfile.from_orm(following) for following in result.data]

    return JSONResponse(
        jsonable_encoder(
            FollowPage(
                page=page, limit=limit, data=followings, count=user.count_followings
            )
        ),
        status_code=200,
    )


@router.patch(
    "/{user_id}/follow",
    status_code=202,
    description="""
    Подписывается на пользователя
    """,
)
async def follow(
    request: Request,
    user_id: int,
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.follow(user_id, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse({}, status_code=202)


@router.patch(
    "/{user_id}/unfollow",
    status_code=202,
    description="""
    Отписывается от пользователя
    """,
)
async def unfollow(
    request: Request,
    user_id: int,
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.unfollow(user_id, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse({}, status_code=202)


@router.get(
    "/{user_id}/followers",
    status_code=200,
    response_model=FollowPage,
    description="""
    Отдаёт список подписчиков пользователя по его id.
    Работает только с пагинацией
    """,
)
async def list_user_followers(
    request: Request,
    user_id: int,
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.list_followers_by_id(user_id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    followers = [
        ShortPersonProfile.from_orm(follower) for follower in result.data.followers
    ]

    return JSONResponse(
        jsonable_encoder(
            FollowPage(page=page, limit=limit, data=followers, count=result.data.count)
        ),
        status_code=200,
    )


@router.get(
    "/{user_id}/followings",
    status_code=200,
    response_model=FollowPage,
    description="""
    Отдаёт список подписок пользователя по его id.
    Работает только с пагинацией
    """,
)
async def list_user_followings(
    request: Request,
    user_id: int,
    page: int = Query(0, ge=0),
    limit: int = Query(40, ge=5),
    follow_service: FollowService = Depends(get_follow_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await follow_service.list_followings_by_id(user_id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    followings = [
        ShortPersonProfile.from_orm(following) for following in result.data.followers
    ]

    return JSONResponse(
        jsonable_encoder(
            FollowPage(page=page, limit=limit, data=followings, count=result.data.count)
        ),
        status_code=200,
    )
