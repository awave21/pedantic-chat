from typing import Dict

from depends import get_person_profile_service
from fastapi import APIRouter, Depends, HTTPException
from schemas.person_profile import PersonProfile, PublicProfile, UpdateProfileSchema
from services.person_profile import PersonProfileService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User

router = APIRouter(prefix="/profile", tags=["users"])


@router.get(
    "",
    response_model=PersonProfile,
    status_code=200,
    description="""Личный профиль""",
)
async def get_person_profile(
    request: Request,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    result = await person_profile_service.get_person_profile_by_id(user.id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    data = PersonProfile.from_orm(result.data, locale=request.state.language)
    return JSONResponse(data.dict())


@router.patch(
    "",
    response_model=PersonProfile,
    status_code=202,
    description="""Редактировать текстовую информацию о себе""",
)
async def update_person_profile(
    request: Request,
    data: UpdateProfileSchema,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    result = await person_profile_service.update_person_profile(user, data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    data = PersonProfile.from_orm(result.data, locale=request.state.language)
    return JSONResponse(data.dict())


@router.get(
    "/{user_id}",
    response_model=PublicProfile,
    status_code=200,
    description="""Публичный профиль пользователя""",
)
async def get_person_profile_by_id(
    request: Request,
    user_id: int,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    result = await person_profile_service.get_public_profile_by_id(user.id, user_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    data = PublicProfile.from_orm(result.data, locale=request.state.language)
    return JSONResponse(data.dict())


@router.post(
    "/delete",
    response_model=None,
    status_code=200,
    description="""Удаление профиял и всей информации о нем""",
)
async def delete_person_profile(
    request: Request,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    await person_profile_service.delete_person_profile(user)


@router.post(
    "/block/{user_id}",
    response_model=Dict,
    status_code=200,
    description="""Блокировка пользователя""",
)
async def block_user(
    request: Request,
    user_id: int,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    result = await person_profile_service.block_user(user_id, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    # data = PublicProfile.from_orm(result.data, locale=request.state.language)
    return JSONResponse({"status": "ok"})


@router.post(
    "/unblock/{user_id}",
    response_model=Dict,
    status_code=200,
    description="""Разблокировка пользователя""",
)
async def unblock_user(
    request: Request,
    user_id: int,
    user: User = Depends(get_jwt_bearer(auth_handler)),
    person_profile_service: PersonProfileService = Depends(get_person_profile_service),
) -> JSONResponse:

    result = await person_profile_service.unblock_user(user_id, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    # data = PublicProfile.from_orm(result.data, locale=request.state.language)
    return JSONResponse({"status": "ok"})
