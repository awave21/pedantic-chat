from depends import get_search_service
from fastapi import APIRouter, Depends, Query
from fastapi.encoders import jsonable_encoder
from schemas.search import SearchPage
from services.search import SearchUserService
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.schemas.users import ShortPersonProfile

router = APIRouter(prefix="/search", tags=["search"])


@router.get(
    "",
    response_model=SearchPage,
    status_code=200,
    description="""Поиск профиля по имени пользователя""",
)
async def search_users_by_nicknames(
    user: User = Depends(get_jwt_bearer(auth_handler)),
    search_service: SearchUserService = Depends(get_search_service),
    nickname: str = Query(...),
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=2),
) -> JSONResponse:
    result = await search_service.search_users_by_nickname(nickname, page, limit)
    users = [ShortPersonProfile.from_orm(user) for user in result.data[0]]

    return JSONResponse(
        jsonable_encoder(
            SearchPage(page=page, limit=limit, data=users, count=result.data[1])
        ),
        status_code=200,
    )
