from common.enums.languages import AbstractLangEnum


class SearchResponseEnum(AbstractLangEnum):
    EMPTY_SEARCH_STRING = (
        "Search string shouldn't be empty",
        "Строка поиска не должна быть пустой",
    )
