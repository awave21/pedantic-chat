from common.enums.languages import AbstractLangEnum


class PersonProfileResponseEnum(AbstractLangEnum):
    NO_LOGIN_FIELD = (
        "Phone or email must be filled",
        "Телефон или почта должны быть заполнены",
    )
    NO_UNIQUE_USER_DATA = (
        "User with this data already exists",
        "Пользователь с такими данными уже существует",
    )
    USER_NOT_FOUND = ("User not found", "Пользователь не найден")
    ALREADY_BLOCKED = ("User already blocked", "Пользователь уже заблокирован")
    ALREADY_UNBLOCKED = ("User not blocked", "Пользователь не заблокирован")
