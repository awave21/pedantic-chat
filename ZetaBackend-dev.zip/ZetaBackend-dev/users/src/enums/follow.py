from common.enums.languages import AbstractLangEnum


class FollowResponseEnum(AbstractLangEnum):
    ALREADY_FOLLOW = ("Already follow", "Вы уже подписаны на данного пользователя")
    ALREADY_UNFOLLOW = ("Already unfollow", "Вы не подписаны на данного пользователя")
    NOT_FOLLOW = (
        "Failed to follow",
        "Неудалось подписаться на пользователя",
    )
    NOT_UNFOLLOW = (
        "Failed to unfollow",
        "Неудалось отписаться на пользователя",
    )

    USER_NOT_FOUND = ("User not found", "Пользователь не найден")
    USER_BLOCKED = ("User is blocked", "Пользователь заблокирован")
