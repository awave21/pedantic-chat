from common.enums.languages import AbstractLangEnum


class DocumentResponseEnum(AbstractLangEnum):
    DOCUMENT_NOT_FOUND = ("Document not found", "Документ не найден")
