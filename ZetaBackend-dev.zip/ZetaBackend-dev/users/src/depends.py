from repositories.document import DocumentRepository
from repositories.follow import FollowRepository
from repositories.search import SearchUserRepository
from repositories.users import UserRepository
from services.document import DocumentService
from services.follow import FollowService
from services.person_profile import PersonProfileService
from services.search import SearchUserService

from common.db import get_db

user_repository = UserRepository(get_db)
follow_repository = FollowRepository(get_db)
search_repository = SearchUserRepository(get_db)
document_repository = DocumentRepository(get_db)

person_profile_service = PersonProfileService(user_repository)
follow_service = FollowService(follow_repository)
search_service = SearchUserService(search_repository)
document_service = DocumentService(document_repository)


async def get_person_profile_service() -> PersonProfileService:
    return person_profile_service


async def get_follow_service() -> FollowService:
    return follow_service


async def get_search_service() -> SearchUserService:
    return search_service


async def get_document_service() -> DocumentService:
    return document_service
