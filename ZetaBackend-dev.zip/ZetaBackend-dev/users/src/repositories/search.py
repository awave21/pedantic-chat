from typing import Callable

from response_tuples import ResponseSearchTuple
from sqlalchemy import and_, asc, desc, distinct, func
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import User


class SearchUserRepository:
    user_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def search_users_by_nickname(
        self, search_string: str, page: int, limit: int
    ) -> ResponseSearchTuple:
        async with self.get_db() as session:
            where_expr = and_(
                self.user_model.is_draft.is_(False),
                func.lower(self.user_model.nickname).startswith(search_string.lower()),
            )
            # todo: it could be better, so we need to refactor it
            count = await session.execute(select(func.count()).where(where_expr))
            result = await session.execute(
                select(self.user_model)
                .where(where_expr)
                .order_by(asc(self.user_model.nickname))
                .limit(limit)
                .offset(page * limit)
            )
            count = count.scalar()
            users = result.scalars().all()
            return ResponseSearchTuple(data=(users, count))
