from typing import Callable

from enums.document import DocumentResponseEnum
from response_tuples import ResponseDocumentTuple
from sqlalchemy import select
from sqlalchemy.orm import sessionmaker

from common.database.models import Document


class DocumentRepository:
    base_model = Document

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_document(
        self,
        slug: str,
    ) -> ResponseDocumentTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.slug == slug)
            )

            policy = result.scalars().first()
            if not policy:
                return ResponseDocumentTuple(
                    error_code=404, description=DocumentResponseEnum.DOCUMENT_NOT_FOUND
                )

            return ResponseDocumentTuple(data=policy)
