from typing import Callable, Optional

from enums.follow import FollowResponseEnum
from response_tuples import ResponseFollowTuple
from sqlalchemy import and_, delete, desc, insert, or_
from sqlalchemy.exc import IntegrityError, InvalidRequestError
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import BlockedAssociateTable, FollowersAssociateTable, User


class FollowRepository:
    user_model = User
    associated_model = FollowersAssociateTable

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_profile_by_id(self, user_id: int) -> Optional[User]:
        async with self.get_db() as session:
            return await session.get(self.user_model, user_id)

    async def list_followers(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.user_model)
                .join(
                    self.associated_model,
                    self.associated_model.c.follower_id == self.user_model.id,
                )
                .where(self.associated_model.c.following_id == user_id)
                .order_by(desc(self.associated_model.c.created_at))
                .limit(limit)
                .offset(page * limit)
            )

            followers = result.scalars().all()

            return ResponseFollowTuple(data=followers)

    async def list_followings(
        self, user_id: int, page: int, limit: int
    ) -> ResponseFollowTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.user_model)
                .join(
                    self.associated_model,
                    self.associated_model.c.following_id == self.user_model.id,
                )
                .where(self.associated_model.c.follower_id == user_id)
                .order_by(desc(self.associated_model.c.created_at))
                .limit(limit)
                .offset(page * limit)
            )

            followers = result.scalars().all()

            return ResponseFollowTuple(data=followers)

    async def follow(self, following_id: int, follower: User) -> ResponseFollowTuple:
        async with self.get_db() as session:
            following = await session.get(self.user_model, following_id)

            if not following:
                return ResponseFollowTuple(
                    error_code=400, description=FollowResponseEnum.USER_NOT_FOUND
                )

            try:
                await session.execute(
                    insert(self.associated_model).values(
                        follower_id=follower.id, following_id=following.id
                    )
                )

                follower.count_followings += 1
                following.count_followers += 1

                session.add_all([follower, following])
                await session.commit()
            except IntegrityError:
                return ResponseFollowTuple(
                    error_code=400, description=FollowResponseEnum.ALREADY_FOLLOW
                )
            except InvalidRequestError:
                return ResponseFollowTuple(
                    error_code=500, description=FollowResponseEnum.NOT_FOLLOW
                )

        return ResponseFollowTuple()

    async def unfollow(self, following_id: int, follower: User) -> ResponseFollowTuple:
        async with self.get_db() as session:
            following = await session.get(self.user_model, following_id)

            if not following:
                return ResponseFollowTuple(
                    error_code=400, description=FollowResponseEnum.USER_NOT_FOUND
                )

            try:
                result = await session.execute(
                    delete(self.associated_model).where(
                        and_(
                            self.associated_model.c.follower_id == follower.id,
                            self.associated_model.c.following_id == following.id,
                        )
                    )
                )

                if not result.rowcount:
                    return ResponseFollowTuple(
                        error_code=400, description=FollowResponseEnum.ALREADY_UNFOLLOW
                    )

                follower.count_followings -= 1
                following.count_followers -= 1

                session.add_all([follower, following])
                await session.commit()
            except IntegrityError:
                return ResponseFollowTuple(
                    error_code=500, description=FollowResponseEnum.NOT_UNFOLLOW
                )

        return ResponseFollowTuple()

    async def _check_blocked(self, user_id: int, user: User) -> bool:
        """Проверка заблокирован ли пользователь"""
        async with self.get_db() as session:
            result = await session.execute(
                select(BlockedAssociateTable).where(
                    or_(
                        and_(
                            BlockedAssociateTable.c.blocking_id == user_id,
                            BlockedAssociateTable.c.blocker_id == user.id,
                        ),
                        and_(
                            BlockedAssociateTable.c.blocker_id == user_id,
                            BlockedAssociateTable.c.blocking_id == user.id,
                        ),
                    )
                )
            )

        return result.scalar() is not None
