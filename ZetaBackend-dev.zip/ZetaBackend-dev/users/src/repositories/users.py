from typing import Any, Callable, Optional

from enums.person_profile import PersonProfileResponseEnum
from response_tuples import ResponseBlockTuple, ResponseUserTuple
from schemas.person_profile import UpdateProfileSchema
from sqlalchemy import and_, delete, insert, or_, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload, sessionmaker

from common.database.models import (
    BlockedAssociateTable,
    Chat,
    ChatsAssociateTable,
    FavoriteAssociateTable,
    FollowersAssociateTable,
    LikerAssociateTable,
    Media,
    Message,
    Post,
    PostSubCategoryAssociateTable,
    User,
    UserSubCategoryAssociateTable,
)


class UserRepository:
    base_model = User
    chat_users_model = ChatsAssociateTable
    chat_model = Chat
    message_model = Message

    post_model = Post
    post_sub_model = PostSubCategoryAssociateTable
    post_favorite_model = FavoriteAssociateTable
    post_like_model = LikerAssociateTable
    post_media_model = Media

    followers_model = FollowersAssociateTable
    user_sub_model = UserSubCategoryAssociateTable
    block_model = BlockedAssociateTable

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def update_user(
        self, user_id: int, data: UpdateProfileSchema
    ) -> ResponseUserTuple:
        async with self.get_db() as session:
            try:
                result_update = await session.execute(
                    update(self.base_model)
                    .where(self.base_model.id == user_id)
                    .values(**data.dict(exclude_unset=True))
                )

                if not result_update.rowcount:
                    return ResponseUserTuple(
                        error_code=404,
                        description=PersonProfileResponseEnum.USER_NOT_FOUND,
                    )

                result = await session.execute(
                    select(self.base_model)
                    .where(self.base_model.id == user_id)
                    .options(selectinload(self.base_model.subcategories))
                )

                user = result.scalars().first()

                await session.commit()
            except IntegrityError:
                return ResponseUserTuple(
                    error_code=400,
                    description=PersonProfileResponseEnum.NO_UNIQUE_USER_DATA,
                )
            return ResponseUserTuple(data=user)

    async def get_person_profile_by_id(self, user_id: int) -> ResponseUserTuple:
        async with self.get_db() as session:
            user = await self._get_profile_by_id(user_id, session)

            if not user:
                return ResponseUserTuple(
                    error_code=404,
                    description=PersonProfileResponseEnum.USER_NOT_FOUND,
                )

            return ResponseUserTuple(data=user)

    async def get_public_profile_by_id(
        self, user_id: int, public_user_id: int
    ) -> ResponseUserTuple:
        async with self.get_db() as session:
            user = await self._get_profile_by_id(public_user_id, session)

            if not user:
                return ResponseUserTuple(
                    error_code=404,
                    description=PersonProfileResponseEnum.USER_NOT_FOUND,
                )

            result_follow = await session.execute(
                select(FollowersAssociateTable).where(
                    and_(
                        FollowersAssociateTable.c.following_id == public_user_id,
                        FollowersAssociateTable.c.follower_id == user_id,
                    )
                )
            )

            result_blocked = await session.execute(
                select(BlockedAssociateTable).where(
                    and_(
                        BlockedAssociateTable.c.blocking_id == public_user_id,
                        BlockedAssociateTable.c.blocker_id == user_id,
                    )
                )
            )

            result_blocker = await session.execute(
                select(BlockedAssociateTable).where(
                    and_(
                        BlockedAssociateTable.c.blocker_id == public_user_id,
                        BlockedAssociateTable.c.blocking_id == user_id,
                    )
                )
            )

            user.is_follow = result_follow.scalar() is not None
            user.blocked_ = result_blocked.scalar() is not None
            user.blocker_ = result_blocker.scalar() is not None

            return ResponseUserTuple(data=user)

    async def _get_profile_by_id(
        self, user_id: int, session: AsyncSession
    ) -> Optional[User]:
        result = await session.execute(
            select(self.base_model)
            .where(self.base_model.id == user_id)
            .options(selectinload(self.base_model.subcategories))
        )

        return result.scalars().first()

    async def delete_user(self, user_id: int) -> None:
        async with self.get_db() as session:
            # удаление личных чатов
            result = await session.execute(
                select(self.chat_model.id)
                .join(self.chat_users_model)
                .where(
                    and_(
                        self.chat_users_model.c.user_id.in_((user_id,)),
                        self.chat_model.is_group.is_(False),
                    )
                )
            )
            chats = result.scalars().all()
            await session.execute(
                delete(self.chat_users_model).where(
                    self.chat_users_model.c.chat_id.in_(chats)
                )
            )
            await session.execute(
                delete(self.message_model).where(self.message_model.chat_id.in_(chats))
            )
            await session.execute(
                delete(self.chat_model).where(self.chat_model.id.in_(chats))
            )

            # удаление из списка пользователей групповых чатов
            await session.execute(
                delete(self.chat_users_model).where(
                    self.chat_users_model.c.user_id == user_id
                )
            )

            # удаление сообщений
            await session.execute(
                delete(self.message_model).where(self.message_model.from_id == user_id)
            )

            # удаление постов
            result = await session.execute(
                select(self.post_model.id).where(self.post_model.author_id == user_id)
            )
            posts = result.scalars().all()
            await session.execute(
                delete(self.post_favorite_model).where(
                    self.post_favorite_model.c.post_id.in_(posts)
                )
            )
            await session.execute(
                delete(self.post_like_model).where(
                    self.post_like_model.c.post_id.in_(posts)
                )
            )
            await session.execute(
                delete(self.post_sub_model).where(
                    self.post_sub_model.c.post_id.in_(posts)
                )
            )
            await session.execute(
                delete(self.post_media_model).where(
                    self.post_media_model.post_id.in_(posts)
                )
            )
            await session.execute(
                delete(self.post_model).where(self.post_model.author_id == user_id)
            )

            # удаление подписок и подписчиков
            result = await session.execute(
                select(self.followers_model.c.follower_id).where(
                    self.followers_model.c.following_id == user_id
                )
            )
            followers = result.scalars().all()
            await session.execute(
                update(self.base_model)
                .where(self.base_model.id.in_(followers))
                .values(count_followings=self.base_model.count_followings - 1)
            )
            result = await session.execute(
                select(self.followers_model.c.following_id).where(
                    self.followers_model.c.follower_id == user_id
                )
            )
            followings = result.scalars().all()
            await session.execute(
                update(self.base_model)
                .where(self.base_model.id.in_(followings))
                .values(count_followers=self.base_model.count_followers - 1)
            )
            await session.execute(
                delete(self.followers_model).where(
                    or_(
                        self.followers_model.c.follower_id == user_id,
                        self.followers_model.c.following_id == user_id,
                    )
                )
            )

            # удаление предпочтений
            await session.execute(
                delete(self.user_sub_model).where(self.user_sub_model == user_id)
            )

            # удаление блок-листов
            await session.execute(
                delete(self.block_model).where(
                    or_(
                        self.block_model.c.blocker_id == user_id,
                        self.block_model.c.blocking_id == user_id,
                    )
                )
            )

            # удаление профиля
            await session.execute(
                delete(self.base_model).where(self.base_model.id == user_id)
            )

            await session.commit()

    async def block_user(self, blocking_id: int, blocker: User) -> ResponseBlockTuple:
        async with self.get_db() as session:
            blocking = await session.get(self.base_model, blocking_id)

            if not blocking:
                return ResponseBlockTuple(
                    error_code=404, description=PersonProfileResponseEnum.USER_NOT_FOUND
                )

            try:
                await session.execute(
                    insert(self.block_model).values(
                        blocker_id=blocker.id, blocking_id=blocking.id
                    )
                )

                ### удаляем все связи
                # удаление чата
                result = await session.execute(
                    select(self.chat_model.id)
                    .join(self.chat_users_model)
                    .filter(self.chat_users_model.c.user_id == blocker.id)
                )
                user_chats = result.scalars().all()
                result = await session.execute(
                    select(self.chat_model)
                    .join(self.chat_users_model)
                    .filter(
                        and_(
                            self.chat_model.id.in_(user_chats),
                            self.chat_users_model.c.user_id == blocking.id,
                            self.chat_model.is_group.is_(False),
                        )
                    )
                )
                chat = result.scalars().first()
                if chat:
                    await session.execute(
                        delete(self.chat_model).where(self.chat_model.id == chat.id)
                    )

                # удаляем подписки
                result = await session.execute(
                    delete(self.followers_model).where(
                        and_(
                            self.followers_model.c.follower_id == blocker.id,
                            self.followers_model.c.following_id == blocking.id,
                        )
                    )
                )
                if result.rowcount:
                    blocker.count_followings -= 1
                    blocking.count_followers -= 1
                result = await session.execute(
                    delete(self.followers_model).where(
                        and_(
                            self.followers_model.c.follower_id == blocking.id,
                            self.followers_model.c.following_id == blocker.id,
                        )
                    )
                )
                if result.rowcount:
                    blocking.count_followings -= 1
                    blocker.count_followers -= 1
                session.add_all([blocker, blocking])

                await session.commit()
            except IntegrityError:
                return ResponseBlockTuple(
                    error_code=400,
                    description=PersonProfileResponseEnum.ALREADY_BLOCKED,
                )

        return ResponseBlockTuple()

    async def unblock_user(self, blocking_id: int, blocker: User) -> ResponseBlockTuple:
        async with self.get_db() as session:
            blocking = await session.get(self.base_model, blocking_id)

            if not blocking:
                return ResponseBlockTuple(
                    error_code=404, description=PersonProfileResponseEnum.USER_NOT_FOUND
                )

            try:
                result = await session.execute(
                    delete(self.block_model).where(
                        and_(
                            self.block_model.c.blocker_id == blocker.id,
                            self.block_model.c.blocking_id == blocking.id,
                        )
                    )
                )

                if not result.rowcount:
                    return ResponseBlockTuple(
                        error_code=400,
                        description=PersonProfileResponseEnum.ALREADY_UNBLOCKED,
                    )

                await session.commit()
            except IntegrityError:
                return ResponseBlockTuple(
                    error_code=500,
                    description=PersonProfileResponseEnum.ALREADY_UNBLOCKED,
                )

        return ResponseBlockTuple()
