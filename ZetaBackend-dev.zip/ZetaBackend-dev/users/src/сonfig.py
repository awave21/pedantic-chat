from pydantic import BaseSettings

from common.auth.jwt_handler import AuthHandler
from common.configs import JWTSettings


class AppSettings(BaseSettings):
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    DB_CONTAINER_NAME: str
    PORT_DB: str
    POSTGRES_DB: str
    DEBUG: int = 0


app_settings = AppSettings()
jwt_settings = JWTSettings()

auth_handler = AuthHandler(jwt_settings)
