from typing import List

from common.schemas.common import Page
from common.schemas.users import ShortPersonProfile


class FollowPage(Page):
    data: List[ShortPersonProfile] = []
