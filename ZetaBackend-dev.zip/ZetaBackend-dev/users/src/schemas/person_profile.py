from typing import Dict, List, Optional

from pydantic import BaseModel, Field, root_validator

from common.database.models import SubCategory, User
from common.enums.validators import ValidatorsErrorEnum


class SubCategorySchema(BaseModel):
    id: int
    category_id: int
    name: str
    icon: Optional[str]

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: SubCategory, locale: str = "en") -> "SubCategorySchema":
        return SubCategorySchema(
            id=obj.id,
            name=obj.name_en if locale == "en" else obj.name_ru,
            category_id=obj.category_id,
            icon=obj.icon,
        )


class PersonProfile(BaseModel):
    id: int
    nickname: str
    count_followers: int
    count_followings: int
    count_posts: int
    age: Optional[int]
    email: Optional[str]
    phone: Optional[str]
    avatar: Optional[str]
    about_me: Optional[str]
    subcategories: List[SubCategorySchema] = []

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: User, locale: str = "en") -> BaseModel:
        schema: BaseModel = super().from_orm(obj)
        schema.subcategories = [
            SubCategorySchema.from_orm(i, locale) for i in obj.subcategories
        ]
        return schema


class PublicProfile(PersonProfile):
    is_follow: bool = False
    blocked: bool = Field(False, alias="blocked_")
    blocker: bool = Field(False, alias="blocker_")

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: User, locale: str = "en") -> BaseModel:
        schema: BaseModel = super().from_orm(obj)
        if schema.blocked or schema.blocker:
            schema.count_posts = 0
            schema.count_followers = 0
            schema.count_followings = 0
            schema.age = 0
            schema.phone = None
            schema.email = None
            schema.subcategories = []

        return schema


class UpdateProfileSchema(BaseModel):
    age: Optional[int]
    nickname: Optional[str]
    about_me: Optional[str] = Field(max_length=1024)

    @root_validator(pre=True)
    def check_is_not_empty_data(cls, values: Dict) -> Dict:
        assert len(values), ValidatorsErrorEnum.FORM_EMPTY.to_str_dict_for_exception
        return values
