from typing import List

from common.schemas.common import Page
from common.schemas.users import ShortPersonProfile


class SearchPage(Page):
    data: List[ShortPersonProfile] = []
