from typing import Optional

from pydantic import BaseModel

from common.database.models import Document


class DocumentScheme(BaseModel):
    name: Optional[str] = "Документ №1"
    text: Optional[str] = "<p>Тело <strong>документа</strong></p>"

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Document, locale: str = "en") -> "DocumentScheme":
        return DocumentScheme(
            name=obj.name_eng if locale == "en" else obj.name,
            text=obj.text_eng if locale == "en" else obj.text,
        )
