from typing import List, NamedTuple, Optional, Tuple, Union

from enums.document import DocumentResponseEnum
from enums.follow import FollowResponseEnum
from enums.person_profile import PersonProfileResponseEnum
from enums.search import SearchResponseEnum
from our_types import FollowersWithCount

from common.database.models import Document, User


class ResponseUserTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[PersonProfileResponseEnum] = None
    data: Union[List[User], User, None] = None


class ResponseFollowTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[FollowResponseEnum] = None
    data: Union[List[User], User, None] = None


class ResponseFollowWithCountTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[FollowResponseEnum] = None
    data: Union[FollowersWithCount, None] = None


class ResponseSearchTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[SearchResponseEnum] = None
    data: Tuple[List[User], int] = [], 0


class ResponseDocumentTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[DocumentResponseEnum] = None
    data: Optional[Document] = None


class ResponseBlockTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[PersonProfileResponseEnum] = None
    data: Union[List[User], User, None] = None
