#!/usr/bin/env bash

envsubst '${ADMIN_CONTAINER_NAME},${PORT_ADMIN}, \
${AUTH_CONTAINER_NAME},${PORT_AUTH}, \
${CORE_CONTAINER_NAME},${PORT_CORE}, \
${USERS_CONTAINER_NAME},${PORT_USERS}, \
${UPLOADER_CONTAINER_NAME},${PORT_UPLOADER}, \
${WS_CONTAINER_NAME},${PORT_WS}, \
${CHATS_CONTAINER_NAME},${PORT_CHATS}' \
 < /etc/nginx/templates/app.conf.template > /etc/nginx/conf.d/default.conf

#cat /etc/nginx/conf.d/default.conf

sleep 2
nginx -g "daemon off;"