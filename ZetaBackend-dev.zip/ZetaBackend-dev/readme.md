### Что нужно знать о проекте ZetaBackend ###

<p>env файлы лежат в папке env_files. Пока там один общий файл, в будущем планируется  
увеличение зависимостей путём создания новых env файлов для каждой апки</p>


<p>В папке сommon.database лежат модельки для нашего проекта</p>

#### Как разворачиваем проект ####

1. make build up
2. docker exec -it db psql -U postgres 
3. create database zeta; и уходим из консоли дб
4. make migrate


#### Инициализация линтера ####
1. make precommit-install


#### Работа с poetry ####
У каждого апки свою окружение poetry. Выполнять команды на уровне файла  
poetry.toml.
1. poetry add <> - добавить библиотеку
2. poetry add -D <> - добавить библиотеку на develop
3. poetry remove <> - удалить библиотеку
4. poetry show - все установленные библиотеки

#### Работа с миграциями ####

1. make makemigrations name="migrations name"
2. make migrate

