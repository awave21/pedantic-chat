from typing import Any, Dict, List, Union

from fastapi import WebSocket

from common.database.models import User


class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    async def bind(self, websocket: WebSocket, user: User) -> "UserManager":
        await self.connect(websocket, user.id)
        return UserManager(websocket, user, self)

    def disconnect(self, user_id: int):
        self.active_connections.pop(user_id, None)

    async def fetch(self, user_id: int) -> Any:
        if self.active_connections.get(user_id):
            return await self.active_connections[user_id].receive_json()

    async def _send_data(self, data: Union[dict, List[dict]], websocket: WebSocket):
        await websocket.send_json(data)

    async def send_data_to_user(self, user_id: int, data: Union[dict, List[dict]]):
        if self.active_connections.get(user_id):
            await self._send_data(data, self.active_connections[user_id])

    async def send_data_to_users(
        self, data: Union[dict, List[dict]], users_list: List[int]
    ):
        for user in users_list:
            await self.send_data_to_user(user, data)


class UserManager:
    def __init__(
        self, websocket: WebSocket, user: User, connection_manager: ConnectionManager
    ):
        self.user = user
        self.websocket = websocket
        self.connection_manager = connection_manager

    def disconnect(self):
        self.connection_manager.disconnect(self.user.id)

    async def send_data(self, data: Dict, receivers: List[int]):
        await self.connection_manager.send_data_to_users(data, receivers)

    async def fetch(self) -> Any:
        return await self.connection_manager.fetch(self.user.id)
