import json
from typing import Dict

from connection_manager import ConnectionManager, UserManager
from depends import get_commands_service, get_connection_manager, get_user_manager
from fastapi import Depends, FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError
from schemas.commands import CommandSchema, EventSchema
from services.commands import CommandsService
from сonfig import app_settings, auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.translate.middlewares import LanguageMiddleware

app = FastAPI(
    debug=app_settings.DEBUG, openapi_url="/ws/openapi.json", docs_url="/ws/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LanguageMiddleware)


@app.websocket("/ws/connect")
async def websocket_endpoint(
    websocket: WebSocket,
    user_manager: UserManager = Depends(get_user_manager),
    commands_service: CommandsService = Depends(get_commands_service),
):
    token = websocket.headers.get("authorization", "")
    try:
        while True:
            data = await user_manager.fetch()
            try:
                cmd = CommandSchema(**data)
            except ValidationError as e:
                await user_manager.send_data(
                    json.loads(e.json()), [user_manager.user.id]
                )
                continue
            await commands_service.handle_command(cmd.cmd, cmd.data, token=token)
    except WebSocketDisconnect:
        print(f"USER {user_manager.user.nickname}#{user_manager.user.id} DISCONNECTED")
        user_manager.disconnect()


@app.post(
    "/ws/event",
    response_model=Dict,
    status_code=201,
    description="""Создание чата""",
)
async def websocket_event(
    request: Request,
    data: EventSchema,
    connection_manager: ConnectionManager = Depends(get_connection_manager),
):
    await connection_manager.send_data_to_users(
        {"event": data.event, "data": data.data}, data.user_ids
    )

    return {}
