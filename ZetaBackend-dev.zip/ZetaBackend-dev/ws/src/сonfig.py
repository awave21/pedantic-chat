from pydantic import BaseSettings

from common.auth.jwt_handler import AuthHandler
from common.configs import JWTSettings


class AppSettings(BaseSettings):
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    DB_CONTAINER_NAME: str
    PORT_DB: str
    POSTGRES_DB: str
    DEBUG: int = 0

    CHATS_CONTAINER_NAME: str
    PORT_CHATS: int


class NetworkSettings(BaseSettings):
    USERS_CONTAINER_NAME: str
    PORT_USERS: str
    UPLOADER_CONTAINER_NAME: str
    PORT_UPLOADER: str


app_settings = AppSettings()
jwt_settings = JWTSettings()
network_settings = NetworkSettings()

auth_handler = AuthHandler(jwt_settings)
