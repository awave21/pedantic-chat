from typing import Dict, List, NamedTuple, Optional, Tuple, Union

from common.database.models import Category, Post
from common.enums.languages import AbstractLangEnum


class ResponsePostTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Union[Post, List[Post], None] = None


class ResponsePostsAndCountTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Tuple[List[Post], int] = [], 0


class ResponseCategoryTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[Category, List[Category], Dict, List[Dict], None] = None


class ResponseNetworkUsersTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[str] = None
    data: Union[Dict, List[Dict]] = []
