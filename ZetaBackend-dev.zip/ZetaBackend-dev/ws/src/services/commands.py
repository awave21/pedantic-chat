import json
from typing import Any, Dict, List, Optional, Tuple

import aiohttp
import requests
from сonfig import app_settings


class CommandsService:
    def __init__(self):
        pass

    @staticmethod
    async def create_message(
        user_id: int = None,
        chat_id: int = None,
        text: Optional[str] = None,
        media: Optional[List[int]] = [],
        token: str = "",
    ):
        async with aiohttp.ClientSession() as session:
            url = f"http://{app_settings.CHATS_CONTAINER_NAME}:{app_settings.PORT_CHATS}/chats/messages"
            async with session.post(
                url,
                json={
                    "user_id": user_id,
                    "chat_id": chat_id,
                    "text": text,
                    "media": media,
                },
                headers={"authorization": token},
            ) as resp:
                await resp.json()

    @staticmethod
    async def read_messages(
        chat_id: int = None,
        token: str = "",
    ):
        async with aiohttp.ClientSession() as session:
            url = f"http://{app_settings.CHATS_CONTAINER_NAME}:{app_settings.PORT_CHATS}/chats/{chat_id}/read"
            async with session.get(url, headers={"authorization": token}) as resp:
                await resp.json()

    @staticmethod
    async def get_chat_users(
        chat_id: int = None, user_id: int = None, token: str = "", **kwargs
    ):
        if user_id:
            url = f"http://{app_settings.CHATS_CONTAINER_NAME}:{app_settings.PORT_CHATS}/chats/{user_id}?is_user=true"
        else:
            url = f"http://{app_settings.CHATS_CONTAINER_NAME}:{app_settings.PORT_CHATS}/chats/{chat_id}"
        result = requests.get(url, headers={"authorization": token})

        result = json.loads(result.content)
        return [user["id"] for user in result["users"]]

    COMMANDS = {
        "send_message": create_message.__func__,
        "read_messages": read_messages.__func__,
    }

    async def handle_command(self, cmd: str, data: dict, token: str = "") -> Any:
        if cmd not in self.COMMANDS.keys():
            return "error"
        return await self.COMMANDS[cmd](**data, token=token)
