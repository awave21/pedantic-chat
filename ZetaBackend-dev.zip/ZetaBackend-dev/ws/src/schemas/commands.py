from typing import Dict, List

from pydantic import BaseModel


class CommandSchema(BaseModel):
    cmd: str
    data: Dict


class EventSchema(BaseModel):
    event: str
    user_ids: List[int]
    data: Dict
