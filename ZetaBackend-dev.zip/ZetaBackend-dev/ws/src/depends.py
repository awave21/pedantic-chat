from connection_manager import ConnectionManager, UserManager
from fastapi import Depends, WebSocket
from services.commands import CommandsService
from сonfig import auth_handler, network_settings

from common.auth.jwt_bearer import get_jwt_bearer
from common.db import get_db

# post_repository = PostRepository(get_db)
# categories_repository = CategoriesRepository(get_db)
# search_interest_repository = SearchInterestRepository(get_db)
# network_service = NetworkService(network_settings)

commands_service = CommandsService()
connection_manager = ConnectionManager()


async def get_commands_service() -> CommandsService:
    return commands_service


def get_connection_manager() -> ConnectionManager:
    return connection_manager


async def get_user_manager(
    websocket: WebSocket,
    user=Depends(get_jwt_bearer(auth_handler)),
    connection_manager: ConnectionManager = Depends(get_connection_manager),
) -> UserManager:
    return await connection_manager.bind(websocket, user)
