from response_tuples import ResponseCategoryTuple

from common.repositories.categories import CategoriesRepository


class CategoriesService:
    def __init__(self, categories_repository: CategoriesRepository):
        self.categories_repository = categories_repository

    async def list_categories(self) -> ResponseCategoryTuple:
        return await self.categories_repository.list_categories()
