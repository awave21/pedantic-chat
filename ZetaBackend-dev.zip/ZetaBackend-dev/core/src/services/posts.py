from typing import Optional

from enums.posts import PostResponseEnum
from our_types import OrderPostsType
from repositories.posts import PostRepository
from response_tuples import (
    ResponsePostsAndCountTuple,
    ResponsePostTuple,
    ResponseReportTuple,
)
from schemas.posts import PostCreateSchema, ReportCreateSchema
from services.network import NetworkService
from сonfig import auth_handler

from common.database.models import User
from common.repositories.categories import CategoriesRepository


class PostService:
    def __init__(
        self,
        post_repository: PostRepository,
        category_repository: CategoriesRepository,
        network_service: NetworkService,
    ) -> None:
        self.post_repository = post_repository
        self.category_repository = category_repository
        self.network_service = network_service

    async def create_post(
        self, post_data: PostCreateSchema, user: User
    ) -> ResponsePostTuple:
        subcategories = (
            await self.category_repository.get_unarchive_subcategories_by_ids(
                post_data.subcategories_id
            )
        )

        if len(subcategories) != len(post_data.subcategories_id):
            return ResponsePostTuple(
                error_code=400, description=PostResponseEnum.INTERESTS_NOT_FOUND
            )

        result = await self.post_repository.create_post(post_data, user, subcategories)

        return result

    async def get_post_by_id(self, user: User, post_id: int) -> ResponsePostTuple:
        return await self.post_repository.get_post_by_id(user, post_id)

    async def delete_post_by_id(self, post_id: int, user: User) -> ResponsePostTuple:
        post = await self.post_repository.get_post_by_id(user, post_id)
        if post.error_code:
            return post
        if post.data.author_id != user.id and user.is_admin is False:
            return ResponsePostTuple(
                error_code=403, description=PostResponseEnum.POST_FORBIDDEN
            )
        links = await self.post_repository.delete_post_by_id(post_id)

        # Удалить линки на бакете
        try:
            admin_user = await self.post_repository._get_admin_user()
            admin_jwt = auth_handler.encode_login_token(admin_user.id)["access_token"]
            admin_jwt = f"Bearer {admin_jwt}"
            await self.network_service.delete_media_links(links, admin_jwt)
        except Exception as e:
            print(f"Failed to delete media links {e}")

        return ResponsePostTuple()

    async def list_posts(
        self,
        user: User,
        page: int,
        limit: int,
    ) -> ResponsePostTuple:
        return await self.post_repository.list_posts(user, page, limit)

    async def list_subcategory_posts(
        self,
        user: User,
        page: int,
        limit: int,
        order_by: OrderPostsType,
        subcategory_id: Optional[int] = None,
    ) -> ResponsePostsAndCountTuple:
        return await self.post_repository.list_subcategory_posts(
            user, page, limit, order_by, subcategory_id
        )

    async def list_favorite_posts(
        self, user: User, page: int, limit: int
    ) -> ResponsePostTuple:
        return await self.post_repository.list_favorite_posts(user, page, limit)

    async def list_my_posts(
        self, user: User, page: int, limit: int
    ) -> ResponsePostTuple:
        return await self.post_repository.list_my_posts(user, page, limit)

    async def list_posts_by_author_id(
        self, user: User, author_id: int, page: int, limit: int
    ) -> ResponsePostTuple:
        if await self.post_repository._check_blocked(author_id, user):
            return ResponsePostTuple(data=[])
        return await self.post_repository.list_posts_by_author_id(
            user, author_id, page, limit
        )

    async def like_post(self, user: User, post_id: int) -> ResponsePostTuple:
        return await self.post_repository.like_post(user, post_id)

    async def unlike_post(self, user: User, post_id: int) -> ResponsePostTuple:
        return await self.post_repository.unlike_post(user, post_id)

    async def favorite_post(self, user: User, post_id: int) -> ResponsePostTuple:
        return await self.post_repository.favorite_post(user, post_id)

    async def unfavorite_post(self, user: User, post_id: int) -> ResponsePostTuple:
        return await self.post_repository.unfavorite_post(user, post_id)

    async def create_report(
        self, report_data: ReportCreateSchema, user: User
    ) -> ResponsePostTuple:
        post = await self.post_repository.get_post_by_id(user, report_data.post_id)

        if not post:
            return ResponseReportTuple(
                error_code=404, description=PostResponseEnum.POST_NOT_FOUND
            )

        result = await self.post_repository.create_report(report_data, user)

        return result

    async def list_reports(
        self,
        page: int,
        limit: int,
    ) -> ResponseReportTuple:
        return await self.post_repository.list_reports(page, limit)

    async def solve_report(self, report_id: int) -> int:
        return await self.post_repository.solve_report(report_id)
