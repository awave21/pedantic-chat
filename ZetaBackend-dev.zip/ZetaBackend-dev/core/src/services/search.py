from typing import Dict, List

from repositories.search import SearchInterestRepository
from schemas.categories import ListPopularSubCategorySchema, SearchResultsSchema
from services.network import NetworkService

from common.database.models import Post, SubCategory


class SearchInterestService:
    def __init__(
        self,
        search_interest_repository: SearchInterestRepository,
        network_service: NetworkService,
    ):
        self.search_interest_repository = search_interest_repository
        self.network_service = network_service

    async def list_popular_subcategories(
        self, locale: str = "en"
    ) -> List[ListPopularSubCategorySchema]:
        subcategories_dict = (
            await self.search_interest_repository.list_popular_subcategories()
        )

        return self._from_dict_subcategories_to_schema(subcategories_dict, locale)

    async def search_subcategories(
        self, startswith: str, auth_header: str, locale: str = "en"
    ) -> SearchResultsSchema:

        subcategories_dict = await self.search_interest_repository.search_subcategories(
            startswith
        )

        result = await self.network_service.search_user_by_nickname_with_3_limit(
            startswith, auth_header
        )
        subcategories = self._from_dict_subcategories_to_schema(
            subcategories_dict, locale
        )
        return SearchResultsSchema(users=result.data, subcategories=subcategories)

    @staticmethod
    def _from_dict_subcategories_to_schema(
        subcategories_dict: Dict[SubCategory, List[Post]], locale: str = "en"
    ) -> List[ListPopularSubCategorySchema]:
        return [
            ListPopularSubCategorySchema(
                id=subcategory.id,
                category_id=subcategory.id,
                name=subcategory.name_en if locale == "en" else subcategory.name_ru,
                icon=subcategory.icon,
                posts=posts,
            )
            for subcategory, posts in subcategories_dict.items()
        ]
