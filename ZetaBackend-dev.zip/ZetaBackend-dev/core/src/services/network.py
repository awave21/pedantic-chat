from typing import List

import aiohttp
from response_tuples import ResponseNetworkUsersTuple
from сonfig import NetworkSettings


class NetworkService:
    def __init__(self, network_settings: NetworkSettings) -> None:
        self._user_service_url = f"http://{network_settings.USERS_CONTAINER_NAME}:{network_settings.PORT_USERS}"
        self._uploader_url = f"http://{network_settings.UPLOADER_CONTAINER_NAME}:{network_settings.PORT_UPLOADER}"
        self._search_user_by_nickname_link = "/users/search"
        self._delete_medias_link = "/uploader/post/delete_medias"

    async def search_user_by_nickname_with_3_limit(
        self, search_string: str, auth_header: str
    ) -> ResponseNetworkUsersTuple:
        """
        Делает запрос на поиск пользователей по нику в сервис users
        """

        # Формируем url, from-data, headers
        url = f"{self._user_service_url}{self._search_user_by_nickname_link}?nickname={search_string}&limit=3&page=0"
        headers = {
            "authorization": auth_header,
        }

        # Обращаемся к аплоадеру
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                result = await response.json()
                if response.ok:
                    return ResponseNetworkUsersTuple(data=result.get("data"))
                else:
                    return ResponseNetworkUsersTuple(
                        error_code=response.status, description=result.get("detail")
                    )

    async def delete_media_links(self, links: List[str], auth_header: str) -> None:
        """
        Делает запрос к аплоадеру для удаления картинок с хранилки
        """

        url = f"{self._uploader_url}{self._delete_medias_link}"
        headers = {
            "authorization": auth_header,
        }
        json = {"links": links}

        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=json):
                pass
