from typing import Callable, List, Literal, Optional

from enums.posts import PostResponseEnum
from our_types import OrderPostsType
from response_tuples import (
    ResponsePostsAndCountTuple,
    ResponsePostTuple,
    ResponseReportTuple,
)
from schemas.posts import PostCreateSchema, ReportCreateSchema
from sqlalchemy import and_, delete, desc, func, or_, update
from sqlalchemy.exc import IntegrityError, InvalidRequestError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import (
    aliased,
    contains_eager,
    joinedload,
    selectinload,
    sessionmaker,
    subqueryload,
)

from common.database.models import (
    BlockedAssociateTable,
    FavoriteAssociateTable,
    FollowersAssociateTable,
    LikerAssociateTable,
    Media,
    Post,
    PostSubCategoryAssociateTable,
    Report,
    SubCategory,
    User,
    UserSubCategoryAssociateTable,
)


class PostRepository:
    base_model = Post

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def create_post(
        self,
        data: PostCreateSchema,
        user: User,
        subcategories: List[SubCategory],
    ) -> ResponsePostTuple:
        async with self.get_db() as session:
            post = self.base_model(
                **data.dict(exclude={"subcategories_id"}),
                author=user,
                subcategories=subcategories,
                is_draft=True,
            )
            try:
                session.add(post)
                await session.commit()
                await session.flush(post)
            except IntegrityError:
                return ResponsePostTuple(
                    error_code=500, description=PostResponseEnum.POST_NOT_CREATED
                )
            return ResponsePostTuple(data=post)

    async def delete_post_by_id(self, post_id: int) -> Optional[List[str]]:
        async with self.get_db() as session:
            post = await session.get(Post, post_id)

            if not post:
                return None

            await session.execute(
                delete(FavoriteAssociateTable).where(
                    FavoriteAssociateTable.c.post_id == post_id
                )
            )

            await session.execute(
                delete(LikerAssociateTable).where(
                    LikerAssociateTable.c.post_id == post_id
                )
            )

            await session.execute(
                delete(PostSubCategoryAssociateTable).where(
                    PostSubCategoryAssociateTable.c.post_id == post_id
                )
            )

            links = await session.execute(
                delete(Media).where(Media.post_id == post_id).returning(Media.link)
            )

            await session.execute(delete(Report).where(Report.post_id == post_id))

            links = links.scalars().all()

            await session.delete(post)
            await session.commit()

            return links

    async def get_post_by_id(self, user: User, post_id: int) -> ResponsePostTuple:
        async with self.get_db() as session:
            post = await self._get_post_by_id_with_joins(post_id, session)

            if not post:
                return ResponsePostTuple(
                    error_code=404, description=PostResponseEnum.POST_NOT_FOUND
                )

        post.set_optional_fields_for_list_view(user.id)
        return ResponsePostTuple(data=post)

    async def list_posts(
        self,
        user: User,
        page: int,
        limit: int,
    ) -> ResponsePostTuple:
        async with self.get_db() as session:
            subcategory_ids = (
                select(SubCategory.id)
                .join(UserSubCategoryAssociateTable)
                .where(UserSubCategoryAssociateTable.c.user_id == user.id)
                .scalar_subquery()
            )

            following_ids = (
                select(User.id)
                .join(
                    FollowersAssociateTable,
                    User.id == FollowersAssociateTable.c.following_id,
                )
                .where(FollowersAssociateTable.c.follower_id == user.id)
                .scalar_subquery()
            )

            posts_query = (
                select(self.base_model)
                .join(self.base_model.author)
                .outerjoin(self.base_model.subcategories)
                .where(
                    or_(User.id.in_(following_ids), SubCategory.id.in_(subcategory_ids))
                )
                .options(
                    contains_eager(self.base_model.author),
                    subqueryload(self.base_model.subcategories),
                    subqueryload(self.base_model.medias),
                    selectinload(self.base_model.favorite_for),
                    selectinload(self.base_model.likers),
                )
                .where(self.base_model.is_draft.is_(False))
                .order_by(desc(self.base_model.created_at))
                .distinct()
            )

            # Узнаём наличие подходящих постов (иначе наличие пагинации все сломает)
            count_posts = await session.execute(
                select(func.count()).select_from(posts_query.subquery())
            )
            count_posts = count_posts.scalar_one()

            # Пытаемся взять посты с необходимыми авторами и интересами (с учётом пагинации)
            if count_posts:
                posts = await session.scalars(
                    posts_query.limit(limit).offset(page * limit)
                )
                posts = posts.all()
            else:
                # Если постов по фильтрам нет - берем все посты (с учётом пагинации)
                posts = await session.scalars(
                    select(self.base_model)
                    .options(
                        joinedload(self.base_model.author),
                        subqueryload(self.base_model.subcategories),
                        subqueryload(self.base_model.medias),
                        selectinload(self.base_model.favorite_for),
                        selectinload(self.base_model.likers),
                    )
                    .where(self.base_model.is_draft.is_(False))
                    .order_by(desc(self.base_model.created_at))
                    .limit(limit)
                    .offset(page * limit)
                )
                posts = posts.all()

            for post in posts:
                post.set_optional_fields_for_list_view(user.id)

            return ResponsePostTuple(data=posts)

    async def list_subcategory_posts(
        self,
        user: User,
        page: int,
        limit: int,
        order_by: OrderPostsType,
        subcategory_id: int,
    ) -> ResponsePostsAndCountTuple:

        async with self.get_db() as session:
            # сортировка по популярности или по дате
            where_expr = and_(
                self.base_model.is_draft.is_(False),
                PostSubCategoryAssociateTable.columns.subcategory_id == subcategory_id,
            )

            if order_by == "top":
                order_by_expr = desc(
                    select(func.count()).where(
                        LikerAssociateTable.c.post_id == self.base_model.id
                    )
                )
            else:
                order_by_expr = desc(self.base_model.created_at)
            # выполняем запрос на количество
            # todo: it could be better, so we need to refactor it
            result_count = await session.execute(
                select(func.count())
                .join(PostSubCategoryAssociateTable)
                .where(where_expr)
            )

            # выполняем запрос
            result = await session.execute(
                select(self.base_model)
                .join(PostSubCategoryAssociateTable)
                .options(
                    joinedload(self.base_model.author),
                    subqueryload(self.base_model.subcategories),
                    subqueryload(self.base_model.medias),
                    selectinload(self.base_model.favorite_for),
                    selectinload(self.base_model.likers),
                )
                .where(where_expr)
                .order_by(order_by_expr)
                .limit(limit)
                .offset(page * limit)
            )

            posts = result.scalars().all()
            for post in posts:
                post.set_optional_fields_for_list_view(user.id)

            count = result_count.scalar()
            return ResponsePostsAndCountTuple(data=(posts, count))

    async def list_favorite_posts(
        self, user: User, page: int, limit: int
    ) -> ResponsePostTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .join(FavoriteAssociateTable)
                .options(
                    joinedload(self.base_model.author),
                    subqueryload(self.base_model.subcategories),
                    subqueryload(self.base_model.medias),
                    selectinload(self.base_model.likers),
                )
                .where(FavoriteAssociateTable.columns.user_id == user.id)
                .order_by(desc(FavoriteAssociateTable.columns.created_at))
                .limit(limit)
                .offset(page * limit)
            )

            posts = result.scalars().all()
            for post in posts:
                post.set_optional_fields_for_favorite_list_view(user.id)

            return ResponsePostTuple(data=posts)

    async def list_my_posts(
        self, user: User, page: int, limit: int
    ) -> ResponsePostTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .options(
                    joinedload(self.base_model.author),
                    subqueryload(self.base_model.subcategories),
                    subqueryload(self.base_model.medias),
                    selectinload(self.base_model.favorite_for),
                    selectinload(self.base_model.likers),
                )
                .where(
                    and_(
                        self.base_model.author == user,
                        self.base_model.is_draft.is_(False),
                    )
                )
                .order_by(desc(self.base_model.created_at))
                .limit(limit)
                .offset(page * limit)
            )

            posts = result.scalars().all()
            for post in posts:
                post.set_optional_fields_for_list_view(user.id)

            return ResponsePostTuple(data=posts)

    async def list_posts_by_author_id(
        self, user: User, author_id: int, page: int, limit: int
    ) -> ResponsePostTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .join(self.base_model.author)
                .options(
                    contains_eager(self.base_model.author),
                    subqueryload(self.base_model.subcategories),
                    subqueryload(self.base_model.medias),
                    selectinload(self.base_model.favorite_for),
                    selectinload(self.base_model.likers),
                )
                .where(
                    and_(
                        User.id == author_id,
                        self.base_model.is_draft.is_(False),
                    )
                )
                .order_by(desc(self.base_model.created_at))
                .limit(limit)
                .offset(page * limit)
            )

            posts = result.scalars().all()
            for post in posts:
                post.set_optional_fields_for_list_view(user.id)

            return ResponsePostTuple(data=posts)

    async def like_post(self, user: User, post_id: int) -> ResponsePostTuple:
        async with self.get_db() as session:
            try:
                post = await self._get_post_by_id_with_joins(post_id, session)

                if not post:
                    return ResponsePostTuple(
                        error_code=404, description=PostResponseEnum.POST_NOT_FOUND
                    )

                if user == post.author:
                    post.likers.append(post.author)
                elif user in post.favorite_for:
                    for favorite in post.favorite_for:
                        if favorite == user:
                            post.likers.append(favorite)
                            break
                else:
                    post.likers.append(user)

                await session.commit()
            except IntegrityError:
                return ResponsePostTuple(
                    error_code=400, description=PostResponseEnum.POST_ALREADY_LIKED
                )
            except InvalidRequestError:
                return ResponsePostTuple(
                    error_code=500, description=PostResponseEnum.POST_NOT_LIKED
                )

        post.set_optional_fields_for_list_view(user.id)
        return ResponsePostTuple(data=post)

    async def unlike_post(self, user: User, post_id: int) -> ResponsePostTuple:
        async with self.get_db() as session:
            try:
                post = await self._get_post_by_id_with_joins(post_id, session)

                if not post:
                    return ResponsePostTuple(
                        error_code=404, description=PostResponseEnum.POST_NOT_FOUND
                    )

                post.likers.remove(user)

                await session.commit()
            except ValueError:
                return ResponsePostTuple(
                    error_code=400, description=PostResponseEnum.POST_ALREADY_UNLIKED
                )

        post.set_optional_fields_for_list_view(user.id)
        return ResponsePostTuple(data=post)

    async def favorite_post(self, user: User, post_id: int) -> ResponsePostTuple:
        async with self.get_db() as session:
            try:
                post = await self._get_post_by_id_with_joins(post_id, session)

                if not post:
                    return ResponsePostTuple(
                        error_code=404, description=PostResponseEnum.POST_NOT_FOUND
                    )

                if user == post.author:
                    post.favorite_for.append(post.author)
                elif user in post.likers:
                    for liker in post.likers:
                        if liker == user:
                            post.favorite_for.append(liker)
                            break
                else:
                    post.favorite_for.append(user)

                await session.commit()
            except IntegrityError:
                return ResponsePostTuple(
                    error_code=400, description=PostResponseEnum.POST_ALREADY_FAVORITE
                )
            except InvalidRequestError:
                return ResponsePostTuple(
                    error_code=500, description=PostResponseEnum.POST_NOT_FAVORITE
                )

        post.set_optional_fields_for_list_view(user.id)
        return ResponsePostTuple(data=post)

    async def unfavorite_post(self, user: User, post_id: int) -> ResponsePostTuple:
        async with self.get_db() as session:
            try:
                post = await self._get_post_by_id_with_joins(post_id, session)

                if not post:
                    return ResponsePostTuple(
                        error_code=404, description=PostResponseEnum.POST_NOT_FOUND
                    )

                post.favorite_for.remove(user)

                await session.commit()
            except (IntegrityError, ValueError):
                return ResponsePostTuple(
                    error_code=400, description=PostResponseEnum.POST_ALREADY_UNFAVORITE
                )

        post.set_optional_fields_for_list_view(user.id)
        return ResponsePostTuple(data=post)

    async def create_report(
        self,
        data: ReportCreateSchema,
        user: User,
    ) -> ResponseReportTuple:
        async with self.get_db() as session:
            report = Report(
                **data.dict(),
                user_id=user.id,
            )
            try:
                session.add(report)
                await session.commit()
                await session.flush(report)
            except IntegrityError:
                return ResponseReportTuple(
                    error_code=500, description=PostResponseEnum.POST_NOT_CREATED
                )
            return ResponseReportTuple(data=report)

    async def list_reports(
        self,
        page: int,
        limit: int,
    ) -> ResponseReportTuple:
        async with self.get_db() as session:
            where_ = Report.solved.is_(False)
            reports = await session.scalars(
                select(Report)
                .options(
                    joinedload(Report.user),
                    selectinload(Report.post),
                    selectinload(Report.post).joinedload(self.base_model.author),
                    selectinload(Report.post).subqueryload(
                        self.base_model.subcategories
                    ),
                    selectinload(Report.post).subqueryload(self.base_model.medias),
                    selectinload(Report.post).selectinload(
                        self.base_model.favorite_for
                    ),
                    selectinload(Report.post).selectinload(self.base_model.likers),
                )
                .where(where_)
                .order_by(desc(Report.created_at))
                .limit(limit)
                .offset(page * limit)
            )
            reports = reports.all()
            reports_count = await session.execute(
                select(func.count()).select_from(Report).where(where_)
            )

            reports_count = reports_count.scalar()

            for report in reports:
                report.post.set_optional_fields_for_list_view(report.user.id)

            return ResponseReportTuple(data=(reports, reports_count))

    async def solve_report(self, report_id: int) -> int:
        async with self.get_db() as session:
            result = await session.execute(
                update(Report)
                .where(Report.id == report_id)
                .values(solved=True)
                .returning(*Report.__table__.c)
            )
            report = result.first()
            await session.commit()
            return report.id

    async def _get_post_by_id_with_joins(
        self, post_id: int, session: AsyncSession
    ) -> Optional[Post]:
        result = await session.execute(
            select(self.base_model)
            .where(self.base_model.id == post_id)
            .options(
                joinedload(self.base_model.author),
                subqueryload(self.base_model.subcategories),
                subqueryload(self.base_model.medias),
                selectinload(self.base_model.favorite_for),
                selectinload(self.base_model.likers),
            )
            .where(self.base_model.is_draft.is_(False))
        )

        return result.scalars().first()

    async def _get_admin_user(self) -> User:
        """Вспомогательный метод для получения администратора для межсервисных взаимодействий"""
        async with self.get_db() as session:
            result = await session.execute(select(User).where(User.is_admin.is_(True)))

        return result.scalars().first()

    async def _check_blocked(self, user_id: int, user: User) -> bool:
        """Проверка заблокирован ли пользователь"""
        async with self.get_db() as session:
            result = await session.execute(
                select(BlockedAssociateTable).where(
                    or_(
                        and_(
                            BlockedAssociateTable.c.blocking_id == user_id,
                            BlockedAssociateTable.c.blocker_id == user.id,
                        ),
                        and_(
                            BlockedAssociateTable.c.blocker_id == user_id,
                            BlockedAssociateTable.c.blocking_id == user.id,
                        ),
                    )
                )
            )

        return result.scalar() is not None
