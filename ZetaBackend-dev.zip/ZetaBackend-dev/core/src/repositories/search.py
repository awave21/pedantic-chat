from typing import Callable, Dict, List, Tuple

from sqlalchemy import and_, desc, func, or_, union
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload, sessionmaker
from sqlalchemy.orm.util import AliasedClass, aliased
from sqlalchemy.sql import Alias, Select

from common.database.models import (
    Category,
    LikerAssociateTable,
    Media,
    Post,
    PostSubCategoryAssociateTable,
    SubCategory,
)


class SearchInterestRepository:
    post_model = Post
    category_model = Category
    subcategory_model = SubCategory
    media_model = Media
    post_subcategory_associated_model = PostSubCategoryAssociateTable
    post_liker_associated_model = LikerAssociateTable

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def list_popular_subcategories(self) -> Dict[SubCategory, List[Post]]:
        async with self.get_db() as session:
            popular_posts_alias = self._get_aliased_for_popular_post_subcategory()

            # Подзапрос для количества лайков поста в основном запросе,
            # используемый для сортировки постов
            count_post_liker_for_sub_order_by = (
                select(func.count())
                .where(LikerAssociateTable.c.post_id == popular_posts_alias.id)
                .scalar_subquery()
            )

            result_subcategories = await session.execute(
                select(self.subcategory_model, popular_posts_alias)
                .order_by(
                    desc(self._get_query_for_subcategory_order_by_count_posts()),
                    desc(count_post_liker_for_sub_order_by),
                    desc(popular_posts_alias.created_at),
                )
                .options(selectinload(popular_posts_alias.medias))
            )

            return self._from_result_subcategories_to_dict(
                result_subcategories.fetchall()
            )

    async def search_subcategories(
        self, startswith: str
    ) -> Dict[SubCategory, List[Post]]:
        async with self.get_db() as session:
            popular_posts_alias = self._get_aliased_for_popular_post_subcategory()

            # Подзапрос для количества лайков поста в основном запросе,
            # используемый для сортировки постов
            count_post_liker_for_sub_order_by = (
                select(func.count())
                .where(LikerAssociateTable.c.post_id == popular_posts_alias.id)
                .scalar_subquery()
            )

            subcategories = await session.execute(
                select(self.subcategory_model, popular_posts_alias)
                .where(
                    or_(
                        func.lower(self.subcategory_model.name_ru).startswith(
                            startswith.lower()
                        ),
                        func.lower(self.subcategory_model.name_en).startswith(
                            startswith.lower()
                        ),
                    )
                )
                .order_by(
                    desc(count_post_liker_for_sub_order_by),
                    desc(popular_posts_alias.created_at),
                )
                .options(selectinload(popular_posts_alias.medias))
            )

            result_subcategories = subcategories.fetchall()

            return self._from_result_subcategories_to_dict(result_subcategories)

    def _get_aliased_for_popular_post_subcategory(self) -> AliasedClass:
        """
        Алиас для получения первых трех самых залайканых постов в подкатегории
        """
        return aliased(
            self.post_model,
            select(self.post_model)
            .join(PostSubCategoryAssociateTable)
            .where(
                and_(
                    PostSubCategoryAssociateTable.c.subcategory_id
                    == self.subcategory_model.id,
                    self.post_model.is_draft.is_(False),
                )
            )
            .order_by(
                desc(self.post_model.get_count_liker_post_query()),
                desc(self.post_model.created_at),
            )
            .limit(3)
            .lateral(),
        )

    def _get_query_for_subcategory_order_by_count_posts(self) -> Select:
        """
        Подзапрос для количества постов не в драфте в каждой подкатегории,
        используемый для сортировки подкатегорий
        """
        return (
            select(func.count())
            .select_from(PostSubCategoryAssociateTable)
            .join(self.post_model)
            .where(
                and_(
                    self.post_model.is_draft.is_(False),
                    self.subcategory_model.id
                    == PostSubCategoryAssociateTable.c.subcategory_id,
                )
            )
            .scalar_subquery()
        )

    @staticmethod
    def _from_result_subcategories_to_dict(
        result: List[Tuple[SubCategory, Post]]
    ) -> Dict[SubCategory, List[Post]]:
        """
        Переводим результат вида subcategory:post
        в словарь типа Dict[SubCategory, List[Post]]
        """
        subcategories_dict: Dict[SubCategory, List[Post]] = {}

        for subcategory, post in result:
            if subcategory in subcategories_dict:
                subcategories_dict[subcategory].append(post)
            else:
                subcategories_dict[subcategory] = [post]

        return subcategories_dict
