"""Add documents fixtures

Revision ID: ae238d20107d
Revises: da00bc6c91e7
Create Date: 2022-08-10 08:53:44.948554

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ae238d20107d'
down_revision = 'da00bc6c91e7'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("DELETE FROM documents;")

    op.execute(
        """
            INSERT INTO documents (id, name, name_eng) VALUES
            (1, 'Документ 1', 'Document 1'),
            (2, 'Документ 2', 'Document 2'),
            (3, 'Документ 3', 'Document 3');
        """
    )


def downgrade():
    op.execute("DELETE FROM documents;")
