from common.enums.languages import AbstractLangEnum


class PostResponseEnum(AbstractLangEnum):
    POST_NOT_CREATED = "Post was no created", "Пост не был создан"
    POST_NOT_FOUND = "Post not found", "Пост не найден"

    POST_ALREADY_LIKED = "Post is already liked", "Пост уже лайкнут"
    POST_ALREADY_UNLIKED = "Post is already unliked", "Пост не был лайкнут ранее"
    POST_NOT_LIKED = "Failed to like post", "Не удалось лайкнуть пост"

    POST_ALREADY_FAVORITE = "Post is already in favorite", "Пост уже в сохраненных"
    POST_ALREADY_UNFAVORITE = (
        "Post is already unfavorite",
        "Пост не был в сохраненных ранее",
    )
    POST_NOT_FAVORITE = "Failed to favorite post", "Не удалось пост в избранные"

    INTERESTS_NOT_FOUND = "Not all nterests found", "Не все интересы найдены"
    INTERESTS_NO_DIFFERENT_CATEGORIES = (
        "Interests must be from different categories",
        "Интересы должны быть из разных категорий",
    )
    POST_FORBIDDEN = "Forbidden operation", "Недостаточно прав для операции"
