from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field
from schemas.common import MediaPostSchema, SubCategorySchema

from common.database.models import Post
from common.schemas.common import Page


class PostCreateSchema(BaseModel):
    description: Optional[str] = Field(None, max_length=1024)
    tags: Optional[str] = Field(None, max_length=20)
    media_count: int = Field(..., ge=1, le=10)
    subcategories_id: List[int] = Field(..., min_items=1, max_items=3)


class AuthorPostSchema(BaseModel):
    id: int
    nickname: str
    avatar: Optional[str] = None

    class Config:
        orm_mode = True


class PostSchema(BaseModel):
    id: int

    description: Optional[str] = None
    tags: Optional[str] = None

    author: AuthorPostSchema
    medias: List[MediaPostSchema] = []
    subcategories: List[SubCategorySchema] = []

    count_likers: int
    is_liker: bool
    is_favorite: bool

    updated_at: datetime
    created_at: datetime

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Post, locale: str = "en") -> "PostSchema":
        schema: PostSchema = super(cls, PostSchema).from_orm(obj)
        schema.subcategories = [
            SubCategorySchema.from_orm(i, locale) for i in obj.subcategories
        ]
        return schema


class PostsPage(Page):
    data: List[PostSchema] = []


class ReportCreateSchema(BaseModel):
    description: Optional[str] = Field(None, max_length=1024)
    post_id: int = Field(...)


class ReportSchema(BaseModel):
    id: int

    description: Optional[str] = None
    created_at: datetime

    user: AuthorPostSchema
    post: PostSchema

    solved: bool

    class Config:
        orm_mode = True


class ReportsPage(Page):
    data: List[ReportSchema] = []
