from typing import Dict, List, Optional, Type

from pydantic import BaseModel
from schemas.common import MediaPostSchema, SubCategorySchema

from common.database.models import Category, SubCategory
from common.schemas.users import ShortPersonProfile


class CategoryScheme(BaseModel):
    id: Optional[int]
    name: Optional[str]
    subcategories: List[SubCategorySchema] = []

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: Category, locale: str = "en") -> "CategoryScheme":
        return CategoryScheme(
            id=obj.id,
            name=obj.name_en if locale == "en" else obj.name_ru,
            subcategories=[
                SubCategorySchema.from_orm(i, locale) for i in obj.subcategories
            ],
        )


class PostShortSchema(BaseModel):
    id: int

    medias: List[MediaPostSchema] = []

    class Config:
        orm_mode = True


class ListPopularSubCategorySchema(SubCategorySchema):
    posts: List[PostShortSchema] = []

    class Config:
        orm_mode = True


class SearchResultsSchema(BaseModel):
    users: List[ShortPersonProfile]
    subcategories: List[ListPopularSubCategorySchema]
