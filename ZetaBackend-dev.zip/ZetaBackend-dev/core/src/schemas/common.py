from typing import Optional

from pydantic import BaseModel

from common.database.models import SubCategory


class SubCategorySchema(BaseModel):
    id: int
    category_id: int
    name: str
    icon: Optional[str]

    class Config:
        orm_mode = True

    @classmethod
    def from_orm(cls, obj: SubCategory, locale: str = "en") -> "SubCategorySchema":
        return SubCategorySchema(
            id=obj.id,
            name=obj.name_en if locale == "en" else obj.name_ru,
            category_id=obj.category_id,
            icon=obj.icon,
        )


class MediaPostSchema(BaseModel):
    id: int
    type: str
    link: str
    aspect_ratio: Optional[float] = None

    class Config:
        orm_mode = True
