from typing import Literal

OrderPostsType = Literal["top", "new"]
