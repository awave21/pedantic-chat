from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routing import categories, posts, search
from сonfig import app_settings

from common.translate.middlewares import LanguageMiddleware

app = FastAPI(
    debug=app_settings.DEBUG, openapi_url="/core/openapi.json", docs_url="/core/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LanguageMiddleware)

app.include_router(posts.router, prefix="/core")
app.include_router(categories.router, prefix="/core")
app.include_router(search.router, prefix="/core")
