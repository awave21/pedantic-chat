from repositories.posts import PostRepository
from repositories.search import SearchInterestRepository
from services.categories import CategoriesService
from services.network import NetworkService
from services.posts import PostService
from services.search import SearchInterestService
from сonfig import network_settings

from common.db import get_db
from common.repositories.categories import CategoriesRepository

post_repository = PostRepository(get_db)
categories_repository = CategoriesRepository(get_db)
search_interest_repository = SearchInterestRepository(get_db)
network_service = NetworkService(network_settings)

post_service = PostService(post_repository, categories_repository, network_service)
categories_service = CategoriesService(categories_repository)
search_interest_service = SearchInterestService(
    search_interest_repository, network_service
)


async def get_post_service() -> PostService:
    return post_service


async def get_categories_service() -> CategoriesService:
    return categories_service


async def get_search_interest_service() -> SearchInterestService:
    return search_interest_service
