from typing import List

from depends import get_categories_service
from fastapi import APIRouter, Depends
from schemas.categories import CategoryScheme
from services.categories import CategoriesService
from starlette.requests import Request
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get(
    "",
    responses={400: {"description": "Bad request"}},
    response_model=List[CategoryScheme],
    description="Получение листинга всех категорий с подкатегориями",
)
async def get_all_categories(
    request: Request,
    categories_service: CategoriesService = Depends(get_categories_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS)),
) -> List[CategoryScheme]:
    categories = await categories_service.list_categories()
    result = [
        CategoryScheme.from_orm(category, request.state.language)
        for category in categories.data
    ]
    return result
