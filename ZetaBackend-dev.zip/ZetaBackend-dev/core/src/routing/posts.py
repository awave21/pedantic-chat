from typing import Dict, List, Literal, Union

from depends import get_post_service
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.encoders import jsonable_encoder
from our_types import OrderPostsType
from schemas.posts import (
    PostCreateSchema,
    PostSchema,
    PostsPage,
    ReportCreateSchema,
    ReportSchema,
    ReportsPage,
)
from services.posts import PostService
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User

router = APIRouter(prefix="/post", tags=["post"])


@router.post(
    "",
    response_model=Dict,
    status_code=201,
    description="""
    Ендпоинт для создания постов.
    Создаёт пост без картинок\n
    Для добавленяи посту медиа необходимо использовать -
    https://zeta.purpleplane-it.com/uploader/post/add_post_media/
    """,
)
async def create_post(
    request: Request,
    post_data: PostCreateSchema,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.create_post(post_data, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse({"id": result.data.id}, status_code=201)


@router.get(
    "/report",
    response_model=ReportsPage,
    status_code=200,
    description="""
    Листинг жалоб на посты.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_reports(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler, is_admin=True)),
) -> JSONResponse:
    result = await post_service.list_reports(page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    reports = [ReportSchema.from_orm(report) for report in result.data[0]]

    return JSONResponse(
        jsonable_encoder(
            ReportsPage(page=page, limit=limit, data=reports, count=result.data[1])
        ),
        status_code=200,
    )


@router.delete(
    "/{post_id}",
    status_code=204,
    description="""
    Удаляет пост со всеми медиа на хранилку
    На данный момент ДОСТУПЕН ТОЛЬКО АДМИНУ
    """,
)
async def delete_post(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> Response:
    result = await post_service.delete_post_by_id(post_id, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return Response(status_code=204)


@router.get(
    "",
    response_model=PostsPage,
    status_code=200,
    description="""
    Листинг постов.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_posts(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.list_posts(user, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    posts = [PostSchema.from_orm(post, request.state.language) for post in result.data]

    return JSONResponse(
        jsonable_encoder(PostsPage(page=page, limit=limit, data=posts)), status_code=200
    )


@router.get(
    "/subcategory/{subcategory_id}",
    response_model=PostsPage,
    status_code=200,
    description="""
    Листинг постов по саб категории.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_subcategory_posts(
    request: Request,
    subcategory_id: int,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    order_by: OrderPostsType = Query("top"),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.list_subcategory_posts(
        user, page, limit, order_by, subcategory_id
    )

    posts = [
        PostSchema.from_orm(post, request.state.language) for post in result.data[0]
    ]

    return JSONResponse(
        jsonable_encoder(
            PostsPage(page=page, limit=limit, data=posts, count=result.data[1])
        ),
        status_code=200,
    )


@router.get(
    "/my",
    response_model=PostsPage,
    status_code=200,
    description="""
    Листинг постов пользователя.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_my_posts(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.list_my_posts(user, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    posts = [PostSchema.from_orm(post) for post in result.data]

    return JSONResponse(
        jsonable_encoder(PostsPage(page=page, limit=limit, data=posts)), status_code=200
    )


@router.get(
    "/favorite",
    response_model=PostsPage,
    status_code=200,
    description="""
    Листинг сохраненных постов.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_favorite_posts(
    request: Request,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.list_favorite_posts(user, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    posts = [PostSchema.from_orm(post, request.state.language) for post in result.data]

    return JSONResponse(
        jsonable_encoder(PostsPage(page=page, limit=limit, data=posts)), status_code=200
    )


@router.get(
    "/{post_id}",
    response_model=PostSchema,
    status_code=200,
    description="""
    Ендпоинт для получения поста по его id.
    """,
)
async def get_post_by_id(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.get_post_by_id(user, post_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    post = PostSchema.from_orm(result.data, request.state.language)

    return JSONResponse(jsonable_encoder(post), status_code=200)


@router.get(
    "/author/{author_id}",
    status_code=200,
    description="""
    Листинг постов по id автора.
    Работает только с пагинацией.\n
    Изначальные параметры пагинации ?page=0&limit=20
    """,
)
async def list_posts_by_author_id(
    request: Request,
    author_id: int,
    page: int = Query(0, ge=0),
    limit: int = Query(20, ge=5),
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.list_posts_by_author_id(user, author_id, page, limit)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    posts = [PostSchema.from_orm(post, request.state.language) for post in result.data]

    return JSONResponse(
        jsonable_encoder(PostsPage(page=page, limit=limit, data=posts)), status_code=200
    )


@router.get(
    "/{post_id}/like",
    response_model=PostSchema,
    status_code=202,
    description="""
    Лайк поста
    """,
)
async def like_post(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.like_post(user, post_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    post = PostSchema.from_orm(result.data, request.state.language)

    return JSONResponse(jsonable_encoder(post), status_code=202)


@router.get(
    "/{post_id}/unlike",
    response_model=PostSchema,
    status_code=202,
    description="""
    Удаление лайка с поста
    """,
)
async def unlike_post(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.unlike_post(user, post_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    post = PostSchema.from_orm(result.data, request.state.language)

    return JSONResponse(jsonable_encoder(post), status_code=202)


@router.get(
    "/{post_id}/favorite",
    response_model=PostSchema,
    status_code=202,
    description="""
    Добавление поста в избранное
    """,
)
async def favorite_post(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.favorite_post(user, post_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    post = PostSchema.from_orm(result.data, request.state.language)

    return JSONResponse(jsonable_encoder(post), status_code=202)


@router.get(
    "/{post_id}/unfavorite",
    response_model=PostSchema,
    status_code=202,
    description="""
    Удаление поста из избранного
    """,
)
async def unfavorite_post(
    request: Request,
    post_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.unfavorite_post(user, post_id)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    post = PostSchema.from_orm(result.data, request.state.language)

    return JSONResponse(jsonable_encoder(post), status_code=202)


@router.post(
    "/report",
    response_model=Dict,
    status_code=201,
    description="""
    Отправка жалобы на пост
    """,
)
async def create_report(
    request: Request,
    report_data: ReportCreateSchema,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    result = await post_service.create_report(report_data, user)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse({"id": result.data.id}, status_code=201)


@router.post(
    "/report/{report_id}",
    response_model=Dict,
    status_code=200,
    description="""
    Отклонение жалобы
    """,
)
async def solve_report(
    request: Request,
    report_id: int,
    post_service: PostService = Depends(get_post_service),
    user: User = Depends(get_jwt_bearer(auth_handler, is_admin=True)),
) -> JSONResponse:
    result = await post_service.solve_report(report_id)

    return JSONResponse({"id": result}, status_code=200)
