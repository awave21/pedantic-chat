from depends import get_search_interest_service
from fastapi import APIRouter, Depends, Query
from fastapi.encoders import jsonable_encoder
from schemas.categories import ListPopularSubCategorySchema, SearchResultsSchema
from services.search import SearchInterestService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User

router = APIRouter(prefix="/search", tags=["search"])


@router.get(
    "/popular",
    status_code=200,
    response_model=ListPopularSubCategorySchema,
    description="""
    Вывод списка популярных интересов отсортированных по кол-во постов в интересе
    """,
)
async def list_popular_subcategories(
    request: Request,
    search_interest_service: SearchInterestService = Depends(
        get_search_interest_service
    ),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    subcategories = await search_interest_service.list_popular_subcategories(
        request.state.language
    )

    return JSONResponse(jsonable_encoder(subcategories))


@router.get(
    "/search",
    status_code=200,
    response_model=SearchResultsSchema,
    description="""
    Вывод результатов поиска по интересам и по никам пользователей
    """,
)
async def search_subcategories(
    request: Request,
    startswith: str = Query(...),
    search_interest_service: SearchInterestService = Depends(
        get_search_interest_service
    ),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    subcategories = await search_interest_service.search_subcategories(
        startswith, request.headers.get("authorization"), request.state.language
    )
    return JSONResponse(jsonable_encoder(subcategories))
