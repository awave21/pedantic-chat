from common.enums.languages import AbstractLangEnum


class PostResponseEnum(AbstractLangEnum):
    POST_NOT_FOUND = "Post not found", "Пост не найден"
    ADD_MEDIA_FAILED = "Add media failed", "Неудалось добавить медиа посту"
    MEDIA_NOT_UPLOAD = (
        "Failed to upload the interest file",
        "Не удалось загрузить медиа файл поста",
    )
    MEDIA_TOO_MANY = (
        "Post medias has too many",
        "Пост уже имеет максимальное количество медиа файлов",
    )
