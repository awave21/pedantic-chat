from common.enums.languages import AbstractLangEnum


class UserResponseEnum(AbstractLangEnum):
    AVATAR_NOT_UPLOAD = (
        "Failed to upload the avatar file",
        "Не удалось загрузить аватар",
    )

    POST_NOT_FOUND = "Post not found", "Пост не найден"
    ADD_MEDIA_FAILED = "Add media failed", "Неудалось добавить медиа посту"

    MEDIA_TOO_MANY = (
        "Post medias has too many",
        "Пост уже имеет максимальное количество медиа файлов",
    )
