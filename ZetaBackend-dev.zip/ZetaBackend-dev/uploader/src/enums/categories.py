from common.enums.languages import AbstractLangEnum


class CategoriesResponseEnum(AbstractLangEnum):
    SUBCATEGORY_NOT_FOUND = "Interest not found", "Интерес не найден"
    SUBCATEGORY_NOT_UPLOAD = (
        "Failed to upload the interest file",
        "Не удалось загрузить файл интереса",
    )
