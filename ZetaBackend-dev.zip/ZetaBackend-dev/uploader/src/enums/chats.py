from common.enums.languages import AbstractLangEnum


class ChatResponseEnum(AbstractLangEnum):
    AVATAR_NOT_UPLOAD = (
        "Failed to upload the avatar file",
        "Не удалось загрузить аватар",
    )

    INVALID_AVATAR_DATA = (
        "Failed to save avatar model",
        "Не удалось сохранить данные аватара",
    )


class MediaResponseEnum(AbstractLangEnum):
    MEDIA_NOT_UPLOAD = (
        "Failed to upload the media file",
        "Не удалось загрузить медиафайл",
    )

    INVALID_MEDIA_DATA = (
        "Failed to save media",
        "Не удалось сохранить медиафайл",
    )
