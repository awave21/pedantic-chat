from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routing import categories, chats, posts, users
from tasks import remove_old_draft_posts
from сonfig import app_settings

from common.translate.middlewares import LanguageMiddleware

scheduler = AsyncIOScheduler()
scheduler.add_job(remove_old_draft_posts, "cron", hour=0)
scheduler.start()

app = FastAPI(
    debug=app_settings.DEBUG,
    openapi_url="/uploader/openapi.json",
    docs_url="/uploader/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LanguageMiddleware)

app.include_router(posts.router, prefix="/uploader")
app.include_router(categories.router, prefix="/uploader")
app.include_router(users.router, prefix="/uploader")
app.include_router(chats.router, prefix="/uploader")
