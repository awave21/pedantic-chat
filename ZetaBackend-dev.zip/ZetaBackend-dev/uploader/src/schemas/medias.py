from typing import List

from our_types import MediaType
from pydantic import BaseModel


class MediaSchema(BaseModel):
    link: str
    type: MediaType
    aspect_ratio: float


class MediasSchema(BaseModel):
    medias: List[MediaSchema]


class MediaLinksScheme(BaseModel):
    links: List[str]
