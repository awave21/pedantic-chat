from pydantic import BaseModel


class LinkResponse(BaseModel):
    link: str


class ChatAvatarResponse(BaseModel):
    avatar_id: int
