from typing import Literal

MediaType = Literal["video", "photo", "image"]
