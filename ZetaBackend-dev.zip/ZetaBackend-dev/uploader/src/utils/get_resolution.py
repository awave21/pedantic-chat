import ast
import asyncio
import io
from typing import Optional

from fastapi import UploadFile
from PIL import Image
from pydantic.annotated_types import Dict


async def get_media_aspect_ratio(file: UploadFile) -> Optional[float]:
    try:
        if file.content_type.split("/")[0] == "video":
            return await get_video_aspect_ratio(file)
        elif file.content_type.split("/")[0] == "image":
            return await get_image_aspect_ratio(file)
        else:
            return None
    except Exception:
        return None


async def get_image_aspect_ratio(file: UploadFile) -> float:
    bytes_ = await file.read()
    content_file = io.BytesIO(bytes_)

    image = Image.open(content_file)

    return round(image.height / image.width, 5)


async def get_video_aspect_ratio(file: UploadFile) -> float:
    await file.seek(0)

    bytes_ = await file.read(16384 * 80)

    metadata = await _get_video_metadata_from_bytes(bytes_)

    # Если ffprobe не хватило перой части файла, считываем весь файл
    if not metadata:
        new_bytes = await file.read(16384 * 80)
        while new_bytes:
            bytes_ += new_bytes
            new_bytes = await file.read(16384 * 80)
        metadata = await _get_video_metadata_from_bytes(bytes_)

    del bytes_

    metadata_stream = metadata.get("streams")[0]

    return round(metadata_stream.get("width") / metadata_stream.get("height"), 5)


async def _get_video_metadata_from_bytes(input_bytes: bytes) -> Dict:
    command = "ffprobe -v error -show_streams -print_format json -"

    proc = await asyncio.create_subprocess_shell(
        cmd=command,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
    )

    proc.stdin.write(input_bytes)  # type: ignore
    proc.stdin.close()  # type: ignore

    b = b""

    while True:
        output = await proc.stdout.read()  # type: ignore
        if len(output) > 0:
            b += output
        else:
            break
    return ast.literal_eval(b.decode("utf-8"))
