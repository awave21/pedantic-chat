from depends import post_upload_repository, upload_service


async def remove_old_draft_posts() -> None:
    # получаем старые черновики
    old_drafts = await post_upload_repository.get_drafts_for_delete()
    print(f"Found {len(old_drafts)} old drafts")
    if not old_drafts:
        return
    # собираем список ссылок которые будем удалять с хранилок
    bucket_links = []
    for old_draft in old_drafts:
        for media in old_draft.medias:
            bucket_links.append(media.link)
    # удаляем черновки
    await post_upload_repository.delete_posts_by_ids(
        [old_draft.id for old_draft in old_drafts]
    )
    # удаляем ссылки с хранилки

    try:
        await upload_service.delete_files(bucket_links)
    except Exception as e:
        print(f"We got error while delete link {e}")
