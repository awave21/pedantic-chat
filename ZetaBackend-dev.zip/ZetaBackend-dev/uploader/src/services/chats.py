import io

from enums.chats import ChatResponseEnum, MediaResponseEnum
from fastapi import UploadFile
from repositories.chat_avatar import ChatAvatarRepository
from repositories.chats import ChatUploadRepository
from response_tuples import ResponseUploadTuple

from common.database.models import Chat

from .uploader import UploaderService


class ChatUploadService:
    def __init__(
        self,
        chats_upload_repository: ChatUploadRepository,
        uploader_service: UploaderService,
        chat_avatar_repository: ChatAvatarRepository,
    ) -> None:
        self.chats_upload_repository = chats_upload_repository
        self.uploader_service = uploader_service
        self.chat_avatar_repository = chat_avatar_repository

    async def set_avatar_for_chat(self, chat: Chat, avatar: str) -> ResponseUploadTuple:
        return await self.chats_upload_repository.set_avatar_for_chat(chat, avatar)

    async def upload_file(self, file: UploadFile) -> ResponseUploadTuple:
        try:
            bytes = await file.read()
            content_file = io.BytesIO(bytes)
            new_avatar_link = await self.uploader_service.upload_chat_avatar(
                file.filename.split(".")[-1], content_file
            )
        except IOError:
            return ResponseUploadTuple(
                error_code=500, description=ChatResponseEnum.AVATAR_NOT_UPLOAD
            )
        return ResponseUploadTuple(data=new_avatar_link)

    async def create_avatar(self, file: UploadFile) -> ResponseUploadTuple:
        # todo добавить в таблицу чат аватара пользователя
        result = await self.upload_file(file)
        if result.error_code:
            return result
        result = await self.chat_avatar_repository.create_chat_avatar(result.data)
        return ResponseUploadTuple(data=result.data)

    async def update_avatar(self, chat: Chat, file: UploadFile) -> ResponseUploadTuple:
        # TODO: сделать проверку, что изменяющий аватарку юзер является админом!
        # TODO: удалить обьект аватарки
        old_avatar_link = chat.avatar

        # Загрузка новой аватарки
        result = await self.upload_file(file)
        if result.error_code:
            return result

        result = await self.chat_avatar_repository.create_chat_avatar(result.data)

        await self.chats_upload_repository.set_avatar_for_chat(chat, result.data.id)

        # Удаление старой аватарки
        try:
            await self.uploader_service.delete_file(old_avatar_link)
        except:
            # todo: log here
            print("Failed to delete old avatar link")

        return ResponseUploadTuple(data=chat.avatar)

    async def get_chat_by_id(self, chat_id: int) -> Chat:
        return await self.chats_upload_repository.get_chat_by_id(chat_id)

    async def upload_media(self, file: UploadFile) -> ResponseUploadTuple:
        try:
            bytes = await file.read()
            content_file = io.BytesIO(bytes)
            media_link = await self.uploader_service.upload_messages_media(
                file.filename, content_file
            )
        except IOError:
            return ResponseUploadTuple(
                error_code=500, description=MediaResponseEnum.MEDIA_NOT_UPLOAD
            )
        return ResponseUploadTuple(data=media_link)

    async def create_media(
        self, file: UploadFile, file_type: str
    ) -> ResponseUploadTuple:
        result = await self.upload_media(file)
        if result.error_code:
            return result
        result = await self.chats_upload_repository.create_media(result.data, file_type)
        return ResponseUploadTuple(data=result.data)
