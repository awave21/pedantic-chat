import io

from enums.users import UserResponseEnum
from fastapi import UploadFile
from repositories.users import UserUploadRepository
from response_tuples import ResponseUploadTuple
from services.uploader import UploaderService

from common.database.models import User


class UserUploadService:
    def __init__(
        self,
        user_upload_repository: UserUploadRepository,
        uploader_service: UploaderService,
    ) -> None:
        self.user_upload_repository = user_upload_repository
        self.uploader_service = uploader_service

    async def set_avatar_for_user(self, user: User, avatar: str) -> ResponseUploadTuple:
        return await self.user_upload_repository.set_avatar_for_user(user, avatar)

    async def update_avatar(self, user: User, file: UploadFile) -> ResponseUploadTuple:
        old_avatar_link = user.avatar

        # Загрузка новой аватарки
        try:
            bytes = await file.read()
            content_file = io.BytesIO(bytes)
            new_avatar_link = await self.uploader_service.upload_user_avatar(
                file.filename.split(".")[-1], content_file
            )
        except IOError:
            return ResponseUploadTuple(
                error_code=500, description=UserResponseEnum.AVATAR_NOT_UPLOAD
            )

        await self.user_upload_repository.set_avatar_for_user(user, new_avatar_link)

        # Удаление старой аватарки
        try:
            await self.uploader_service.delete_file(old_avatar_link)
        except:
            # todo: log here
            print("Failed to delete old avatar link")

        return ResponseUploadTuple(data=user.avatar)
