import datetime
import random
import string
from abc import ABC, abstractmethod
from io import BytesIO
from typing import List

import aioboto3
from сonfig import UploaderSettings


class UploaderService(ABC):
    def __init__(self, config: UploaderSettings) -> None:
        self.session = aioboto3.Session(
            aws_access_key_id=config.STORAGE_ACCESS_KEY_ID,
            aws_secret_access_key=config.STORAGE_SECRET_ACCESS_KEY,
            region_name=config.STORAGE_REGION_NAME,
        )
        self.bucket_name = config.STORAGE_BUCKET_NAME
        self.endpoint_url = config.STORAGE_ENDPOINT_URL

    @abstractmethod
    async def upload_media(self, file_extension: str, file_obj: BytesIO) -> str:
        pass

    @abstractmethod
    async def upload_user_avatar(self, file_extension: str, file_obj: BytesIO) -> str:
        pass

    @abstractmethod
    async def upload_chat_avatar(self, file_extension: str, file_obj: BytesIO) -> str:
        pass

    @abstractmethod
    async def upload_messages_media(
        self, file_extension: str, file_obj: BytesIO
    ) -> str:
        pass

    @abstractmethod
    async def upload_subcategory_icon(
        self, file_extension: str, file_obj: BytesIO
    ) -> str:
        pass

    @abstractmethod
    async def delete_file(self, path: str) -> None:
        pass

    @abstractmethod
    async def delete_files(self, paths: List[str]) -> None:
        pass


class YandexUploaderService(UploaderService):
    async def upload_media(self, file_extension: str, file_obj: BytesIO) -> str:
        return await self._upload_file(
            folder=f"medias/{str(datetime.date.today())}",
            filename=f"{self._slug_generator()}.{file_extension}",
            file_obj=file_obj,
        )

    async def upload_user_avatar(self, file_extension: str, file_obj: BytesIO) -> str:
        return await self._upload_file(
            folder=f"avatars/{str(datetime.date.today())}",
            filename=f"{self._slug_generator()}.{file_extension}",
            file_obj=file_obj,
        )

    async def upload_chat_avatar(self, file_extension: str, file_obj: BytesIO) -> str:
        return await self._upload_file(
            folder=f"chat_avatars/{str(datetime.date.today())}",
            filename=f"{self._slug_generator()}.{file_extension}",
            file_obj=file_obj,
        )

    async def upload_messages_media(self, file_name: str, file_obj: BytesIO) -> str:
        file_extension = file_name.split(".")[-1]
        if file_extension != "pdf":
            file_name = f"{self._slug_generator()}.{file_extension}"
        else:
            file_name = "_".join(file_name.split())
        return await self._upload_file(
            folder=f"messages/{str(datetime.date.today())}",
            filename=file_name,
            file_obj=file_obj,
        )

    async def upload_subcategory_icon(
        self, file_extension: str, file_obj: BytesIO
    ) -> str:
        return await self._upload_file(
            folder="subcategories",
            filename=f"{self._slug_generator(10)}.{file_extension}",
            file_obj=file_obj,
        )

    async def _upload_file(self, folder: str, filename: str, file_obj: BytesIO) -> str:
        async with self.session.client("s3", endpoint_url=self.endpoint_url) as s3:
            path = folder + "/" + filename
            await s3.upload_fileobj(file_obj, self.bucket_name, path)

            return f"{self.endpoint_url}/{self.bucket_name}/{path}"

    async def delete_file(self, path: str) -> None:
        async with self.session.client("s3", endpoint_url=self.endpoint_url) as s3:
            await s3.delete_object(
                Bucket=self.bucket_name, Key=path.split(f"/{self.bucket_name}/")[-1]
            )

    async def delete_files(self, paths: List[str]) -> None:
        async with self.session.client("s3", endpoint_url=self.endpoint_url) as s3:
            await s3.delete_objects(
                Bucket=self.bucket_name,
                Delete={
                    "Objects": [
                        {"Key": path.split(f"/{self.bucket_name}/")[-1]}
                        for path in paths
                    ]
                },
            )

    @staticmethod
    def _slug_generator(length: int = 40) -> str:
        return "".join(
            random.choice(string.ascii_letters + string.digits) for _ in range(length)
        )
