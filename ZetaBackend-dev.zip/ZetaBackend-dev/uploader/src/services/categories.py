import io
from typing import Optional

from enums.categories import CategoriesResponseEnum
from fastapi import UploadFile
from repositories.categories import CategoryUploadRepository
from response_tuples import ResponseUploadTuple
from services.uploader import UploaderService


class CategoryUploadService:
    def __init__(
        self,
        category_upload_repository: CategoryUploadRepository,
        uploader_service: UploaderService,
    ) -> None:
        self.category_upload_repository = category_upload_repository
        self.uploader_service = uploader_service

    async def set_avatar_for_subcategory(
        self, subcategory_id: int, link: str
    ) -> ResponseUploadTuple:
        return await self.category_upload_repository.set_avatar_for_subcategory(
            subcategory_id, link
        )

    async def create_or_update_subcategory_icon(
        self, file: UploadFile, old_icon_link: Optional[str] = None
    ) -> ResponseUploadTuple:
        # Загрузка новой иконки
        try:
            bytes = await file.read()
            content_file = io.BytesIO(bytes)
            new_icon_link = await self.uploader_service.upload_subcategory_icon(
                file.filename.split(".")[-1], content_file
            )
        except IOError:
            return ResponseUploadTuple(
                error_code=500,
                description=CategoriesResponseEnum.SUBCATEGORY_NOT_UPLOAD,
            )

        # Удаление старой иконки
        try:
            if old_icon_link:
                await self.uploader_service.delete_file(old_icon_link)
        except:
            # todo: log here
            print("Failed to delete old icon link")

        return ResponseUploadTuple(data=new_icon_link)
