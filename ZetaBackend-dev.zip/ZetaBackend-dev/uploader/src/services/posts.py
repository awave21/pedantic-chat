import io

from enums.posts import PostResponseEnum
from fastapi import UploadFile
from repositories.posts import PostUploadRepository
from response_tuples import ResponseUploadTuple
from schemas.medias import MediaSchema, MediasSchema
from services.uploader import UploaderService
from utils.get_resolution import get_media_aspect_ratio

from common.database.models import User


class PostUploadService:
    def __init__(
        self,
        post_upload_repository: PostUploadRepository,
        uploader_service: UploaderService,
    ) -> None:
        self.post_upload_repository = post_upload_repository
        self.uploader_service = uploader_service

    # async def set_medias_for_post(
    #     self, post_id: int, user_id: int, medias_data: MediasSchema
    # ) -> ResponseUploadTuple:
    #     post = await self.post_upload_repository.get_post_with_author_check(
    #         post_id, user_id
    #     )
    #
    #     if not post:
    #         return ResponseUploadTuple(
    #             error_code=404, description=PostResponseEnum.POST_NOT_FOUND
    #         )
    #
    #     return await self.post_upload_repository.set_medias_for_post(post, medias_data)

    async def upload_media_for_post(
        self, post_id: int, user: User, file: UploadFile
    ) -> ResponseUploadTuple:
        post = await self.post_upload_repository.get_post_with_author_check(
            post_id, user.id
        )

        if not post:
            return ResponseUploadTuple(
                error_code=404, description=PostResponseEnum.POST_NOT_FOUND
            )

        if post.media_count <= len(post.medias):
            return ResponseUploadTuple(
                error_code=400, description=PostResponseEnum.MEDIA_TOO_MANY
            )

        aspect_ratio = await get_media_aspect_ratio(file)

        if not aspect_ratio:
            return ResponseUploadTuple(
                error_code=500, description=PostResponseEnum.ADD_MEDIA_FAILED
            )

        # Загрузка медиа
        try:
            await file.seek(0)
            bytes = await file.read()
            content_file = io.BytesIO(bytes)
            media_link = await self.uploader_service.upload_media(
                file.filename.split(".")[-1], content_file
            )
        except IOError:
            return ResponseUploadTuple(
                error_code=500, description=PostResponseEnum.MEDIA_NOT_UPLOAD
            )

        media_data = MediaSchema(
            link=media_link,
            type=file.content_type.split("/")[0],
            aspect_ratio=aspect_ratio,
        )

        return await self.post_upload_repository.set_media_for_post(
            post, user, media_data
        )
