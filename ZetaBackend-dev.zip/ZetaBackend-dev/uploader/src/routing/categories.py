from typing import Optional

from depends import get_category_upload_service
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from schemas.responses import LinkResponse
from services.categories import CategoryUploadService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.enums.uploader import UploaderResponseEnum
from common.utils.checks import check_type_files_in_image_or_video

router = APIRouter(prefix="/categories", tags=["categories"])


# @router.post(
#     "/set-subcategory-avatar/{subcategory_id}",
#     status_code=202,
#     description="""
#     Устанавливает картинку для подкатегории.\n
#     Для использования необходимы права АДМИНА\n
#     ПОКА ЧТО СОХРАНЯЕТ КАРТИНКУ КАК ПЕРЕДАННУЮ НА НЕЁ ССЫЛКУ(link)
#     """,
# )
# async def set_avatar_for_subcategory(
#     subcategory_id: int,
#     link: str = Query(...),
#     category_service: CategoryUploadService = Depends(get_category_upload_service),
#     user: User = Depends(get_jwt_bearer(auth_handler, is_admin=True)),
# ) -> JSONResponse:
#     result = await category_service.set_avatar_for_subcategory(subcategory_id, link)
#
#     if result.error_code:
#         raise HTTPException(status_code=result.error_code, detail=result.description)
#
#     return JSONResponse(status_code=202)


@router.post(
    "/upload-subcategory-icon",
    status_code=202,
    description="""
    Загружает картинку для подкатегории. Так же удаляет старую картинку,
    если она указана как old_icon_link
    """,
    responses={202: {"model": LinkResponse}},
)
async def upload_subcategory_icon(
    request: Request,
    old_icon_link: Optional[str] = Form(None),
    file: UploadFile = File(...),
    category_service: CategoryUploadService = Depends(get_category_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler, is_admin=True)),
) -> JSONResponse:
    if not check_type_files_in_image_or_video(file, is_video=False):
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.NO_IMAGE.translate(request.state.language),
        )

    result = await category_service.create_or_update_subcategory_icon(
        file, old_icon_link
    )

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(status_code=202, content={"link": result.data})
