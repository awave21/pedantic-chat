from depends import get_chats_upload_service
from fastapi import APIRouter, Body, Depends, File, HTTPException, Query, UploadFile
from fastapi.encoders import jsonable_encoder
from schemas.responses import ChatAvatarResponse, LinkResponse
from services.chats import ChatUploadService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.enums.uploader import UploaderResponseEnum
from common.schemas.chats import ChatAvatar, Media
from common.utils.checks import check_type_files_in_image_or_video, check_type_media

router = APIRouter(prefix="/chats", tags=["chats"])


@router.post(
    "/update-avatar/{chat_id}",
    status_code=202,
    description="""
    Загружает новый аватар чата, удаляя старый
    """,
    responses={202: {"model": LinkResponse}},
)
async def update_avatar(
    request: Request,
    chat_id: int,
    file: UploadFile = File(...),
    chats_service: ChatUploadService = Depends(get_chats_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    if not check_type_files_in_image_or_video(file, is_video=False):
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.NO_IMAGE.translate(request.state.language),
        )
    chat = await chats_service.get_chat_by_id(chat_id)
    result = await chats_service.update_avatar(chat, file)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(status_code=202, content={"link": result.link})


@router.post(
    "/create-avatar",
    status_code=201,
    description="""
    Создает аватар чата
    """,
    response_model=ChatAvatar,
)
async def create_avatar(
    request: Request,
    file: UploadFile = File(...),
    chats_service: ChatUploadService = Depends(get_chats_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    if not check_type_files_in_image_or_video(file, is_video=False):
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.NO_IMAGE.translate(request.state.language),
        )

    result = await chats_service.create_avatar(file)
    data = ChatAvatar.from_orm(result.data)
    return JSONResponse(status_code=201, content=jsonable_encoder(data))


@router.post(
    "/upload_messages_media",
    status_code=201,
    description="""
    Загружает и сохраняет медиа для сообщений
    """,
    response_model=Media,
)
async def create_media(
    request: Request,
    file: UploadFile = File(...),
    chats_service: ChatUploadService = Depends(get_chats_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    file_type = check_type_media(file)
    if not file_type:
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.UNSUPPORTED_MEDIA_FILE.translate(
                request.state.language
            ),
        )

    result = await chats_service.create_media(file, file_type)
    data = Media.from_orm(result.data)
    return JSONResponse(status_code=201, content=jsonable_encoder(data))
