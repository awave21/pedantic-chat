from depends import get_user_upload_service
from fastapi import APIRouter, Body, Depends, File, HTTPException, Query, UploadFile
from schemas.responses import LinkResponse
from services.users import UserUploadService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.enums.uploader import UploaderResponseEnum
from common.utils.checks import check_type_files_in_image_or_video

router = APIRouter(prefix="/user", tags=["user"])


# @router.post(
#     "/set-user-avatar/",
#     status_code=202,
#     description="""
#     Устанавливает аватарку пользователя\n
#     Берёт пользователя для изменения аватарки по используемому токену авторизации\n
#     ПОКА ЧТО СОХРАНЯЕТ КАРТИНКУ КАК ПЕРЕДАННУЮ НА НЕЁ ССЫЛКУ(link)
#     """,
# )
# async def set_avatar_for_user(
#     link: str = Query(...),
#     user_service: UserUploadService = Depends(get_user_upload_service),
#     user: User = Depends(get_jwt_bearer(auth_handler)),
# ) -> JSONResponse:
#     result = await user_service.set_avatar_for_user(user, link)
#
#     if result.error_code:
#         raise HTTPException(status_code=result.error_code, detail=result.description)
#
#     return JSONResponse(status_code=202)


@router.post(
    "/update-avatar",
    status_code=202,
    description="""
    Загружает новый аватар пользователя, удаляя старый
    """,
    responses={202: {"model": LinkResponse}},
)
async def update_avatar(
    request: Request,
    file: UploadFile = File(...),
    user_service: UserUploadService = Depends(get_user_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    if not check_type_files_in_image_or_video(file, is_video=False):
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.NO_IMAGE.translate(request.state.language),
        )

    result = await user_service.update_avatar(user, file)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(status_code=202, content={"link": result.data})
