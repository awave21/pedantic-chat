from depends import get_post_upload_service, get_upload_service
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from schemas.medias import MediaLinksScheme
from services.posts import PostUploadService
from services.uploader import UploaderService
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from сonfig import app_settings, auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.database.models import User
from common.enums.uploader import UploaderResponseEnum
from common.utils.checks import check_type_files_in_image_or_video

router = APIRouter(prefix="/post", tags=["post"])


# @router.post(
#     "/add_post_media/{post_id}",
#     status_code=202,
#     description="""
#     Добавляет картинки посту.
#     Можно прикрепить много картинок за раз\n
#     Медиа на посты может прикреплять тольkо автор поста.\n
#     ПОКА ЧТО СОХРАНЯЕТ КАРТИНКУ КАК ПЕРЕДАННУЮ НА НЕЁ ССЫЛКУ(link)
#     """,
# )
# async def add_post_media(
#     post_id: int,
#     medias: MediasSchema,
#     post_service: PostUploadService = Depends(get_post_upload_service),
#     user: User = Depends(get_jwt_bearer(auth_handler)),
# ) -> JSONResponse:
#     result = await post_service.set_medias_for_post(post_id, user.id, medias)
#
#     if result.error_code:
#         raise HTTPException(status_code=result.error_code, detail=result.description)
#
#     return JSONResponse(status_code=202)


@router.post(
    "/upload_post_media/{post_id}",
    status_code=202,
    description=""""
    Загружает медиа для поста
    """,
)
async def upload_post_media(
    request: Request,
    post_id: int,
    file: UploadFile = File(...),
    post_service: PostUploadService = Depends(get_post_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler)),
) -> JSONResponse:
    if not check_type_files_in_image_or_video(file):
        raise HTTPException(
            status_code=400,
            detail=UploaderResponseEnum.NO_IMAGE_OR_VIDEO.translate(
                request.state.language
            ),
        )

    result = await post_service.upload_media_for_post(post_id, user, file)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(
        {"draft_mode": True if app_settings.DRAFT_MODE == 1 else False}, status_code=202
    )


@router.post(
    "/delete_medias",
    status_code=204,
    description=""""
    Удаляет медиа по линку с хранилки
    """,
)
async def delete_medias(
    links_scheme: MediaLinksScheme,
    uploader_service: UploaderService = Depends(get_upload_service),
    user: User = Depends(get_jwt_bearer(auth_handler, is_admin=True)),
) -> Response:
    try:
        await uploader_service.delete_files(links_scheme.links)
    except Exception as e:
        print(f"We got error while delete link {e}")
        raise HTTPException(status_code=500)

    return Response(status_code=204)
