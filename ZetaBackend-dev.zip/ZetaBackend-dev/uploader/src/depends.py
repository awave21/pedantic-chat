from repositories.categories import CategoryUploadRepository
from repositories.chat_avatar import ChatAvatarRepository
from repositories.chats import ChatUploadRepository
from repositories.posts import PostUploadRepository
from repositories.users import UserUploadRepository
from services.categories import CategoryUploadService
from services.chats import ChatUploadService
from services.posts import PostUploadService
from services.uploader import UploaderService, YandexUploaderService
from services.users import UserUploadService
from сonfig import uploader_settings

from common.db import get_db

category_upload_repository = CategoryUploadRepository(get_db)
user_upload_repository = UserUploadRepository(get_db)
post_upload_repository = PostUploadRepository(get_db)
chats_upload_repository = ChatUploadRepository(get_db)
chat_avatar_repository = ChatAvatarRepository(get_db)

upload_service = YandexUploaderService(uploader_settings)

category_upload_service = CategoryUploadService(
    category_upload_repository, upload_service
)
user_upload_service = UserUploadService(user_upload_repository, upload_service)
chats_upload_service = ChatUploadService(
    chats_upload_repository, upload_service, chat_avatar_repository
)
post_upload_service = PostUploadService(post_upload_repository, upload_service)


async def get_category_upload_service() -> CategoryUploadService:
    return category_upload_service


async def get_user_upload_service() -> UserUploadService:
    return user_upload_service


async def get_chats_upload_service() -> ChatUploadService:
    return chats_upload_service


async def get_post_upload_service() -> PostUploadService:
    return post_upload_service


async def get_upload_service() -> UploaderService:
    return upload_service
