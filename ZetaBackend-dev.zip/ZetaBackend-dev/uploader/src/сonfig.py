from typing import Optional

from pydantic import BaseSettings

from common.auth.jwt_handler import AuthHandler
from common.configs import JWTSettings


class AppSettings(BaseSettings):
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    DB_CONTAINER_NAME: str
    PORT_DB: str
    POSTGRES_DB: str
    DEBUG: int = 0
    LIFETIME_OLD_DRAFTS_DAYS: Optional[int] = 1
    DRAFT_MODE: int = 0


class UploaderSettings(BaseSettings):
    STORAGE_ACCESS_KEY_ID: str
    STORAGE_SECRET_ACCESS_KEY: str
    STORAGE_REGION_NAME: str
    STORAGE_ENDPOINT_URL: str
    STORAGE_BUCKET_NAME: str


app_settings = AppSettings()
jwt_settings = JWTSettings()
uploader_settings = UploaderSettings()

auth_handler = AuthHandler(jwt_settings)
