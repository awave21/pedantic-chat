from typing import Callable

from enums.chats import MediaResponseEnum
from response_tuples import ResponseMediaTuple, ResponseUploadTuple
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

from common.database.models import Attachment, Chat


class ChatUploadRepository:
    base_model = Chat
    attachment_model = Attachment

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_chat_by_id(self, chat_id: int) -> Chat:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.id == chat_id)
            )

            chat = result.scalars().first()

            return chat

    async def set_avatar_for_chat(
        self, chat: Chat, avatar_id: int
    ) -> ResponseUploadTuple:
        async with self.get_db() as session:
            chat.avatar_id = avatar_id
            session.add(chat)
            await session.commit()

        return ResponseUploadTuple()

    async def create_media(self, link: str, file_type: str) -> ResponseMediaTuple:
        async with self.get_db() as session:
            media = self.attachment_model(url=link, type=file_type)
            try:
                session.add(media)
                await session.flush()
                await session.commit()
            except:
                return ResponseMediaTuple(
                    error_code=500, description=MediaResponseEnum.INVALID_MEDIA_DATA
                )
            return ResponseMediaTuple(data=media)
