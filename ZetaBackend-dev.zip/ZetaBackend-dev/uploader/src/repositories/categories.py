from typing import Callable

from enums.categories import CategoriesResponseEnum
from response_tuples import ResponseUploadTuple
from sqlalchemy import update
from sqlalchemy.orm import sessionmaker

from common.database.models import Category, SubCategory


class CategoryUploadRepository:
    base_model = Category
    subcategory_model = SubCategory

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def set_avatar_for_subcategory(
        self, subcategory_id: int, link: str
    ) -> ResponseUploadTuple:
        async with self.get_db() as session:
            result = await session.execute(
                update(self.subcategory_model)
                .where(self.subcategory_model.id == subcategory_id)
                .values(link=link)
                .returning(self.subcategory_model.__table__.c)
            )

            subcategory = result.first()

            if not subcategory:
                return ResponseUploadTuple(
                    error_code=404,
                    description=CategoriesResponseEnum.SUBCATEGORY_NOT_FOUND,
                )

            await session.commit()

        return ResponseUploadTuple()
