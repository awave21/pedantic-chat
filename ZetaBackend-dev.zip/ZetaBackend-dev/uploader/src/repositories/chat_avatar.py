from typing import Callable

from enums.chats import ChatResponseEnum
from response_tuples import ResponseChatAvatarTuple
from sqlalchemy.orm import sessionmaker

from common.database.models import ChatAvatar


class ChatAvatarRepository:
    base_model = ChatAvatar

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def create_chat_avatar(self, link: str) -> ResponseChatAvatarTuple:
        async with self.get_db() as session:
            avatar = self.base_model(link=link)
            try:
                session.add(avatar)
                await session.flush()
                await session.commit()
            except:
                return ResponseChatAvatarTuple(
                    error_code=500, description=ChatResponseEnum.INVALID_AVATAR_DATA
                )
            return ResponseChatAvatarTuple(data=avatar)
