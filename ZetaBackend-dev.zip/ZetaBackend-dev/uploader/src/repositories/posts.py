from datetime import datetime, timedelta
from typing import Callable, List, Optional

from enums.posts import PostResponseEnum
from response_tuples import ResponseUploadTuple
from schemas.medias import MediaSchema, MediasSchema
from sqlalchemy import and_, delete, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError, InvalidRequestError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload, sessionmaker
from сonfig import app_settings

from common.database.models import (
    Media,
    Post,
    PostSubCategoryAssociateTable,
    User,
    UserSubCategoryAssociateTable,
)


class PostUploadRepository:
    base_model = Post
    media_model = Media
    user_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def delete_posts_by_ids(self, ids: list) -> None:
        async with self.get_db() as session:
            await session.execute(
                delete(self.media_model).where(self.media_model.post_id.in_(ids))
            )
            await session.execute(
                delete(self.base_model).where(self.base_model.id.in_(ids))
            )
            await session.commit()

    async def get_drafts_for_delete(self) -> List[Post]:
        now = datetime.now()
        # пока что за последние сути
        old_drafts_date = now - timedelta(days=app_settings.LIFETIME_OLD_DRAFTS_DAYS)
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .where(
                    and_(
                        self.base_model.is_draft.is_(True),
                        self.base_model.created_at <= old_drafts_date,
                    )
                )
                .options(selectinload(self.base_model.medias))
            )
            return result.scalars().all()

    async def get_post_with_author_check(
        self, post_id: int, user_id: int
    ) -> Optional[Post]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model)
                .where(
                    and_(
                        self.base_model.id == post_id,
                        self.base_model.author_id == user_id,
                    )
                )
                .options(selectinload(self.base_model.medias))
            )

            return result.scalars().first()

    async def set_media_for_post(
        self, post: Post, user: User, media_data: MediaSchema
    ) -> ResponseUploadTuple:
        async with self.get_db() as session:
            try:
                media = self.media_model(**media_data.dict())

                post.medias.extend([media])

                # Если кол-во медиа поста равно кол-во загруженным медиа
                # вывод пост из драфта и уведичиваем счётчик постов автора поста
                if post.media_count <= len(post.medias):
                    if app_settings.DRAFT_MODE == 0:
                        await self._undraft_post(post, user, session)

                session.add(media)
                await session.commit()
            except (IntegrityError, InvalidRequestError):
                return ResponseUploadTuple(
                    error_code=500, description=PostResponseEnum.ADD_MEDIA_FAILED
                )

        return ResponseUploadTuple()

    async def set_medias_for_post(
        self, post: Post, medias_data: MediasSchema
    ) -> ResponseUploadTuple:
        async with self.get_db() as session:
            try:
                medias = [
                    self.media_model(**media.dict()) for media in medias_data.medias
                ]

                post.medias.extend(medias)

                session.add_all(medias)
                await session.commit()
            except (IntegrityError, InvalidRequestError):
                return ResponseUploadTuple(
                    error_code=500, description=PostResponseEnum.ADD_MEDIA_FAILED
                )

        return ResponseUploadTuple()

    @staticmethod
    async def _undraft_post(post: Post, user: User, session: AsyncSession) -> None:
        post.is_draft = False
        user.count_posts += 1
        session.add_all([post, user])

        result = await session.execute(
            select(PostSubCategoryAssociateTable.c.subcategory_id).where(
                PostSubCategoryAssociateTable.c.post_id == post.id
            )
        )

        subcategory_ids = result.scalars().all()

        await session.execute(
            pg_insert(UserSubCategoryAssociateTable)
            .values(
                [
                    {
                        UserSubCategoryAssociateTable.c.user_id: user.id,
                        UserSubCategoryAssociateTable.c.subcategory_id: subcategory_id,
                    }
                    for subcategory_id in subcategory_ids
                ]
            )
            .on_conflict_do_nothing()
        )

        return
