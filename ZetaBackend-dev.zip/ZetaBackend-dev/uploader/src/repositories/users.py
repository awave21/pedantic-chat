from typing import Callable

from response_tuples import ResponseUploadTuple
from sqlalchemy.orm import sessionmaker

from common.database.models import User


class UserUploadRepository:
    base_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def set_avatar_for_user(self, user: User, link: str) -> ResponseUploadTuple:
        async with self.get_db() as session:
            user.avatar = link

            session.add(user)
            await session.commit()

        return ResponseUploadTuple()
