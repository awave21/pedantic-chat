from typing import NamedTuple, Optional, Union

from common.database.models import Attachment, ChatAvatar
from common.enums.languages import AbstractLangEnum


class ResponseUploadTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[Union[str, int]] = None


class ResponseMediaTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[Attachment] = None


class ResponseChatAvatarTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[ChatAvatar] = None
