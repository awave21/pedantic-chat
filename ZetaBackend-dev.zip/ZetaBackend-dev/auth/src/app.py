from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from routing import auth, recovery, registration
from tasks import remove_old_user_drafts
from сonfig import app_settings

from common.translate.handlers import validation_exception_translate_handler
from common.translate.middlewares import LanguageMiddleware

scheduler = AsyncIOScheduler()
scheduler.add_job(remove_old_user_drafts, 'interval', minutes=5)
scheduler.start()


app = FastAPI(
    debug=app_settings.DEBUG, openapi_url="/auth/openapi.json", docs_url="/auth/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LanguageMiddleware)

app.add_exception_handler(
    RequestValidationError, validation_exception_translate_handler
)

app.include_router(registration.router, prefix="/auth")
app.include_router(auth.router, prefix="/auth")
app.include_router(recovery.router, prefix="/auth")
