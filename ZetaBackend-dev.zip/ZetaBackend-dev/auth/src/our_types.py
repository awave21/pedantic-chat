from typing import Literal

LoginType = Literal["phone", "nickname", "email"]
RecoveryMethodType = Literal["phone", "email"]
