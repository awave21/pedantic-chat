from base64 import b64decode
from typing import Optional

from fastapi.exceptions import HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.security.utils import get_authorization_scheme_param
from starlette import status
from starlette.requests import Request


class UTF8HTTPBasic(HTTPBasic):
    """Modified `fastapi.security.http.HTTPBasic` code."""

    async def __call__(self, request: Request) -> Optional[HTTPBasicCredentials]:
        authorization: str = request.headers.get("Authorization")
        scheme, param = get_authorization_scheme_param(authorization)
        unauthorized_headers = {"WWW-Authenticate": "Basic"}
        invalid_user_credentials_exc = HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers=unauthorized_headers,
        )
        if not authorization or scheme.lower() != "basic":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not authenticated",
                headers=unauthorized_headers,
            )

        try:
            data = b64decode(param).decode("utf-8")
        except ValueError:
            raise invalid_user_credentials_exc

        username, separator, password = data.partition(":")
        if not separator:
            raise invalid_user_credentials_exc

        return HTTPBasicCredentials(username=username, password=password)
