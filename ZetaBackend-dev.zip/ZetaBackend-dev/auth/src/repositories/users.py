from datetime import datetime, timedelta
from typing import Callable, Optional

from enums.users import UserResponseEnum
from response_tuples import ResponseUserTuple
from schemas.users import UserDraftSchema, UserUpdateSchema
from sqlalchemy import and_, delete, or_, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker
from сonfig import app_settings

from common.database.models import User


class UserRepository:
    base_model = User

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def get_user_by_nickname(self, nickname: str) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.nickname == nickname)
            )
            user = result.scalars().first()
            return user

    async def get_user_by_phone(self, phone: str) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.phone == phone)
            )
            user = result.scalars().first()
            return user

    async def get_user_by_email(self, email: str) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.email == email)
            )
            user = result.scalars().first()
            return user

    async def get_user_by_id(self, id: int) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.id == id)
            )
            user = result.scalars().first()
            return user

    async def get_verified_user(
        self,
        nickname: Optional[str] = None,
        phone: Optional[str] = None,
        email: Optional[str] = None,
    ) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(
                    and_(
                        or_(
                            and_(
                                self.base_model.nickname == nickname,
                                self.base_model.nickname.is_not(None),
                            ),
                            and_(
                                self.base_model.email == email,
                                self.base_model.email.is_not(None),
                            ),
                            and_(
                                self.base_model.phone == phone,
                                self.base_model.phone.is_not(None),
                            ),
                        ),
                        self.base_model.is_draft.is_(False),
                    )
                )
            )
            user = result.scalars().first()
            return user

    async def get_user_by_nickname_or_email_or_phone(
        self,
        nickname: Optional[str] = None,
        email: Optional[str] = None,
        phone: Optional[str] = None,
    ) -> Optional[User]:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(
                    or_(
                        and_(
                            self.base_model.nickname != None,  # noqa: E711
                            self.base_model.nickname == nickname,
                            self.base_model.is_draft.is_(False),
                        ),
                        and_(
                            self.base_model.email != None,  # noqa: E711
                            self.base_model.email == email,
                            self.base_model.is_draft.is_(False),
                        ),
                        and_(
                            self.base_model.phone != None,  # noqa: E711
                            self.base_model.phone == phone,
                            self.base_model.is_draft.is_(False),
                        ),
                    )
                )
            )
            user = result.scalars().first()
            return user

    async def create_user_draft(self, user_draft: UserDraftSchema) -> ResponseUserTuple:
        async with self.get_db() as session:
            user = User(**user_draft.dict(exclude_none=True))
            try:
                session.add(user)
                await session.commit()
                await session.flush(user)
            except IntegrityError:
                return ResponseUserTuple(
                    error_code=400, description=UserResponseEnum.USER_ALREADY_EXISTS
                )
            return ResponseUserTuple(data=user)

    async def update_user(
        self, user_id: int, data: UserUpdateSchema
    ) -> ResponseUserTuple:
        async with self.get_db() as session:
            try:
                result = await session.execute(
                    update(self.base_model)
                    .where(self.base_model.id == user_id)
                    .values(**data.dict(exclude_unset=True))
                    .returning(*self.base_model.__table__.c)
                )
                user = result.first()
                await session.commit()
            except IntegrityError:
                return ResponseUserTuple(
                    error_code=400, description=UserResponseEnum.USER_ALREADY_EXISTS
                )
            return ResponseUserTuple(data=user)

    async def delete_user_draft(self, user_id: int) -> ResponseUserTuple:
        async with self.get_db() as session:

            await session.execute(
                delete(self.base_model).where(self.base_model.id == user_id)
            )
            await session.commit()
            return ResponseUserTuple()

    async def delete_draft_users_lifetime_expired(self) -> ResponseUserTuple:
        async with self.get_db() as session:
            lifetime_expired_date = datetime.now() - timedelta(
                minutes=app_settings.LIFETIME_MINUTES_DRAFT_USER
            )

            await session.execute(
                delete(self.base_model).where(
                    and_(
                        self.base_model.is_draft.is_(True),
                        self.base_model.created_at <= lifetime_expired_date,
                    )
                )
            )
            await session.commit()
            return ResponseUserTuple()

    async def delete_user_drafts_on_verification(
        self,
        nickname: Optional[str] = None,
        phone: Optional[str] = None,
        email: Optional[str] = None,
    ) -> ResponseUserTuple:
        async with self.get_db() as session:

            await session.execute(
                delete(self.base_model).where(
                    and_(
                        or_(
                            self.base_model.nickname == nickname,
                            self.base_model.email == email,
                            self.base_model.phone == phone,
                        ),
                        self.base_model.is_draft.is_(True),
                    )
                )
            )
            await session.commit()
            return ResponseUserTuple()
