import random
from typing import Callable

from response_tuples import ResponseCodeTuple
from sqlalchemy import delete
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker
from сonfig import app_settings

from common.database.models import VerificationCode


class VerificationCodeRepository:
    base_model = VerificationCode

    def __init__(self, get_db: Callable[[], sessionmaker]) -> None:
        self.get_db = get_db

    async def create_verification_code(
        self, user_id: int, type: str
    ) -> ResponseCodeTuple:
        async with self.get_db() as session:
            # todo add randomise or mock code
            if not app_settings.DEBUG:
                code = str(random.randint(100000, 999999))
            else:
                code = app_settings.MOCK_VERIFICATION_CODE
            verification_code = self.base_model(user=user_id, code=code, type=type)
            session.add(verification_code)
            await session.commit()
            await session.flush(verification_code)
            return ResponseCodeTuple(data=verification_code)

    async def get_verification_code(self, code_id: int) -> ResponseCodeTuple:
        async with self.get_db() as session:
            result = await session.execute(
                select(self.base_model).where(self.base_model.id == code_id)
            )
            code = result.scalars().first()
            return ResponseCodeTuple(data=code)

    async def delete_verification_code(self, code_id: int) -> ResponseCodeTuple:
        async with self.get_db() as session:
            await session.execute(
                delete(self.base_model).where(self.base_model.id == code_id)
            )
            await session.commit()
            return ResponseCodeTuple()
