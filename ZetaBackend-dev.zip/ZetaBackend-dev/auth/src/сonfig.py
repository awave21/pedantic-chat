from pydantic import BaseSettings

from common.auth.jwt_handler import AuthHandler
from common.configs import JWTSettings


class AppSettings(BaseSettings):
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    DB_CONTAINER_NAME: str
    PORT_DB: str
    POSTGRES_DB: str
    DEBUG: int = 0
    MOCK_VERIFICATION_CODE: str = "111111"
    LIFETIME_MINUTES_DRAFT_USER: int = 5


class SmsSettings(BaseSettings):
    SMS_URL: str
    SMS_LOGIN: str
    SMS_PASSWORD: str
    SMS_NAME: str

    SMSAERO_LOGIN: str
    SMSAERO_PASSWORD: str
    SMSAERO_BASE_URL: str
    SMSAERO_SIGN: str = "SMS Aero"


class SMTPSettings(BaseSettings):
    SMTP_LOGIN: str
    SMTP_PASS: str
    SMTP_HOST: str
    SMTP_PORT: int


app_settings = AppSettings()
jwt_settings = JWTSettings()
sms_settings = SmsSettings()
smtp_settings = SMTPSettings()

auth_handler = AuthHandler(jwt_settings)
