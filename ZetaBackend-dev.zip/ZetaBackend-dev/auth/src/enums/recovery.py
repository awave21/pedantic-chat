from common.enums.languages import AbstractLangEnum


class RecoveryResponseEnum(AbstractLangEnum):
    CHOOSE_RECOVERY_METHOD = "Choose recovery method", "Выберите метод восстановления"
    RECOVERY_METHOD_NOT_FOUND = (
        "No recovery methods found",
        "Возможные методы восстановления не найдены",
    )
    RECOVERY_METHOD_INVALID = (
        "Invalid recovery method",
        "Некорректный метод восстановления",
    )
