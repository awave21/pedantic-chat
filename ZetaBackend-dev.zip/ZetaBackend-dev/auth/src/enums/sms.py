from common.enums.languages import AbstractLangEnum


class SmsResponseEnum(AbstractLangEnum):
    ERROR_WITH_SERVICE = "SMS SERVICE ERROR", "Проблемы с смс сервисом"
