from common.enums.languages import AbstractLangEnum


class UserResponseEnum(AbstractLangEnum):
    USER_NOT_FOUND = "User not found", "Пользователь не найден"
    USER_ALREADY_EXISTS = (
        "User with this data already exists",
        "Пользователь с такими данными уже существует",
    )

    USED_NICKNAME = "This nickname has been taken", "Данный никнейм уже используется"

    BAD_CREDENTIALS = "Bad credentials", "Неправильный логин или пароль"
    BLOCKED = "User is blocked", "Пользователь заблокирован"
