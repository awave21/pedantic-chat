from common.enums.languages import AbstractLangEnum


class VerifyResponseEnum(AbstractLangEnum):
    VERIFY_CODE_SEND = (
        "Your confirmation code was sent",
        "Вам код подтверждения отправлен",
    )
    VERIFY_CODE_WRONG = "Verification code is wrong", "Неправильный код восстановления"
    VERIFY_CODE_NOT_FOUND = (
        "Verification code with this id is not exist",
        "Код восстановления не найден",
    )
