from common.enums.languages import AbstractLangEnum


class EmailResponseEnum(AbstractLangEnum):
    ERROR_WITH_SERVICE = "EMAIL SERVICE ERROR", "Проблемы с email сервисом"
