from repositories.users import UserRepository
from repositories.verification_codes import VerificationCodeRepository
from services.auth import AuthService
from services.recovery import RecoveryService
from services.registration import RegistrationService
from services.sms import SmsService

from common.db import get_db

user_repository = UserRepository(get_db)
verify_code_repository = VerificationCodeRepository(get_db)
sms_service = SmsService()

auth_service = AuthService(user_repository)
recovery_service = RecoveryService(user_repository, verify_code_repository, sms_service)
registration_service = RegistrationService(
    user_repository, verify_code_repository, sms_service
)


async def get_auth_service() -> AuthService:
    return auth_service


async def get_recovery_service() -> RecoveryService:
    return recovery_service


async def get_registration_service() -> RegistrationService:
    return registration_service
