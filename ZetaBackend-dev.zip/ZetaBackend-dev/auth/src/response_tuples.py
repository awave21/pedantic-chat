from typing import Dict, List, NamedTuple, Optional, Union

from our_types import LoginType

from common.database.models import User, VerificationCode
from common.enums.languages import AbstractLangEnum


class ResponseUserTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Union[List[User], User, None] = None


class ResponseCodeTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[VerificationCode] = None


class ResponseRecoveryCodeTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[VerificationCode] = None
    send_to: Optional[LoginType] = None
    method_data: Optional[str] = None


class ResponseJWTTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[Dict] = None


class ResponseSmsTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[Union[Dict, str]] = None


class ResponseSMTPTuple(NamedTuple):
    error_code: Optional[int] = None
    description: Optional[AbstractLangEnum] = None
    data: Optional[str] = None
