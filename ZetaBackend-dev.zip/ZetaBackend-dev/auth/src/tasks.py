from depends import user_repository


async def remove_old_user_drafts() -> None:
    await user_repository.delete_draft_users_lifetime_expired()
    print("Users drafts were deleted successful")
