from typing import Union

import bcrypt
from enums.users import UserResponseEnum
from enums.verify import VerifyResponseEnum
from repositories.users import UserRepository
from repositories.verification_codes import VerificationCodeRepository
from response_tuples import (
    ResponseCodeTuple,
    ResponseJWTTuple,
    ResponseSmsTuple,
    ResponseUserTuple,
)
from schemas.users import UserDraftSchema, UserUpdateSchema, VerificationCodeSchema
from сonfig import auth_handler

from common.database.models import User

from .sms import SmsService
from .smtp import send_auth_email


class RegistrationService:
    def __init__(
        self,
        user_repository: UserRepository,
        verification_code_repository: VerificationCodeRepository,
        sms_service: SmsService,
    ):
        self.user_repository = user_repository
        self.verification_code_repository = verification_code_repository
        self.sms_service = sms_service

    async def check_nickname(self, nickname: str) -> Union[User, None]:
        return await self.user_repository.get_user_by_nickname_or_email_or_phone(
            nickname=nickname
        )

    async def rollback(self, user_id: int, code_id: int) -> None:
        await self.user_repository.delete_user_draft(user_id)
        await self.verification_code_repository.delete_verification_code(code_id)

    async def create_draft_user_and_start_verification(
        self, user_draft: UserDraftSchema
    ) -> Union[ResponseUserTuple, ResponseCodeTuple, ResponseSmsTuple]:
        existing_user = (
            await self.user_repository.get_user_by_nickname_or_email_or_phone(
                nickname=user_draft.nickname,
                email=user_draft.email,
                phone=user_draft.phone,
            )
        )
        if existing_user:
            return ResponseUserTuple(
                error_code=400, description=UserResponseEnum.USER_ALREADY_EXISTS
            )
        result = await self.user_repository.create_user_draft(user_draft)
        if not result.error_code:
            if result.data.email:
                email = result.data.email
                result = (
                    await self.verification_code_repository.create_verification_code(
                        result.data.id, "email"
                    )
                )
                result_smtp = await send_auth_email(email, result.data.code)
                if result_smtp.error_code:
                    await self.rollback(result.data.user, result.data.id)
                    return result_smtp
            else:
                phone = result.data.phone_int
                result = (
                    await self.verification_code_repository.create_verification_code(
                        result.data.id, "phone"
                    )
                )
                result_sms = await self.sms_service.send_sms(result.data.code, phone)
                if result_sms.error_code:
                    await self.rollback(result.data.user, result.data.id)
                    return result_sms
        return result

    async def validate_user_and_get_access_token(
        self, verification_code: VerificationCodeSchema
    ) -> Union[ResponseUserTuple, ResponseCodeTuple, ResponseJWTTuple]:
        result = await self.verification_code_repository.get_verification_code(
            verification_code.id
        )
        if result.data:
            if result.data.code == verification_code.code:
                user = await self.user_repository.get_user_by_id(result.data.user)
                nickname = user.nickname
                email = user.email
                phone = user.phone
                # проверяем наличие уже подтвержденного юзера с таким ником
                if await self.user_repository.get_verified_user(
                    nickname=nickname, phone=phone, email=email
                ):
                    await self.verification_code_repository.delete_verification_code(
                        verification_code.id
                    )
                    return ResponseUserTuple(
                        error_code=400, description=UserResponseEnum.USER_ALREADY_EXISTS
                    )
                # подтверждаем юзера
                result = await self.user_repository.update_user(
                    result.data.user, UserUpdateSchema(is_draft=False)
                )
                if result.error_code:
                    return result
                # удаляем драфты с таким же ником
                await self.user_repository.delete_user_drafts_on_verification(
                    nickname=nickname, phone=phone, email=email
                )
                # удаляем код
                await self.verification_code_repository.delete_verification_code(
                    verification_code.id
                )
                # получаем токен и отдаем
                payload = auth_handler.encode_login_token(id=result.data.id)
                return ResponseJWTTuple(data=payload)
            else:
                return ResponseCodeTuple(
                    error_code=400, description=VerifyResponseEnum.VERIFY_CODE_WRONG
                )
        return ResponseCodeTuple(
            error_code=404, description=VerifyResponseEnum.VERIFY_CODE_NOT_FOUND
        )

    async def set_user_password(self, user: User, password: str) -> ResponseUserTuple:
        hashed_password = bcrypt.hashpw(bytes(password, "utf-8"), bcrypt.gensalt())
        return await self.user_repository.update_user(
            user.id, UserUpdateSchema(password=hashed_password)
        )
