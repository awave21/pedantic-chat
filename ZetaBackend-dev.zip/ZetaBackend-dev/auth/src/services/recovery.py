from typing import Optional, Tuple, Union

from enums.recovery import RecoveryResponseEnum
from enums.users import UserResponseEnum
from enums.verify import VerifyResponseEnum
from our_types import LoginType
from repositories.users import UserRepository
from repositories.verification_codes import VerificationCodeRepository
from response_tuples import (
    ResponseJWTTuple,
    ResponseRecoveryCodeTuple,
    ResponseSmsTuple,
)
from schemas.users import (
    UserRecoveryByMethodSchema,
    UserRecoverySchema,
    VerificationCodeSchema,
)
from services.sms import SmsService
from services.smtp import send_auth_email
from сonfig import auth_handler

from common.database.models import User


class RecoveryService:
    def __init__(
        self,
        user_repository: UserRepository,
        verification_code_repository: VerificationCodeRepository,
        sms_service: SmsService,
    ):
        self.user_repository = user_repository
        self.verification_code_repository = verification_code_repository
        self.sms_service = sms_service

    async def send_verification_code(
        self, user_data: UserRecoverySchema
    ) -> Union[ResponseRecoveryCodeTuple, ResponseSmsTuple]:
        login_type, user_login = self._get_login_type_and_value_from_recovery_schema(
            user_data
        )

        user = await self._get_user_by_login_type(user_login, login_type)

        if not user:
            return ResponseRecoveryCodeTuple(
                error_code=400, description=UserResponseEnum.USER_NOT_FOUND
            )

        if not (login_type == "nickname" and user.email and user.phone):
            # Пользователь ввел почту или номер, или у него привязан только один способ восстановления
            if login_type == "nickname":
                if user.phone:
                    login_type = "phone"
                    user_login = user.phone
                elif user.email:
                    login_type = "email"
                    user_login = user.email
                else:
                    return ResponseRecoveryCodeTuple(
                        error_code=404,
                        description=RecoveryResponseEnum.RECOVERY_METHOD_NOT_FOUND,
                    )

            result = await self.verification_code_repository.create_verification_code(
                user.id, login_type
            )
            if login_type == "phone":
                result_sms = await self.sms_service.send_sms(
                    result.data.code, user.phone_int
                )
                if result_sms.error_code:
                    await self.verification_code_repository.delete_verification_code(
                        result.data.id
                    )
                    return result_sms
            else:
                result_smtp = await send_auth_email(user.email, result.data.code)
                if result_smtp.error_code:
                    await self.verification_code_repository.delete_verification_code(
                        result.data.id
                    )
                    return result_smtp
            result = ResponseRecoveryCodeTuple(
                data=result.data, send_to=login_type, method_data=user_login
            )
        else:
            # Предоставляем пользователю выбор способа аутентификации
            result = ResponseRecoveryCodeTuple(send_to="nickname")

        return result

    async def send_verification_code_by_method(
        self, user_data: UserRecoveryByMethodSchema
    ) -> Union[ResponseRecoveryCodeTuple, ResponseSmsTuple]:
        user = await self.user_repository.get_user_by_nickname(user_data.nickname)

        if not user:
            return ResponseRecoveryCodeTuple(
                error_code=400, description=UserResponseEnum.USER_NOT_FOUND
            )

        if (user_data.send_to == "email" and user.email) or (
            user_data.send_to == "phone" and user.phone
        ):
            result = await self.verification_code_repository.create_verification_code(
                user.id, user_data.send_to
            )
            # todo отправка кода в зависимости от выбранного варианта
            login_data = user.email if user_data.send_to == "email" else user.phone

            if user_data.send_to == "phone":
                result_sms = await self.sms_service.send_sms(
                    result.data.code, login_data
                )
                if result_sms.error_code:
                    await self.verification_code_repository.delete_verification_code(
                        result.data.id
                    )
                    return result_sms
            else:
                # todo make for email
                pass

            result = ResponseRecoveryCodeTuple(
                data=result.data, send_to=user_data.send_to, method_data=login_data
            )
        else:
            result = ResponseRecoveryCodeTuple(
                error_code=400, description=RecoveryResponseEnum.RECOVERY_METHOD_INVALID
            )

        return result

    async def check_confirm_code_and_send_jwt(
        self,
        verification_code: VerificationCodeSchema,
    ) -> ResponseJWTTuple:
        result = await self.verification_code_repository.get_verification_code(
            verification_code.id
        )
        if result.data:
            if result.data.code == verification_code.code:
                payload = auth_handler.encode_login_token(id=result.data.user)
                return ResponseJWTTuple(data=payload)
            else:
                return ResponseJWTTuple(
                    error_code=400, description=VerifyResponseEnum.VERIFY_CODE_WRONG
                )
        return ResponseJWTTuple(
            error_code=404, description=VerifyResponseEnum.VERIFY_CODE_NOT_FOUND
        )

    @staticmethod
    def _get_login_type_and_value_from_recovery_schema(
        recovery_schema: UserRecoverySchema,
    ) -> Tuple[LoginType, str]:
        if recovery_schema.phone:
            return "phone", recovery_schema.phone
        elif recovery_schema.nickname:
            return "nickname", recovery_schema.nickname
        else:
            return "email", recovery_schema.email

    async def _get_user_by_login_type(
        self, user_login: str, login_type: LoginType
    ) -> Optional[User]:
        if login_type == "email":
            return await self.user_repository.get_user_by_email(user_login)
        elif login_type == "phone":
            return await self.user_repository.get_user_by_phone(user_login)
        else:
            return await self.user_repository.get_user_by_nickname(user_login)
