import aiohttp
from enums.sms import SmsResponseEnum
from response_tuples import ResponseSmsTuple
from сonfig import app_settings, sms_settings


class SmsService:
    def __init__(self) -> None:
        self.login = sms_settings.SMSAERO_LOGIN
        self.password = sms_settings.SMSAERO_PASSWORD
        self.base_url = sms_settings.SMSAERO_BASE_URL
        self.sign = sms_settings.SMSAERO_SIGN

    async def _get_authorisation_headers(self) -> aiohttp.BasicAuth:
        return aiohttp.BasicAuth(self.login, self.password)

    async def send_sms(self, code: str, phone: int) -> ResponseSmsTuple:
        if app_settings.DEBUG:
            return ResponseSmsTuple()
        headers = {"ACCEPT": "application/json"}
        params = {
            "number": f"+{phone}",
            "sign": self.sign,
            "text": f"Your auth code {code}",
        }
        url = f"https://{self.base_url}/v2/sms/send"
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url=url,
                params=params,
                auth=await self._get_authorisation_headers(),
                headers=headers,
            ) as response:
                if response.ok:
                    return ResponseSmsTuple(data=await response.json())
                else:
                    print(
                        f"Error with sms service {response.status}, {await response.text()}"
                    )
                    return ResponseSmsTuple(
                        error_code=response.status,
                        description=SmsResponseEnum.ERROR_WITH_SERVICE,
                        data=await response.text(),
                    )
