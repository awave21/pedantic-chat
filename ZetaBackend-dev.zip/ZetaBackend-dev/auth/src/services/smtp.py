import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from enums.smtp import EmailResponseEnum
from response_tuples import ResponseSMTPTuple
from сonfig import app_settings, smtp_settings


async def send_auth_email(email: str, code: str) -> ResponseSMTPTuple:
    if app_settings.DEBUG:
        return ResponseSMTPTuple(data="Письмо успешно отправлено")
    msg = MIMEMultipart()
    msg["From"] = smtp_settings.SMTP_LOGIN
    msg["To"] = email
    msg["Subject"] = "Код авторизации ZetaApp"
    message = f"Код подтверждения: {code}"
    msg.attach(MIMEText(message))
    try:
        mailserver = smtplib.SMTP_SSL(smtp_settings.SMTP_HOST, smtp_settings.SMTP_PORT)
        mailserver.set_debuglevel(True)
        mailserver.login(smtp_settings.SMTP_LOGIN, smtp_settings.SMTP_PASS)
        mailserver.sendmail(smtp_settings.SMTP_LOGIN, email, msg.as_string())
        mailserver.quit()
        print("Письмо успешно отправлено")
        return ResponseSMTPTuple(data="Письмо успешно отправлено")
    except smtplib.SMTPException as e:
        print(f"Ошибка: Невозможно отправить сообщение {e}")
        return ResponseSMTPTuple(
            error_code=500,
            description=EmailResponseEnum.ERROR_WITH_SERVICE,
            data=str(e),
        )
