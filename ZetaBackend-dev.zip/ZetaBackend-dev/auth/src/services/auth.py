from typing import Optional, Union

import bcrypt
from enums.users import UserResponseEnum
from our_types import LoginType
from repositories.users import UserRepository
from response_tuples import ResponseJWTTuple, ResponseUserTuple
from сonfig import auth_handler

from common.database.models import User


class AuthService:
    def __init__(
        self,
        user_repository: UserRepository,
    ):
        self.user_repository = user_repository

    async def login_user(
        self, user_login: str, password: str, login_type: LoginType
    ) -> Union[ResponseUserTuple, ResponseJWTTuple]:
        user = await self._get_user_by_login_type(user_login, login_type)

        if not user:
            return ResponseUserTuple(
                error_code=400, description=UserResponseEnum.BAD_CREDENTIALS
            )

        if user.is_blocked:
            return ResponseUserTuple(
                error_code=403, description=UserResponseEnum.BLOCKED
            )

        if not bcrypt.checkpw(bytes(password, "utf-8"), bytes(user.password, "utf-8")):
            return ResponseUserTuple(
                error_code=400, description=UserResponseEnum.BAD_CREDENTIALS
            )

        payload = auth_handler.encode_login_token(id=user.id)
        return ResponseJWTTuple(data=payload)

    @staticmethod
    async def refresh_token(user_id: int) -> ResponseJWTTuple:
        payload = auth_handler.encode_login_token(id=user_id)
        return ResponseJWTTuple(data=payload)

    async def _get_user_by_login_type(
        self, user_login: str, login_type: LoginType
    ) -> Optional[User]:
        if login_type == "email":
            return await self.user_repository.get_user_by_email(user_login)
        elif login_type == "phone":
            return await self.user_repository.get_user_by_phone(user_login)
        else:
            return await self.user_repository.get_user_by_nickname(user_login)
