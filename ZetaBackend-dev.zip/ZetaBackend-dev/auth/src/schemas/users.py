from typing import Dict, Optional

from our_types import LoginType, RecoveryMethodType
from pydantic import BaseModel, Field, root_validator, validator

from common.enums.validators import ValidatorsErrorEnum
from common.schemas.validators import validate_email, validate_phone_number


class ValidateEmailAndPhoneScheme(BaseModel):
    phone: Optional[str]
    email: Optional[str]

    @validator("email")
    def validate_email(cls, v: str) -> str:
        if v:
            return validate_email(v)
        return v

    @validator("phone")
    def validate_phone(cls, v: str) -> str:
        if v:
            return validate_phone_number(v)
        return v


class UserDraftSchema(ValidateEmailAndPhoneScheme):
    age: Optional[int]
    nickname: str

    @root_validator
    def check_existing_contacts(cls, values: Dict) -> Dict:
        phone, email = values.get("phone"), values.get("email")
        if (not phone) and (not email):
            raise ValueError(
                ValidatorsErrorEnum.PHONE_AND_EMAIL_EMPTY.to_str_dict_for_exception
            )
        return values


class UserRecoverySchema(ValidateEmailAndPhoneScheme):
    nickname: Optional[str]

    @root_validator
    def check_existing_contacts(cls, values: Dict) -> Dict:
        if (
            (not values.get("phone"))
            and (not values.get("email"))
            and (not values.get("nickname"))
        ):
            raise ValueError(
                ValidatorsErrorEnum.PHONE_AND_EMAIL_AND_NICKNAME_EMPTY.to_str_dict_for_exception
            )
        return values


class UserRecoveryByMethodSchema(BaseModel):
    nickname: str
    send_to: RecoveryMethodType


class UserUpdateSchema(BaseModel):
    age: Optional[int]
    is_draft: Optional[bool]
    phone: Optional[str]
    email: Optional[str]
    password: Optional[str]


class UserPasswordSchema(BaseModel):
    password1: str
    password2: str

    @root_validator
    def check_existing_contacts(cls, values: Dict) -> Dict:
        password1, password2 = values.get("password1"), values.get("password2")
        if not (password1 and password2):
            raise ValueError(
                ValidatorsErrorEnum.PASSWORDS_EMPTY.to_str_dict_for_exception
            )
        if password1 != password2:
            raise ValueError(
                ValidatorsErrorEnum.PASSWORDS_NO_EQUAL.to_str_dict_for_exception
            )
        if len(password1) < 8:
            raise ValueError(
                ValidatorsErrorEnum.PASSWORD_SMALL_LEN.to_str_dict_for_exception
            )
        if not any(char.isdigit() for char in password1):
            raise ValueError(
                ValidatorsErrorEnum.PASSWORD_NOT_CONTAIN_DIGIT.to_str_dict_for_exception
            )
        if not any(char.isupper() for char in password1):
            raise ValueError(
                ValidatorsErrorEnum.PASSWORD_NOT_CONTAIN_UPPER.to_str_dict_for_exception
            )
        return values


class VerificationCodeSchema(BaseModel):
    id: int
    code: str


class UserDraftResponseSchema(BaseModel):
    code_id: int
    message: str


class RecoveryVerificationCodeSchema(BaseModel):
    code_id: Optional[int] = None
    message: str
    send_to: LoginType
    method_data: Optional[str] = None
