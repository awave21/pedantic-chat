from pydantic import BaseModel


class InfoResponse(BaseModel):
    detail: str


class JWTResponse(BaseModel):
    access: str
    refresh: str
