from depends import get_auth_service
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.security import HTTPBasicCredentials
from our_types import LoginType
from schemas.common import JWTResponse
from services.auth import AuthService
from starlette.requests import Request
from starlette.responses import JSONResponse
from utf_basic import UTF8HTTPBasic
from сonfig import auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/auth")
security = UTF8HTTPBasic()


@router.get(
    "/login",
    response_model=JWTResponse,
    description="Ручка для получения access token по логину+паролю, "
    "которые отправляются сюда по Basic Auth",
    tags=["auth"],
)
async def login(
    request: Request,
    credentials: HTTPBasicCredentials = Depends(security),
    login_type: LoginType = Query(
        ...,
        description="Указывает тип поля используемого для авторизации, телефон/никнейм/почта",
    ),
    auth_service: AuthService = Depends(get_auth_service),
) -> JSONResponse:
    result = await auth_service.login_user(
        credentials.username, credentials.password, login_type
    )
    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )
    return JSONResponse(result.data, status_code=200)


@router.get(
    "/refresh_token",
    response_model=JWTResponse,
    description="Ручка для получения новой пары токенов по refresh token",
    tags=["auth"],
)
async def refresh_token(
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.REFRESH)),
    auth_service: AuthService = Depends(get_auth_service),
) -> JSONResponse:
    result = await auth_service.refresh_token(user.id)

    return JSONResponse(result.data, status_code=200)


@router.get(
    "/check_auth_with_access_token",
    tags=["test"],
    description="Тестовый метод для проверки работоспособности access token",
)
async def access_token_check(
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS))
) -> JSONResponse:
    return JSONResponse({"success": True})


@router.get(
    "/check_auth_with_refresh_token",
    tags=["test"],
    description="Тестовый метод для проверки работоспособности refresh token",
)
async def refresh_token_check(
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.REFRESH))
) -> JSONResponse:
    return JSONResponse({"success": True})


@router.get(
    "/get_my_tokens/{id}",
    tags=["test"],
    description="Тестовый метод для генерации jwt токенов по id",
    response_model=JWTResponse,
)
async def get_tokens(id: int) -> JSONResponse:
    payload = auth_handler.encode_login_token(id=id)
    return JSONResponse(payload)
