from depends import get_recovery_service
from enums.recovery import RecoveryResponseEnum
from enums.verify import VerifyResponseEnum
from fastapi import APIRouter, Depends, HTTPException
from schemas.common import JWTResponse
from schemas.users import (
    RecoveryVerificationCodeSchema,
    UserRecoveryByMethodSchema,
    UserRecoverySchema,
    VerificationCodeSchema,
)
from services.recovery import RecoveryService
from starlette.requests import Request
from starlette.responses import JSONResponse
from сonfig import app_settings

router = APIRouter(prefix="/recovery", tags=["recovery"])


@router.post(
    "/request_code",
    response_model=RecoveryVerificationCodeSchema,
    responses={
        200: {"description": "Accepted"},
        400: {"description": "Bad request"},
        404: {"description": "Not found"},
    },
    description="""
        В соответствии с блок схемой восстановления доступа отсылает на возможные
        способы восстановление код подтверждения - {} или предлагает выбрать способ восстановления.\n
        Принимает nickname/phone/email в зависимости от введенных данных. Нужный способ должен быть строкой, а другие - null.\n
        Возвращает:
        code_id - идентификатор кода верификации, для дальнейшего подтверждения (приходит если send_to=email/phone)
        message - сообщение строкой
        method_data - почта или телефон, на которое было отослано сообщение (приходит если send_to=email/phone)
        send_to:
        Поле send_to указывает, куда был отправлен код:
        email - на почту,
        phone - на телефон,
        nickname - пользователь имеет возможность выбрать способ восстановления: телефон или почту -
        В таком случае необходимо использовать - recovery/request_code_by_method
    """.format(
        app_settings.MOCK_VERIFICATION_CODE
    ),
)
async def send_verification_code(
    request: Request,
    user_data: UserRecoverySchema,
    recovery_service: RecoveryService = Depends(get_recovery_service),
) -> JSONResponse:
    result = await recovery_service.send_verification_code(user_data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    if result.send_to != "nickname":
        data = RecoveryVerificationCodeSchema(
            send_to=result.send_to,
            code_id=result.data.id,
            message=VerifyResponseEnum.VERIFY_CODE_SEND.translate(
                request.state.language
            ),
            method_data=result.method_data,
        )
    else:
        data = RecoveryVerificationCodeSchema(
            send_to=result.send_to,
            message=RecoveryResponseEnum.CHOOSE_RECOVERY_METHOD.translate(
                request.state.language
            ),
        )

    return JSONResponse(data.dict(), status_code=201)


@router.post(
    "/request_code_by_method",
    response_model=RecoveryVerificationCodeSchema,
    responses={
        200: {"description": "Accepted"},
        400: {"description": "Bad request"},
        404: {"description": "Not found"},
    },
    description="""
        Вызывается после recovery/request_code, когда пользователь может выбрать способ восстановления.
        Отправляет на выбранный способ код восстановления.\n
        Принимает nickname пользователя и выбранный способ восстановления\n
        Возвращает:
        code_id - идентификатор кода верификации, для дальнейшего подтверждения
        message - сообщение строкой
        method_data - почта или телефон, на которое было отослано сообщениe
        Поле send_to указывает, куда был отправлен код:
        email - на почту,
        phone - на телефон,
    """,
)
async def send_verification_code_by_method(
    request: Request,
    user_data: UserRecoveryByMethodSchema,
    recovery_service: RecoveryService = Depends(get_recovery_service),
) -> JSONResponse:
    result = await recovery_service.send_verification_code_by_method(user_data)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    data = RecoveryVerificationCodeSchema(
        send_to=result.send_to,
        code_id=result.data.id,
        message=VerifyResponseEnum.VERIFY_CODE_SEND.translate(request.state.language),
        method_data=result.method_data,
    )

    return JSONResponse(data.dict(), status_code=201)


@router.post(
    "/confirm_code",
    response_model=JWTResponse,
    responses={
        200: {"description": "Accepted"},
        400: {"description": "Bad request"},
        404: {"description": "Not found"},
    },
    description="Получает jwt токен для обращения к методу сброса пароля",
)
async def check_confirm_code_and_send_jwt(
    request: Request,
    verify_code: VerificationCodeSchema,
    recovery_service: RecoveryService = Depends(get_recovery_service),
) -> JSONResponse:
    result = await recovery_service.check_confirm_code_and_send_jwt(verify_code)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )
    return JSONResponse(result.data, status_code=200)
