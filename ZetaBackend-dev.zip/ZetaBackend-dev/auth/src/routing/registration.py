from depends import get_registration_service
from enums.users import UserResponseEnum
from enums.verify import VerifyResponseEnum
from fastapi import APIRouter, Depends, HTTPException
from schemas.common import JWTResponse
from schemas.users import (
    UserDraftResponseSchema,
    UserDraftSchema,
    UserPasswordSchema,
    VerificationCodeSchema,
)
from services.registration import RegistrationService
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from сonfig import app_settings, auth_handler

from common.auth.jwt_bearer import get_jwt_bearer
from common.auth.jwt_handler import TokenType
from common.database.models import User

router = APIRouter(prefix="/registration", tags=["registration"])


@router.get(
    "/check_nickname/{nickname}",
    responses={400: {"description": "Bad request"}},
    description="Проверка есть ли такой ник в базе, если есть - вернет 400, если нет - 200",
)
async def check_nickname(
    request: Request,
    nickname: str,
    registration_service: RegistrationService = Depends(get_registration_service),
) -> Response:
    user = await registration_service.check_nickname(nickname)

    if user:
        raise HTTPException(
            400, detail=UserResponseEnum.USED_NICKNAME.translate(request.state.language)
        )

    return Response(status_code=200)


@router.post(
    "/create_draft",
    responses={201: {"description": "Created"}, 400: {"description": "Bad request"}},
    response_model=UserDraftResponseSchema,
    description="Апи для создания черновика пользователя, также получает информацию о способе верификации пользователя,"
    "после чего отправляет код подтверждения на телефон или почту, на данный момент временный код всегда - "
    f"{app_settings.MOCK_VERIFICATION_CODE}, отдает айди кода подтверждения - он нужен далее",
)
async def create_draft_and_send_verification_code(
    request: Request,
    user_draft: UserDraftSchema,
    registration_service: RegistrationService = Depends(get_registration_service),
) -> JSONResponse:
    result = await registration_service.create_draft_user_and_start_verification(
        user_draft
    )

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    data = UserDraftResponseSchema(
        code_id=result.data.id,
        message=VerifyResponseEnum.VERIFY_CODE_SEND.translate(request.state.language),
    )
    return JSONResponse(data.dict(), status_code=201)


@router.post(
    "/verify_user",
    response_model=JWTResponse,
    responses={
        200: {"description": "Accepted"},
        400: {"description": "Bad request"},
        404: {"description": "Not found"},
    },
    description="Получает айди кода подтверждения и сам код, на данный момент тестовый код "
    f"- {app_settings.MOCK_VERIFICATION_CODE}, в случае успеха подтверждает пользователя и дает "
    "jwt токены",
)
async def verify_user_and_get_access_token(
    request: Request,
    verify_code: VerificationCodeSchema,
    registration_service: RegistrationService = Depends(get_registration_service),
) -> JSONResponse:
    result = await registration_service.validate_user_and_get_access_token(verify_code)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return JSONResponse(result.data, status_code=200)


@router.patch(
    "/set_password",
    responses={202: {"description": "Accepted"}},
    description="Метод, который завершает регистрацию установкой пароля у юзера",
)
async def set_password(
    request: Request,
    user_pass: UserPasswordSchema,
    registration_service: RegistrationService = Depends(get_registration_service),
    user: User = Depends(get_jwt_bearer(auth_handler, TokenType.ACCESS)),
) -> Response:
    result = await registration_service.set_user_password(user, user_pass.password1)

    if result.error_code:
        raise HTTPException(
            status_code=result.error_code,
            detail=result.description.translate(request.state.language),
        )

    return Response(status_code=202)
